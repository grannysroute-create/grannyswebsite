import React, { useState } from 'react';
import { Link, useLocation } from 'react-router-dom';
import { Button } from "@/components/ui/button";
import { Sheet, SheetContent, SheetTrigger } from "@/components/ui/sheet";
import { Shield, Menu, Map, Truck, AlertTriangle, Home, Route, Star, ShoppingBag, Crown, MapPin, Database, ShoppingCart } from 'lucide-react';
import GearPopover from './GearPopover';

const navLinks = [
  { path: '/', label: 'Home', icon: Home },
  { path: '/dashboard', label: 'Dashboard', icon: Map },
  { path: '/route-planner', label: 'Plan Route', icon: Route },
  { path: '/hazard-map', label: 'Hazard Map', icon: MapPin },
  { path: '/community', label: 'Hazards', icon: AlertTriangle },
  { path: '/reviews', label: 'Reviews', icon: Star },
  { path: '/rig-profile', label: 'My Rig', icon: Truck },
  { path: '/dot-resources', label: 'DOT Data', icon: Database },
];

export default function Navbar() {
  const location = useLocation();
  const [open, setOpen] = useState(false);

  return (
    <nav className="sticky top-0 z-50 bg-card/80 backdrop-blur-lg border-b border-border">
      <div className="max-w-7xl mx-auto px-4 sm:px-6 lg:px-8">
        <div className="flex items-center justify-between h-16">
          <Link to="/" className="flex items-center gap-2.5">
            <div className="w-9 h-9 rounded-xl bg-primary flex items-center justify-center">
              <Shield className="w-5 h-5 text-primary-foreground" />
            </div>
            <div>
              <span className="font-heading text-lg font-semibold text-foreground tracking-tight">RVBridgeSafe</span>
              <span className="text-accent font-heading text-lg">.app</span>
            </div>
          </Link>

          {/* Desktop Nav */}
          <div className="hidden md:flex items-center gap-1">
            {navLinks.map(link => (
              <Link key={link.path} to={link.path}>
                <Button
                  variant={location.pathname === link.path ? "secondary" : "ghost"}
                  size="sm"
                  className="font-body text-sm gap-2"
                >
                  <link.icon className="w-4 h-4" />
                  {link.label}
                </Button>
              </Link>
            ))}
            <GearPopover />
            <Link to="/gumroad-guide">
              <Button
                variant={location.pathname === '/gumroad-guide' ? "secondary" : "ghost"}
                size="sm"
                className="font-body text-sm gap-2"
              >
                <ShoppingCart className="w-4 h-4" />
                Download & Setup
              </Button>
            </Link>
            <Link to="/upgrade">
              <Button size="sm" className="font-body text-sm gap-1.5 ml-2 rounded-xl bg-accent hover:bg-accent/90 text-accent-foreground">
                <Crown className="w-3.5 h-3.5" />
                Go Pro
              </Button>
            </Link>
          </div>

          {/* Mobile Nav */}
          <Sheet open={open} onOpenChange={setOpen}>
            <SheetTrigger asChild className="md:hidden">
              <Button variant="ghost" size="icon">
                <Menu className="w-5 h-5" />
              </Button>
            </SheetTrigger>
            <SheetContent side="right" className="w-72">
              <div className="flex flex-col gap-2 mt-8">
                {navLinks.map(link => (
                  <Link key={link.path} to={link.path} onClick={() => setOpen(false)}>
                    <Button
                      variant={location.pathname === link.path ? "secondary" : "ghost"}
                      className="w-full justify-start gap-3 font-body"
                    >
                      <link.icon className="w-5 h-5" />
                      {link.label}
                    </Button>
                  </Link>
                ))}
                <Link to="/gear" onClick={() => setOpen(false)}>
                  <Button
                    variant={location.pathname === '/gear' ? "secondary" : "ghost"}
                    className="w-full justify-start gap-3 font-body"
                  >
                    <ShoppingBag className="w-5 h-5" />
                    Gear, Gas, & Grub
                  </Button>
                </Link>
                <Link to="/gumroad-guide" onClick={() => setOpen(false)}>
                  <Button
                    variant={location.pathname === '/gumroad-guide' ? "secondary" : "ghost"}
                    className="w-full justify-start gap-3 font-body"
                  >
                    <ShoppingCart className="w-5 h-5" />
                    Download & Setup
                  </Button>
                </Link>
                <Link to="/upgrade" onClick={() => setOpen(false)}>
                  <Button className="w-full justify-start gap-3 font-body mt-2 bg-accent hover:bg-accent/90 text-accent-foreground rounded-xl">
                    <Crown className="w-5 h-5" />
                    Go Pro
                  </Button>
                </Link>
              </div>
            </SheetContent>
          </Sheet>
        </div>
      </div>
    </nav>
  );
}