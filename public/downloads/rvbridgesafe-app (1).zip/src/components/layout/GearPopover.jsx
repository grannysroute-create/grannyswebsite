import React from 'react';
import { Link } from 'react-router-dom';
import { ShoppingBag, ExternalLink, ArrowRight, ChevronDown, Star, ShoppingCart, Fuel, Smartphone, Package } from 'lucide-react';
import { Button } from "@/components/ui/button";
import { Popover, PopoverContent, PopoverTrigger } from "@/components/ui/popover";

const categories = [
  {
    label: "Granny's Route Premium",
    icon: Star,
    color: 'text-primary',
    items: [
      { emoji: '🛡️', name: "Granny's Route", url: '#', comingSoon: true },
    ],
  },
  {
    label: 'Digital Downloads',
    icon: ShoppingCart,
    color: 'text-accent',
    items: [
      { emoji: '🛍️', name: 'RVBridgeSafe on Gumroad', url: 'https://gumroad.com/l/rvbridgesafe' },
    ],
  },
  {
    label: 'Fuel Savings',
    icon: Fuel,
    color: 'text-accent',
    items: [
      { emoji: '⛽', name: 'GasBuddy', url: 'https://www.gasbuddy.com/' },
      { emoji: '💸', name: 'Upside', url: 'https://www.upside.com/' },
    ],
  },
  {
    label: 'Mobile & Connectivity',
    icon: Smartphone,
    color: 'text-primary',
    items: [
      { emoji: '📱', name: 'Visible by Verizon', url: 'https://www.visible.com/' },
    ],
  },
  {
    label: 'RV Supplies & Gear',
    icon: Package,
    color: 'text-foreground',
    items: [
      { emoji: '📦', name: 'Amazon RV Essentials', url: 'https://www.amazon.com/s?k=rv+essentials' },
      { emoji: '🛒', name: 'Walmart RV Accessories', url: 'https://www.walmart.com/cp/rv-accessories/1231459' },
    ],
  },
];

export default function GearPopover() {
  return (
    <Popover>
      <PopoverTrigger asChild>
        <Button variant="ghost" size="sm" className="font-body text-sm gap-1.5">
          <ShoppingBag className="w-4 h-4" />
          Gear, Gas, & Grub
          <ChevronDown className="w-3.5 h-3.5" />
        </Button>
      </PopoverTrigger>
      <PopoverContent className="w-72 p-0" align="start">
        {/* Header */}
        <div className="px-3 py-2.5 border-b border-border flex items-center justify-between">
          <span className="font-heading text-sm font-semibold text-foreground">Quick Access</span>
          <Link to="/gear">
            <Button variant="ghost" size="sm" className="text-xs font-body gap-1 h-7 px-2 text-primary">
              View All <ArrowRight className="w-3 h-3" />
            </Button>
          </Link>
        </div>

        {/* Categorized links */}
        <div className="py-1.5 max-h-[420px] overflow-y-auto">
          {categories.map((cat) => (
            <div key={cat.label} className="mb-1">
              {/* Subcategory label */}
              <div className="flex items-center gap-1.5 px-3 pt-2 pb-1">
                <cat.icon className={`w-3 h-3 ${cat.color}`} />
                <span className="text-[11px] font-body font-semibold uppercase tracking-wider text-muted-foreground">
                  {cat.label}
                </span>
              </div>
              {/* Items */}
              {cat.items.map((item) =>
                item.comingSoon ? (
                  <div
                    key={item.name}
                    className="flex items-center gap-3 px-3 py-1.5 opacity-50 cursor-default"
                  >
                    <span className="text-base">{item.emoji}</span>
                    <span className="text-sm font-body text-foreground flex-1">{item.name}</span>
                    <span className="text-[10px] font-body text-muted-foreground">Soon</span>
                  </div>
                ) : (
                  <a
                    key={item.name}
                    href={item.url}
                    target="_blank"
                    rel="noopener noreferrer"
                    className="flex items-center gap-3 px-3 py-1.5 rounded-lg mx-1 hover:bg-secondary transition-colors group"
                  >
                    <span className="text-base">{item.emoji}</span>
                    <span className="text-sm font-body text-foreground flex-1 truncate">{item.name}</span>
                    <ExternalLink className="w-3 h-3 text-muted-foreground opacity-0 group-hover:opacity-100 transition-opacity shrink-0" />
                  </a>
                )
              )}
            </div>
          ))}
        </div>
      </PopoverContent>
    </Popover>
  );
}