import React from 'react';
import { Shield, Heart } from 'lucide-react';

export default function Footer() {
  return (
    <footer className="bg-foreground/5 border-t border-border mt-auto">
      <div className="max-w-7xl mx-auto px-4 sm:px-6 lg:px-8 py-24">
        <div className="grid grid-cols-1 md:grid-cols-3 gap-16">
          <div>
            <div className="flex items-center gap-4 mb-6">
              <span className="font-heading text-3xl font-semibold">RVBridgeSafe</span>
            </div>
            <p className="text-lg text-muted-foreground font-body leading-relaxed">
              Built by RVers, for RVers. Because getting home safe is the whole point of the adventure, sweetheart.
            </p>
          </div>
          <div>
            <h4 className="font-heading text-xl font-semibold mb-6">Quick Links</h4>
            <ul className="space-y-4 text-lg text-muted-foreground font-body">
              <li>Route Planner</li>
              <li>Community Reports</li>
              <li>My Rig Profile</li>
              <li>Offline Maps</li>
            </ul>
          </div>
          <div>
            <h4 className="font-heading text-xl font-semibold mb-6">Community</h4>
            <ul className="space-y-4 text-lg text-muted-foreground font-body">
              <li>50,000+ Active RVers</li>
              <li>500,000+ Verified Bridges</li>
              <li>Updated Monthly</li>
              <li>DOT Data + Crowd-Sourced</li>
            </ul>
          </div>
        </div>
        <div className="border-t border-border mt-16 pt-12 flex flex-col sm:flex-row items-center justify-between gap-6">
          <p className="text-base text-muted-foreground font-body sm:w-1/3 text-center sm:text-left">
            © 2026 RVBridgeSafe.app — All rights reserved
          </p>
          <div className="flex justify-center sm:w-1/3">
            <img src="https://media.base44.com/images/public/69f80fae4d57b1fce069e110/7a24949d0_routelogo.png" alt="Granny's Route Logo" className="w-24 h-24 object-contain drop-shadow-md" />
          </div>
          <p className="text-base text-muted-foreground font-body flex items-center justify-center sm:justify-end gap-2 sm:w-1/3">
            Faith Gratitude Peace of Mind
          </p>
        </div>
      </div>
    </footer>
  );
}