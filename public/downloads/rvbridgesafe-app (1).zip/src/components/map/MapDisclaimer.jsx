import React, { useState } from 'react';
import { AlertTriangle, ChevronDown, ChevronUp, ExternalLink } from 'lucide-react';

export default function MapDisclaimer() {
  const [expanded, setExpanded] = useState(false);

  return (
    <div className="bg-amber-50 border border-amber-300 rounded-xl p-4 font-body">
      <div className="flex items-center gap-2 bg-red-100 border border-red-300 rounded-lg px-3 py-2 mb-3">
        <AlertTriangle className="w-4 h-4 text-red-600 shrink-0" />
        <p className="text-xs font-bold text-red-800 uppercase tracking-wide">
          Always visually confirm clearance before proceeding — never rely solely on this app.
        </p>
      </div>
      <button
        className="w-full flex items-start gap-3 text-left"
        onClick={() => setExpanded(!expanded)}
      >
        <AlertTriangle className="w-5 h-5 text-amber-600 shrink-0 mt-0.5" />
        <div className="flex-1">
          <p className="text-sm font-semibold text-amber-900">
            ⚠️ Data Sources & Liability Disclaimer — Please Read
          </p>
          <p className="text-xs text-amber-700 mt-0.5">
            Bridge clearance data is sourced from U.S. DOT / FHWA and community reports. Tap to read full disclaimer.
          </p>
        </div>
        {expanded
          ? <ChevronUp className="w-4 h-4 text-amber-600 shrink-0 mt-0.5" />
          : <ChevronDown className="w-4 h-4 text-amber-600 shrink-0 mt-0.5" />
        }
      </button>

      {expanded && (
        <div className="mt-4 space-y-3 text-xs text-amber-900 leading-relaxed border-t border-amber-200 pt-4">
          <p>
            <strong>Data Sources:</strong> Hazard and clearance data displayed on this map is sourced from the following public resources:
          </p>
          <ul className="list-disc pl-4 space-y-1">
            <li>U.S. Department of Transportation (DOT) — <a href="https://www.transportation.gov" target="_blank" rel="noopener noreferrer" className="underline inline-flex items-center gap-0.5">transportation.gov <ExternalLink className="w-3 h-3" /></a></li>
            <li>Federal Highway Administration (FHWA) National Bridge Inventory (NBI) — <a href="https://www.fhwa.dot.gov/bridge/nbi.cfm" target="_blank" rel="noopener noreferrer" className="underline inline-flex items-center gap-0.5">fhwa.dot.gov <ExternalLink className="w-3 h-3" /></a></li>
            <li>State DOT databases and publicly available bridge inspection records</li>
            <li>Community-submitted reports from RVBridgeSafe.app users</li>
          </ul>
          <p>
            <strong>⚠️ NO WARRANTY — LIMITATION OF LIABILITY:</strong> RVBridgeSafe.app, its owners, operators, developers, and affiliates make <strong>NO representations, warranties, or guarantees</strong> — express or implied — regarding the accuracy, completeness, timeliness, or fitness for a particular purpose of any bridge clearance, hazard, or road data displayed on this platform.
          </p>
          <p>
            Bridge clearances can change due to road resurfacing, infrastructure repairs, signage errors, seasonal conditions, or measurement discrepancies. Posted clearance heights may differ from actual physical clearance. <strong>Always visually confirm clearance before proceeding.</strong>
          </p>
          <p>
            <strong>BY USING THIS APP YOU ACKNOWLEDGE AND AGREE</strong> that RVBridgeSafe.app shall not be held liable for any property damage, vehicle damage, personal injury, death, financial loss, or any other harm arising from reliance on data displayed in this application. Use of this application does not replace the need for driver judgment, professional guidance, or verification of clearances in person.
          </p>
          <p>
            DOT data is provided under public domain. Community reports reflect individual user experiences and are not independently verified unless marked "DOT Verified."
          </p>
          <p className="font-semibold">
            RVBridgeSafe.app assumes ZERO liability for bridge strikes, vehicle damage, or any incident. Always drive to conditions. Your safety is your responsibility.
          </p>
        </div>
      )}
    </div>
  );
}