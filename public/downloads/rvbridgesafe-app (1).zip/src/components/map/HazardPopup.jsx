import React from 'react';
import { Badge } from "@/components/ui/badge";
import { Button } from "@/components/ui/button";
import { CheckCircle, AlertTriangle, ShieldAlert, ArrowUpCircle, ThumbsUp, MapPin, ExternalLink } from 'lucide-react';
import { formatDistanceToNow } from 'date-fns';

const typeLabels = {
  low_clearance: 'Low Clearance',
  close_call: 'Close Call',
  bridge_strike: 'Bridge Strike',
  tight_turn: 'Tight Turn',
  steep_grade: 'Steep Grade',
  weight_restriction: 'Weight Restriction',
  road_closed: 'Road Closed',
};

const severityConfig = {
  danger: { color: 'text-red-600', bg: 'bg-red-50 border-red-200', icon: ShieldAlert, label: 'Danger' },
  warning: { color: 'text-amber-600', bg: 'bg-amber-50 border-amber-200', icon: AlertTriangle, label: 'Warning' },
  info: { color: 'text-blue-600', bg: 'bg-blue-50 border-blue-200', icon: ArrowUpCircle, label: 'Info' },
};

export default function HazardPopup({ report, onUpvote, onClose }) {
  if (!report) return null;
  const cfg = severityConfig[report.severity] || severityConfig.info;
  const Icon = cfg.icon;

  return (
    <div className="w-72 font-body">
      {/* Header */}
      <div className={`flex items-start gap-3 p-3 rounded-t-lg border-b ${cfg.bg}`}>
        <Icon className={`w-5 h-5 ${cfg.color} shrink-0 mt-0.5`} />
        <div className="flex-1 min-w-0">
          <p className="font-semibold text-sm text-gray-900 leading-snug">{report.title}</p>
          <p className="text-xs text-gray-500 flex items-center gap-1 mt-0.5">
            <MapPin className="w-3 h-3" />{report.location_name}
          </p>
        </div>
        <button onClick={onClose} className="text-gray-400 hover:text-gray-600 text-lg leading-none shrink-0">×</button>
      </div>

      {/* Body */}
      <div className="p-3 space-y-3 bg-white rounded-b-lg">
        <div className="flex flex-wrap gap-1.5">
          <Badge variant="secondary" className="text-xs">{typeLabels[report.report_type] || report.report_type}</Badge>
          <Badge className={`text-xs ${cfg.color} bg-transparent border`}>{cfg.label}</Badge>
          {report.verified && (
            <Badge className="text-xs bg-green-50 text-green-700 border-green-200 gap-1">
              <CheckCircle className="w-3 h-3" /> DOT Verified*
            </Badge>
          )}
        </div>

        {report.clearance_feet && (
          <div className="bg-gray-50 rounded-lg p-2.5 text-center">
            <p className="text-xs text-gray-500 uppercase tracking-wide mb-0.5">Posted Clearance</p>
            <p className="font-bold text-2xl text-gray-900">{report.clearance_feet}'{report.clearance_inches || 0}"</p>
            <p className="text-xs text-amber-600 mt-0.5">Always verify in person before passing</p>
          </div>
        )}

        {report.description && (
          <p className="text-xs text-gray-600 leading-relaxed">{report.description}</p>
        )}

        <div className="flex items-center justify-between pt-1 border-t border-gray-100">
          <p className="text-xs text-gray-400">
            {formatDistanceToNow(new Date(report.created_date), { addSuffix: true })}
          </p>
          <Button
            variant="ghost"
            size="sm"
            className="text-xs h-7 gap-1 px-2"
            onClick={() => onUpvote(report)}
          >
            <ThumbsUp className="w-3 h-3" />
            Helpful ({report.upvotes || 0})
          </Button>
        </div>

        {/* DOT Disclaimer */}
        <div className="bg-amber-50 border border-amber-200 rounded-lg p-2">
          <p className="text-xs text-amber-800 leading-relaxed">
            <span className="font-semibold">* Data Source:</span> Clearance data is sourced from U.S. DOT / FHWA National Bridge Inventory and community reports. See full disclaimer below.
          </p>
        </div>
      </div>
    </div>
  );
}