import React from 'react';

const legendItems = [
  { color: '#dc2626', label: 'Bridge Strike', type: 'bridge_strike' },
  { color: '#f59e0b', label: 'Low Clearance', type: 'low_clearance' },
  { color: '#f97316', label: 'Close Call', type: 'close_call' },
  { color: '#8b5cf6', label: 'Weight Restriction', type: 'weight_restriction' },
  { color: '#3b82f6', label: 'Steep Grade', type: 'steep_grade' },
  { color: '#6b7280', label: 'Tight Turn / Road Closed', type: 'other' },
];

export default function MapLegend() {
  return (
    <div className="bg-white/95 backdrop-blur-sm rounded-xl border border-gray-200 shadow-lg p-4 font-body">
      <p className="text-xs font-semibold text-gray-700 uppercase tracking-wide mb-3">Hazard Legend</p>
      <div className="space-y-2">
        {legendItems.map((item) => (
          <div key={item.type} className="flex items-center gap-2.5">
            <div
              className="w-4 h-4 rounded-full border-2 border-white shadow-sm shrink-0"
              style={{ backgroundColor: item.color }}
            />
            <span className="text-xs text-gray-700">{item.label}</span>
          </div>
        ))}
      </div>
      <div className="mt-3 pt-3 border-t border-gray-100">
        <div className="flex items-center gap-2.5">
          <div className="w-4 h-4 rounded-full border-2 border-green-500 bg-green-100 flex items-center justify-center shrink-0">
            <div className="w-1.5 h-1.5 rounded-full bg-green-500" />
          </div>
          <span className="text-xs text-gray-700">DOT Verified</span>
        </div>
      </div>
    </div>
  );
}