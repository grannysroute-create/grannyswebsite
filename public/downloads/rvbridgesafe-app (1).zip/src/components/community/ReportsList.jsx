import React from 'react';
import { Card } from "@/components/ui/card";
import { Badge } from "@/components/ui/badge";
import { Button } from "@/components/ui/button";
import {
  AlertTriangle,
  ShieldAlert,
  ArrowUpCircle,
  ThumbsUp,
  MapPin,
  Clock,
  CheckCircle
} from 'lucide-react';
import { formatDistanceToNow } from 'date-fns';

const severityConfig = {
  danger: { color: 'bg-destructive/10 text-destructive', icon: ShieldAlert, label: 'Danger' },
  warning: { color: 'bg-accent/10 text-accent', icon: AlertTriangle, label: 'Warning' },
  info: { color: 'bg-primary/10 text-primary', icon: ArrowUpCircle, label: 'Info' },
};

const typeLabels = {
  low_clearance: 'Low Clearance',
  close_call: 'Close Call',
  bridge_strike: 'Bridge Strike',
  tight_turn: 'Tight Turn',
  steep_grade: 'Steep Grade',
  weight_restriction: 'Weight Restriction',
  road_closed: 'Road Closed',
};

export default function ReportsList({ reports, onUpvote }) {
  if (!reports || reports.length === 0) {
    return (
      <Card className="p-10 text-center">
        <AlertTriangle className="w-10 h-10 text-muted-foreground/30 mx-auto mb-3" />
        <p className="font-heading font-semibold mb-1">No reports yet</p>
        <p className="text-sm text-muted-foreground font-body">
          Be the first to help fellow RVers by reporting a hazard!
        </p>
      </Card>
    );
  }

  return (
    <div className="space-y-4">
      {reports.map((report) => {
        const config = severityConfig[report.severity] || severityConfig.info;
        const Icon = config.icon;
        return (
          <Card key={report.id} className="p-5 border-border hover:shadow-md transition-shadow">
            <div className="flex items-start gap-4">
              <div className={`w-10 h-10 rounded-xl ${config.color} flex items-center justify-center shrink-0`}>
                <Icon className="w-5 h-5" />
              </div>
              <div className="flex-1 min-w-0">
                <div className="flex items-start justify-between gap-2 mb-1">
                  <h4 className="font-body font-semibold text-foreground">{report.title}</h4>
                  <div className="flex items-center gap-2 shrink-0">
                    {report.verified && (
                      <Badge className="bg-primary/10 text-primary text-xs gap-1">
                        <CheckCircle className="w-3 h-3" /> Verified
                      </Badge>
                    )}
                    <Badge variant="secondary" className="text-xs">
                      {typeLabels[report.report_type] || report.report_type}
                    </Badge>
                  </div>
                </div>

                <div className="flex flex-wrap items-center gap-3 text-xs text-muted-foreground font-body mb-2">
                  <span className="flex items-center gap-1">
                    <MapPin className="w-3 h-3" />
                    {report.location_name}
                  </span>
                  {report.clearance_feet && (
                    <span>Clearance: {report.clearance_feet}'{report.clearance_inches || 0}"</span>
                  )}
                  <span className="flex items-center gap-1">
                    <Clock className="w-3 h-3" />
                    {formatDistanceToNow(new Date(report.created_date), { addSuffix: true })}
                  </span>
                </div>

                {report.description && (
                  <p className="text-sm text-muted-foreground font-body leading-relaxed">{report.description}</p>
                )}

                <div className="mt-3">
                  <Button
                    variant="ghost"
                    size="sm"
                    className="font-body text-xs gap-1.5 h-8"
                    onClick={() => onUpvote(report)}
                  >
                    <ThumbsUp className="w-3.5 h-3.5" />
                    Helpful ({report.upvotes || 0})
                  </Button>
                </div>
              </div>
            </div>
          </Card>
        );
      })}
    </div>
  );
}