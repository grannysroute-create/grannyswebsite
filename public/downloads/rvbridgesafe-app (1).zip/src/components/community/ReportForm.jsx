import React, { useState } from 'react';
import { Card } from "@/components/ui/card";
import { Button } from "@/components/ui/button";
import { Input } from "@/components/ui/input";
import { Label } from "@/components/ui/label";
import { Textarea } from "@/components/ui/textarea";
import { Select, SelectContent, SelectItem, SelectTrigger, SelectValue } from "@/components/ui/select";
import { AlertTriangle, Send, Loader2 } from 'lucide-react';

const reportTypes = [
  { value: 'low_clearance', label: 'Low Clearance' },
  { value: 'close_call', label: 'Close Call' },
  { value: 'bridge_strike', label: 'Bridge Strike' },
  { value: 'tight_turn', label: 'Tight Turn' },
  { value: 'steep_grade', label: 'Steep Grade' },
  { value: 'weight_restriction', label: 'Weight Restriction' },
  { value: 'road_closed', label: 'Road Closed' },
];

const severities = [
  { value: 'info', label: 'Info — Good to know' },
  { value: 'warning', label: 'Warning — Use caution' },
  { value: 'danger', label: 'Danger — Avoid!' },
];

export default function ReportForm({ onSubmit, isSubmitting }) {
  const [form, setForm] = useState({
    title: '',
    report_type: 'low_clearance',
    location_name: '',
    clearance_feet: '',
    clearance_inches: '',
    description: '',
    severity: 'warning',
  });

  const handleSubmit = (e) => {
    e.preventDefault();
    onSubmit({
      ...form,
      clearance_feet: Number(form.clearance_feet) || undefined,
      clearance_inches: Number(form.clearance_inches) || undefined,
    });
    setForm({
      title: '',
      report_type: 'low_clearance',
      location_name: '',
      clearance_feet: '',
      clearance_inches: '',
      description: '',
      severity: 'warning',
    });
  };

  const update = (field, value) => setForm(prev => ({ ...prev, [field]: value }));

  return (
    <Card className="p-6">
      <div className="flex items-center gap-2 mb-5">
        <AlertTriangle className="w-5 h-5 text-accent" />
        <h3 className="font-heading font-semibold text-foreground">Report a Hazard</h3>
      </div>
      <form onSubmit={handleSubmit} className="space-y-4">
        <div>
          <Label className="font-body text-sm">What happened?</Label>
          <Input
            placeholder="e.g., Low bridge on Hwy 52 near exit 14"
            value={form.title}
            onChange={(e) => update('title', e.target.value)}
            className="mt-1.5 rounded-xl font-body"
          />
        </div>
        <div className="grid grid-cols-2 gap-4">
          <div>
            <Label className="font-body text-sm">Type</Label>
            <Select value={form.report_type} onValueChange={(v) => update('report_type', v)}>
              <SelectTrigger className="mt-1.5 rounded-xl font-body">
                <SelectValue />
              </SelectTrigger>
              <SelectContent>
                {reportTypes.map(t => (
                  <SelectItem key={t.value} value={t.value} className="font-body">{t.label}</SelectItem>
                ))}
              </SelectContent>
            </Select>
          </div>
          <div>
            <Label className="font-body text-sm">Severity</Label>
            <Select value={form.severity} onValueChange={(v) => update('severity', v)}>
              <SelectTrigger className="mt-1.5 rounded-xl font-body">
                <SelectValue />
              </SelectTrigger>
              <SelectContent>
                {severities.map(s => (
                  <SelectItem key={s.value} value={s.value} className="font-body">{s.label}</SelectItem>
                ))}
              </SelectContent>
            </Select>
          </div>
        </div>
        <div>
          <Label className="font-body text-sm">Location</Label>
          <Input
            placeholder="e.g., I-95 near Jacksonville, FL"
            value={form.location_name}
            onChange={(e) => update('location_name', e.target.value)}
            className="mt-1.5 rounded-xl font-body"
          />
        </div>
        <div className="grid grid-cols-2 gap-4">
          <div>
            <Label className="font-body text-sm">Clearance (ft)</Label>
            <Input
              type="number"
              placeholder="12"
              value={form.clearance_feet}
              onChange={(e) => update('clearance_feet', e.target.value)}
              className="mt-1.5 rounded-xl font-body"
            />
          </div>
          <div>
            <Label className="font-body text-sm">Clearance (in)</Label>
            <Input
              type="number"
              placeholder="6"
              min="0"
              max="11"
              value={form.clearance_inches}
              onChange={(e) => update('clearance_inches', e.target.value)}
              className="mt-1.5 rounded-xl font-body"
            />
          </div>
        </div>
        <div>
          <Label className="font-body text-sm">Details</Label>
          <Textarea
            placeholder="Tell fellow RVers what they need to know..."
            value={form.description}
            onChange={(e) => update('description', e.target.value)}
            className="mt-1.5 rounded-xl font-body h-24"
          />
        </div>
        <Button
          type="submit"
          className="w-full rounded-xl font-body gap-2"
          disabled={isSubmitting || !form.title || !form.location_name}
        >
          {isSubmitting ? <Loader2 className="w-4 h-4 animate-spin" /> : <Send className="w-4 h-4" />}
          Submit Report
        </Button>
      </form>
    </Card>
  );
}