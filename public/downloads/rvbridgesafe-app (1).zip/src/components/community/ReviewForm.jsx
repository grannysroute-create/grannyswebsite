import React, { useState } from 'react';
import { Card } from "@/components/ui/card";
import { Button } from "@/components/ui/button";
import { Input } from "@/components/ui/input";
import { Label } from "@/components/ui/label";
import { Textarea } from "@/components/ui/textarea";
import { Star, Send, Loader2 } from 'lucide-react';

export default function ReviewForm({ onSubmit, isSubmitting }) {
  const [form, setForm] = useState({
    author_name: '',
    rig_type: '',
    home_state: '',
    years_rving: '',
    rating: 0,
    title: '',
    body: '',
  });
  const [hovered, setHovered] = useState(0);

  const update = (field, value) => setForm(prev => ({ ...prev, [field]: value }));

  const handleSubmit = (e) => {
    e.preventDefault();
    onSubmit({
      ...form,
      years_rving: Number(form.years_rving) || 0,
      rating: form.rating,
    });
    setForm({ author_name: '', rig_type: '', home_state: '', years_rving: '', rating: 0, title: '', body: '' });
  };

  return (
    <Card className="p-6">
      <div className="flex items-center gap-2 mb-5">
        <Star className="w-5 h-5 text-accent fill-accent" />
        <h3 className="font-heading font-semibold text-foreground">Write a Review</h3>
      </div>

      <form onSubmit={handleSubmit} className="space-y-4">
        {/* Star Rating */}
        <div>
          <Label className="font-body text-sm mb-2 block">Your Rating</Label>
          <div className="flex gap-1">
            {[1, 2, 3, 4, 5].map((star) => (
              <button
                key={star}
                type="button"
                onMouseEnter={() => setHovered(star)}
                onMouseLeave={() => setHovered(0)}
                onClick={() => update('rating', star)}
              >
                <Star
                  className={`w-7 h-7 transition-colors ${
                    star <= (hovered || form.rating) ? 'text-accent fill-accent' : 'text-muted-foreground/30'
                  }`}
                />
              </button>
            ))}
          </div>
        </div>

        <div className="grid grid-cols-2 gap-4">
          <div>
            <Label className="font-body text-sm">Your Name</Label>
            <Input
              placeholder="e.g., Linda M."
              value={form.author_name}
              onChange={(e) => update('author_name', e.target.value)}
              className="mt-1.5 rounded-xl font-body"
            />
          </div>
          <div>
            <Label className="font-body text-sm">Home State</Label>
            <Input
              placeholder="e.g., Texas"
              value={form.home_state}
              onChange={(e) => update('home_state', e.target.value)}
              className="mt-1.5 rounded-xl font-body"
            />
          </div>
          <div>
            <Label className="font-body text-sm">Rig Type</Label>
            <Input
              placeholder="e.g., Class A, 5th Wheel"
              value={form.rig_type}
              onChange={(e) => update('rig_type', e.target.value)}
              className="mt-1.5 rounded-xl font-body"
            />
          </div>
          <div>
            <Label className="font-body text-sm">Years RVing</Label>
            <Input
              type="number"
              placeholder="e.g., 5"
              value={form.years_rving}
              onChange={(e) => update('years_rving', e.target.value)}
              className="mt-1.5 rounded-xl font-body"
            />
          </div>
        </div>

        <div>
          <Label className="font-body text-sm">Review Title</Label>
          <Input
            placeholder="e.g., Saved me from a close call!"
            value={form.title}
            onChange={(e) => update('title', e.target.value)}
            className="mt-1.5 rounded-xl font-body"
          />
        </div>

        <div>
          <Label className="font-body text-sm">Your Story</Label>
          <Textarea
            placeholder="Tell the community about your experience..."
            value={form.body}
            onChange={(e) => update('body', e.target.value)}
            className="mt-1.5 rounded-xl font-body h-28"
          />
        </div>

        <Button
          type="submit"
          className="w-full rounded-xl font-body gap-2"
          disabled={isSubmitting || !form.author_name || !form.body || form.rating === 0}
        >
          {isSubmitting ? <Loader2 className="w-4 h-4 animate-spin" /> : <Send className="w-4 h-4" />}
          Submit Review
        </Button>
      </form>
    </Card>
  );
}