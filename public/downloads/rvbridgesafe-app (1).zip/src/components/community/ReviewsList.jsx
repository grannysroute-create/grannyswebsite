import React from 'react';
import { Card } from "@/components/ui/card";
import { Badge } from "@/components/ui/badge";
import { Button } from "@/components/ui/button";
import { Star, ThumbsUp, MapPin, Clock, CheckCircle, MessageSquare } from 'lucide-react';
import { formatDistanceToNow } from 'date-fns';

function StarRating({ count }) {
  return (
    <div className="flex gap-0.5">
      {[...Array(5)].map((_, i) => (
        <Star key={i} className={`w-3.5 h-3.5 ${i < count ? 'text-accent fill-accent' : 'text-muted-foreground/20'}`} />
      ))}
    </div>
  );
}

export default function ReviewsList({ reviews, onHelpful }) {
  if (!reviews || reviews.length === 0) {
    return (
      <Card className="p-10 text-center">
        <MessageSquare className="w-10 h-10 text-muted-foreground/30 mx-auto mb-3" />
        <p className="font-heading font-semibold mb-1">No reviews yet — be the first!</p>
        <p className="text-sm text-muted-foreground font-body">
          Share your experience and help other RVers make a great decision.
        </p>
      </Card>
    );
  }

  return (
    <div className="space-y-4">
      {reviews.map((review) => (
        <Card key={review.id} className="p-6 border-border hover:shadow-md transition-shadow">
          <div className="flex items-start justify-between gap-3 mb-3">
            <div>
              <div className="flex items-center gap-2 mb-1">
                <StarRating count={review.rating} />
                {review.verified_purchase && (
                  <Badge className="bg-primary/10 text-primary text-xs gap-1 font-body">
                    <CheckCircle className="w-3 h-3" /> Verified
                  </Badge>
                )}
              </div>
              {review.title && (
                <h4 className="font-heading font-semibold text-foreground">{review.title}</h4>
              )}
            </div>
            <div className="text-right text-xs text-muted-foreground font-body shrink-0">
              <p className="flex items-center gap-1 justify-end">
                <Clock className="w-3 h-3" />
                {formatDistanceToNow(new Date(review.created_date), { addSuffix: true })}
              </p>
            </div>
          </div>

          <p className="text-sm font-body text-foreground leading-relaxed mb-4">{review.body}</p>

          <div className="flex items-center justify-between">
            <div className="flex flex-wrap items-center gap-3 text-xs text-muted-foreground font-body">
              <span className="font-semibold text-foreground">{review.author_name}</span>
              {review.rig_type && <span>· {review.rig_type}</span>}
              {review.home_state && (
                <span className="flex items-center gap-1">
                  <MapPin className="w-3 h-3" />{review.home_state}
                </span>
              )}
              {review.years_rving > 0 && <span>· {review.years_rving} yrs RVing</span>}
            </div>
            <Button
              variant="ghost"
              size="sm"
              className="font-body text-xs gap-1.5 h-8 shrink-0"
              onClick={() => onHelpful(review)}
            >
              <ThumbsUp className="w-3.5 h-3.5" />
              Helpful ({review.helpful_votes || 0})
            </Button>
          </div>
        </Card>
      ))}
    </div>
  );
}