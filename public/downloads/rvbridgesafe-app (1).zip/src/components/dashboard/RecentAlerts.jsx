import React from 'react';
import { Card } from "@/components/ui/card";
import { Badge } from "@/components/ui/badge";
import { AlertTriangle, ArrowUpCircle, ShieldAlert, Construction, ChevronRight } from 'lucide-react';
import { format } from 'date-fns';

const severityConfig = {
  danger: { color: 'bg-destructive/10 text-destructive border-destructive/20', icon: ShieldAlert },
  warning: { color: 'bg-accent/10 text-accent border-accent/20', icon: AlertTriangle },
  info: { color: 'bg-primary/10 text-primary border-primary/20', icon: ArrowUpCircle },
};

export default function RecentAlerts({ reports }) {
  if (!reports || reports.length === 0) {
    return (
      <Card className="p-8 text-center">
        <Construction className="w-10 h-10 text-muted-foreground/40 mx-auto mb-3" />
        <p className="font-heading font-semibold text-foreground mb-1">All clear, sweetheart!</p>
        <p className="text-sm text-muted-foreground font-body">No active alerts in your area right now.</p>
      </Card>
    );
  }

  return (
    <div className="space-y-3">
      {reports.slice(0, 5).map((report) => {
        const config = severityConfig[report.severity] || severityConfig.info;
        const Icon = config.icon;
        return (
          <Card key={report.id} className="p-4 border-border hover:shadow-md transition-shadow cursor-pointer">
            <div className="flex items-start gap-3">
              <div className={`w-9 h-9 rounded-lg ${config.color} flex items-center justify-center shrink-0`}>
                <Icon className="w-4 h-4" />
              </div>
              <div className="flex-1 min-w-0">
                <div className="flex items-center gap-2 mb-1">
                  <p className="font-body font-semibold text-sm text-foreground truncate">{report.title}</p>
                  {report.verified && (
                    <Badge variant="secondary" className="text-xs shrink-0">Verified</Badge>
                  )}
                </div>
                <p className="text-xs text-muted-foreground font-body">{report.location_name}</p>
                {report.clearance_feet && (
                  <p className="text-xs text-muted-foreground font-body mt-1">
                    Clearance: {report.clearance_feet}'{report.clearance_inches || 0}"
                  </p>
                )}
              </div>
              <ChevronRight className="w-4 h-4 text-muted-foreground shrink-0 mt-1" />
            </div>
          </Card>
        );
      })}
    </div>
  );
}