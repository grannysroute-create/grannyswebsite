import React from 'react';
import { Link } from 'react-router-dom';
import { Button } from "@/components/ui/button";
import { Crown, ArrowRight, Zap } from 'lucide-react';

export default function UpgradeBanner() {
  return (
    <div className="rounded-2xl bg-gradient-to-r from-accent/90 to-accent p-5 flex flex-col sm:flex-row items-center justify-between gap-4">
      <div className="flex items-center gap-3">
        <div className="w-10 h-10 rounded-xl bg-white/20 flex items-center justify-center shrink-0">
          <Crown className="w-5 h-5 text-white" />
        </div>
        <div>
          <p className="font-heading font-semibold text-white text-sm">Granny's Route — Coming Soon</p>
          <p className="text-white/80 text-xs font-body">Real-time alerts, offline maps, AI routing — join the waitlist!</p>
        </div>
      </div>
      <div className="flex gap-2 shrink-0">
        <a href="https://grannysroute.org" target="_blank" rel="noopener noreferrer">
          <Button size="sm" className="bg-white text-accent hover:bg-white/90 rounded-xl font-body gap-2 font-semibold">
            GrannysRoute.org <ArrowRight className="w-3.5 h-3.5" />
          </Button>
        </a>
        <Link to="/upgrade">
          <Button size="sm" variant="ghost" className="text-white hover:bg-white/20 rounded-xl font-body text-xs">
            Learn More
          </Button>
        </Link>
      </div>
    </div>
  );
}