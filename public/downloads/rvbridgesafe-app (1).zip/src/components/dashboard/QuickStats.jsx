import React from 'react';
import { Card } from "@/components/ui/card";
import { Shield, Route, AlertTriangle, Users } from 'lucide-react';

const stats = [
  { label: 'Hazards Avoided', value: '23', icon: Shield, color: 'bg-primary/10 text-primary' },
  { label: 'Miles Traveled', value: '4,280', icon: Route, color: 'bg-accent/10 text-accent' },
  { label: 'Active Alerts', value: '3', icon: AlertTriangle, color: 'bg-destructive/10 text-destructive' },
  { label: 'Community Tips', value: '156', icon: Users, color: 'bg-primary/10 text-primary' },
];

export default function QuickStats() {
  return (
    <div className="grid grid-cols-2 lg:grid-cols-4 gap-4">
      {stats.map((stat, i) => (
        <Card key={i} className="p-5 border-border hover:shadow-md transition-shadow">
          <div className="flex items-start justify-between mb-3">
            <div className={`w-10 h-10 rounded-xl ${stat.color} flex items-center justify-center`}>
              <stat.icon className="w-5 h-5" />
            </div>
          </div>
          <p className="font-heading text-2xl font-bold text-foreground">{stat.value}</p>
          <p className="text-xs text-muted-foreground font-body mt-1">{stat.label}</p>
        </Card>
      ))}
    </div>
  );
}