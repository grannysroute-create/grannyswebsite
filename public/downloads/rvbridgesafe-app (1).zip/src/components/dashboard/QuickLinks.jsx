import React from 'react';
import { Card } from "@/components/ui/card";
import { Cloud, ShieldCheck, Users } from 'lucide-react';

const links = [
  {
    icon: Cloud,
    label: 'Weather',
    description: 'Road conditions & forecast',
    color: 'bg-primary/10 text-primary',
    url: 'https://www.weather.gov/',
  },
  {
    icon: ShieldCheck,
    label: 'Safety Rating',
    description: 'Bridge & route safety score',
    color: 'bg-accent/10 text-accent',
    url: '#safety-rating',
    internal: true,
  },
  {
    icon: Users,
    label: 'Location Sharing',
    description: 'Share with family & travelers',
    color: 'bg-primary/10 text-primary',
    url: '#location-sharing',
    internal: true,
    comingSoon: true,
  },
];

export default function QuickLinks() {
  return (
    <div className="mb-6">
      <h2 className="font-heading text-lg font-semibold text-foreground mb-3">Quick Access</h2>
      <div className="grid grid-cols-1 sm:grid-cols-3 gap-4">
        {links.map((link, i) => (
          <a
            key={i}
            href={link.internal || link.comingSoon ? undefined : link.url}
            target={link.internal || link.comingSoon ? undefined : '_blank'}
            rel="noopener noreferrer"
            className={`block ${link.comingSoon ? 'cursor-default' : 'cursor-pointer'}`}
          >
            <Card className="p-4 border-border hover:shadow-md hover:border-primary/20 transition-all duration-200 flex items-center gap-4">
              <div className={`w-10 h-10 rounded-xl ${link.color} flex items-center justify-center shrink-0`}>
                <link.icon className="w-5 h-5" />
              </div>
              <div className="flex-1 min-w-0">
                <p className="font-body font-semibold text-sm text-foreground">
                  {link.label}
                  {link.comingSoon && (
                    <span className="ml-2 text-xs text-muted-foreground font-normal">(Coming Soon)</span>
                  )}
                </p>
                <p className="text-xs text-muted-foreground font-body truncate">{link.description}</p>
              </div>
            </Card>
          </a>
        ))}
      </div>
    </div>
  );
}