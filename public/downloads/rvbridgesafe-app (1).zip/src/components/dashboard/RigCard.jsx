import React from 'react';
import { Link } from 'react-router-dom';
import { Card } from "@/components/ui/card";
import { Button } from "@/components/ui/button";
import { Badge } from "@/components/ui/badge";
import { Truck, Ruler, Weight, ArrowRight, Plus, Flame } from 'lucide-react';

const rigTypeLabels = {
  motorhome_class_a: 'Class A Motorhome',
  motorhome_class_b: 'Class B Motorhome',
  motorhome_class_c: 'Class C Motorhome',
  fifth_wheel: 'Fifth Wheel',
  travel_trailer: 'Travel Trailer',
  truck_camper: 'Truck Camper',
  toy_hauler: 'Toy Hauler'
};

export default function RigCard({ rig }) {
  if (!rig) {
    return (
      <Card className="p-8 border-dashed border-2 border-border flex flex-col items-center justify-center text-center">
        <div className="w-14 h-14 rounded-2xl bg-secondary flex items-center justify-center mb-4">
          <Plus className="w-6 h-6 text-muted-foreground" />
        </div>
        <h3 className="font-heading text-lg font-semibold mb-2">No rig set up yet, hon!</h3>
        <p className="text-sm text-muted-foreground font-body mb-4">
          Tell us about your rig so we can keep you safe on the road.
        </p>
        <Link to="/rig-profile">
          <Button className="gap-2 rounded-xl font-body">
            Set Up My Rig
            <ArrowRight className="w-4 h-4" />
          </Button>
        </Link>
      </Card>
    );
  }

  const totalHeight = (rig.height_feet || 0) + (rig.height_inches || 0) / 12;

  return (
    <Card className="p-6 border-border">
      <div className="flex items-start justify-between mb-4">
        <div>
          <h3 className="font-heading text-lg font-semibold text-foreground">{rig.rig_name}</h3>
          <p className="text-sm text-muted-foreground font-body">{rigTypeLabels[rig.rig_type] || rig.rig_type}</p>
        </div>
        <Badge variant="secondary" className="bg-primary/10 text-primary">
          <Truck className="w-3 h-3 mr-1" /> Active
        </Badge>
      </div>
      <div className="grid grid-cols-2 gap-4 mb-4">
        <div className="flex items-center gap-2">
          <Ruler className="w-4 h-4 text-muted-foreground" />
          <div>
            <p className="text-xs text-muted-foreground font-body">Height</p>
            <p className="font-body font-semibold text-sm">{rig.height_feet}'{rig.height_inches || 0}"</p>
          </div>
        </div>
        <div className="flex items-center gap-2">
          <Ruler className="w-4 h-4 text-muted-foreground rotate-90" />
          <div>
            <p className="text-xs text-muted-foreground font-body">Length</p>
            <p className="font-body font-semibold text-sm">{rig.length_feet || '—'} ft</p>
          </div>
        </div>
        <div className="flex items-center gap-2">
          <Weight className="w-4 h-4 text-muted-foreground" />
          <div>
            <p className="text-xs text-muted-foreground font-body">Weight</p>
            <p className="font-body font-semibold text-sm">{rig.weight_lbs ? `${rig.weight_lbs.toLocaleString()} lbs` : '—'}</p>
          </div>
        </div>
        <div className="flex items-center gap-2">
          <Flame className="w-4 h-4 text-muted-foreground" />
          <div>
            <p className="text-xs text-muted-foreground font-body">Propane</p>
            <p className="font-body font-semibold text-sm">{rig.has_propane ? 'Yes' : 'No'}</p>
          </div>
        </div>
      </div>
      <Link to="/rig-profile">
        <Button variant="outline" size="sm" className="w-full rounded-xl font-body">Edit Rig Profile</Button>
      </Link>
    </Card>
  );
}