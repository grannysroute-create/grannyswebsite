import React from 'react';
import { Card } from "@/components/ui/card";
import { Badge } from "@/components/ui/badge";
import { Button } from "@/components/ui/button";
import { motion } from 'framer-motion';
import {
  ShieldCheck,
  AlertTriangle,
  Clock,
  Route as RouteIcon,
  Fuel,
  Mountain,
  Save,
  ChevronRight,
  Loader2
} from 'lucide-react';
import OfflineDownloadButton from './OfflineDownloadButton';

export default function RouteResult({ result, onSave, isSaving, saveDisabled, origin, destination }) {
  if (!result) return null;

  return (
    <motion.div
      initial={{ opacity: 0, y: 20 }}
      animate={{ opacity: 1, y: 0 }}
      className="space-y-4"
    >
      <Card className="p-6 border-primary/20 bg-primary/5">
        <div className="flex items-center gap-3 mb-4">
          <div className="w-10 h-10 rounded-xl bg-primary/10 flex items-center justify-center">
            <ShieldCheck className="w-5 h-5 text-primary" />
          </div>
          <div>
            <h3 className="font-heading font-semibold text-foreground">RV-Safe Route Found!</h3>
            <p className="text-xs text-muted-foreground font-body">Optimized for your rig's dimensions</p>
          </div>
        </div>

        <div className="grid grid-cols-3 gap-4 mb-4">
          <div className="text-center p-3 rounded-xl bg-card">
            <RouteIcon className="w-4 h-4 text-primary mx-auto mb-1" />
            <p className="font-heading font-bold text-lg">{result.distance}</p>
            <p className="text-xs text-muted-foreground font-body">miles</p>
          </div>
          <div className="text-center p-3 rounded-xl bg-card">
            <Clock className="w-4 h-4 text-accent mx-auto mb-1" />
            <p className="font-heading font-bold text-lg">{result.time}</p>
            <p className="text-xs text-muted-foreground font-body">hours</p>
          </div>
          <div className="text-center p-3 rounded-xl bg-card">
            <Fuel className="w-4 h-4 text-primary mx-auto mb-1" />
            <p className="font-heading font-bold text-lg">{result.fuelStops}</p>
            <p className="text-xs text-muted-foreground font-body">fuel stops</p>
          </div>
        </div>

        <Button onClick={onSave} variant="outline" className="w-full rounded-xl font-body gap-2" disabled={isSaving || saveDisabled}>
          {isSaving ? <Loader2 className="w-4 h-4 animate-spin" /> : <Save className="w-4 h-4" />}
          {saveDisabled ? 'Trip Limit Reached (2 max)' : 'Save This Route'}
        </Button>
        <OfflineDownloadButton origin={origin} destination={destination} result={result} />
      </Card>

      {/* Hazards avoided */}
      <Card className="p-5">
        <h4 className="font-heading font-semibold mb-3 flex items-center gap-2">
          <AlertTriangle className="w-4 h-4 text-accent" />
          Hazards We Routed Around ({result.hazards.length})
        </h4>
        <div className="space-y-2">
          {result.hazards.map((h, i) => (
            <div key={i} className="flex items-center gap-3 p-3 rounded-xl bg-secondary/50">
              <div className="w-8 h-8 rounded-lg bg-accent/10 flex items-center justify-center shrink-0">
                {h.type === 'bridge' && <AlertTriangle className="w-4 h-4 text-accent" />}
                {h.type === 'grade' && <Mountain className="w-4 h-4 text-accent" />}
                {h.type === 'tunnel' && <AlertTriangle className="w-4 h-4 text-destructive" />}
              </div>
              <div className="flex-1 min-w-0">
                <p className="text-sm font-body font-medium text-foreground">{h.name}</p>
                <p className="text-xs text-muted-foreground font-body">{h.detail}</p>
              </div>
              <Badge variant="secondary" className="shrink-0 text-xs">{h.clearance || h.info}</Badge>
            </div>
          ))}
        </div>
      </Card>
    </motion.div>
  );
}