import React, { useEffect, useState } from 'react';
import { MapContainer, TileLayer, Marker, Popup, Polyline, useMap } from 'react-leaflet';
import { Card } from "@/components/ui/card";
import { MapPin, Navigation, Loader2 } from 'lucide-react';
import 'leaflet/dist/leaflet.css';
import L from 'leaflet';

// Fix default marker icons for Leaflet + Vite
delete L.Icon.Default.prototype._getIconUrl;
L.Icon.Default.mergeOptions({
  iconRetinaUrl: 'https://unpkg.com/leaflet@1.9.4/dist/images/marker-icon-2x.png',
  iconUrl: 'https://unpkg.com/leaflet@1.9.4/dist/images/marker-icon.png',
  shadowUrl: 'https://unpkg.com/leaflet@1.9.4/dist/images/marker-shadow.png',
});

const originIcon = new L.Icon({
  iconUrl: 'https://raw.githubusercontent.com/pointhi/leaflet-color-markers/master/img/marker-icon-2x-green.png',
  shadowUrl: 'https://unpkg.com/leaflet@1.9.4/dist/images/marker-shadow.png',
  iconSize: [25, 41], iconAnchor: [12, 41], popupAnchor: [1, -34], shadowSize: [41, 41],
});

const destIcon = new L.Icon({
  iconUrl: 'https://raw.githubusercontent.com/pointhi/leaflet-color-markers/master/img/marker-icon-2x-red.png',
  shadowUrl: 'https://unpkg.com/leaflet@1.9.4/dist/images/marker-shadow.png',
  iconSize: [25, 41], iconAnchor: [12, 41], popupAnchor: [1, -34], shadowSize: [41, 41],
});

function FitBounds({ coords }) {
  const map = useMap();
  useEffect(() => {
    if (coords.length >= 2) {
      map.fitBounds(coords, { padding: [50, 50] });
    }
  }, [coords, map]);
  return null;
}

async function geocode(place) {
  const res = await fetch(
    `https://nominatim.openstreetmap.org/search?format=json&q=${encodeURIComponent(place)}&limit=1`,
    { headers: { 'Accept-Language': 'en' } }
  );
  const data = await res.json();
  if (data.length === 0) return null;
  return [parseFloat(data[0].lat), parseFloat(data[0].lon)];
}

async function getRoute(from, to) {
  const url = `https://router.project-osrm.org/route/v1/driving/${from[1]},${from[0]};${to[1]},${to[0]}?overview=full&geometries=geojson`;
  const res = await fetch(url);
  const data = await res.json();
  if (data.routes?.length > 0) {
    return data.routes[0].geometry.coordinates.map(([lng, lat]) => [lat, lng]);
  }
  return [from, to];
}

export default function RouteMap({ origin, destination, onRouteLine }) {
  const [originCoords, setOriginCoords] = useState(null);
  const [destCoords, setDestCoords] = useState(null);
  const [routeLine, setRouteLine] = useState([]);
  const [loading, setLoading] = useState(false);
  const [error, setError] = useState(null);

  useEffect(() => {
    if (!origin || !destination) return;
    setLoading(true);
    setError(null);
    setRouteLineSafe([]);

    Promise.all([geocode(origin), geocode(destination)]).then(async ([oc, dc]) => {
      if (!oc || !dc) {
        setError('Could not find one or both locations on the map.');
        setLoading(false);
        return;
      }
      setOriginCoords(oc);
      setDestCoords(dc);
      const line = await getRoute(oc, dc);
      setRouteLineSafe(line);
      if (onRouteLine) onRouteLine(line);
      setLoading(false);
    }).catch(() => {
      setError('Map data unavailable. Check your connection.');
      setLoading(false);
    });
  }, [origin, destination]);

  // safe setter alias (avoids naming collision)
  function setRouteLineSafe(v) { setRouteLine(v); }

  const hasMap = originCoords && destCoords;
  const defaultCenter = [39.5, -98.35];

  return (
    <Card className="overflow-hidden">
      <div className="flex items-center gap-3 p-4 border-b border-border">
        <div className="w-8 h-8 rounded-lg bg-primary/10 flex items-center justify-center">
          <MapPin className="w-4 h-4 text-primary" />
        </div>
        <div className="flex-1 min-w-0">
          <p className="font-heading font-semibold text-sm text-foreground">Route Map</p>
          {origin && destination ? (
            <p className="text-xs text-muted-foreground font-body truncate">{origin} → {destination}</p>
          ) : (
            <p className="text-xs text-muted-foreground font-body">Enter start and destination above</p>
          )}
        </div>
        {loading && <Loader2 className="w-4 h-4 animate-spin text-primary shrink-0" />}
      </div>

      <div className="relative" style={{ height: '380px' }}>
        {error && (
          <div className="absolute inset-0 flex items-center justify-center bg-secondary/30 z-10">
            <p className="text-sm text-muted-foreground font-body px-4 text-center">{error}</p>
          </div>
        )}

        <MapContainer
          center={hasMap ? originCoords : defaultCenter}
          zoom={hasMap ? 7 : 4}
          style={{ height: '100%', width: '100%' }}
          scrollWheelZoom={false}
        >
          <TileLayer
            attribution='&copy; <a href="https://www.openstreetmap.org/copyright">OpenStreetMap</a>'
            url="https://{s}.tile.openstreetmap.org/{z}/{x}/{y}.png"
          />

          {originCoords && (
            <Marker position={originCoords} icon={originIcon}>
              <Popup><strong>Start:</strong> {origin}</Popup>
            </Marker>
          )}

          {destCoords && (
            <Marker position={destCoords} icon={destIcon}>
              <Popup><strong>Destination:</strong> {destination}</Popup>
            </Marker>
          )}

          {routeLine.length > 1 && (
            <Polyline positions={routeLine} color="#3d7a5a" weight={4} opacity={0.8} />
          )}

          {hasMap && <FitBounds coords={[originCoords, destCoords]} />}
        </MapContainer>

        {!origin && !destination && !loading && (
          <div className="absolute inset-0 flex items-center justify-center bg-background/60 z-10 pointer-events-none">
            <div className="text-center">
              <Navigation className="w-8 h-8 text-muted-foreground/40 mx-auto mb-2" />
              <p className="text-sm text-muted-foreground font-body">Plan a route to see it on the map</p>
            </div>
          </div>
        )}
      </div>
    </Card>
  );
}