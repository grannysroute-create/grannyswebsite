import React from 'react';
import { Card } from "@/components/ui/card";
import { Button } from "@/components/ui/button";
import { Input } from "@/components/ui/input";
import { Label } from "@/components/ui/label";
import { Switch } from "@/components/ui/switch";
import { MapPin, Navigation, Fuel, WifiOff, Loader2 } from 'lucide-react';

export default function RouteForm({ form, setForm, onSubmit, isLoading }) {
  return (
    <Card className="p-6">
      <form onSubmit={onSubmit} className="space-y-5">
        <div>
          <Label className="font-body text-sm flex items-center gap-2">
            <MapPin className="w-4 h-4 text-primary" />
            Starting Point
          </Label>
          <Input
            placeholder="e.g., Yellowstone National Park, WY"
            value={form.origin}
            onChange={(e) => setForm(prev => ({ ...prev, origin: e.target.value }))}
            className="mt-1.5 rounded-xl font-body"
          />
        </div>
        <div>
          <Label className="font-body text-sm flex items-center gap-2">
            <Navigation className="w-4 h-4 text-accent" />
            Destination
          </Label>
          <Input
            placeholder="e.g., Grand Canyon South Rim, AZ"
            value={form.destination}
            onChange={(e) => setForm(prev => ({ ...prev, destination: e.target.value }))}
            className="mt-1.5 rounded-xl font-body"
          />
        </div>

        <div className="grid grid-cols-2 gap-4">
          <div className="flex items-center justify-between p-3 rounded-xl bg-secondary/50">
            <div className="flex items-center gap-2">
              <Fuel className="w-4 h-4 text-muted-foreground" />
              <span className="text-sm font-body">Fuel Stops</span>
            </div>
            <Switch
              checked={form.includeFuelStops}
              onCheckedChange={(v) => setForm(prev => ({ ...prev, includeFuelStops: v }))}
            />
          </div>
          <div className="flex items-center justify-between p-3 rounded-xl bg-secondary/50">
            <div className="flex items-center gap-2">
              <WifiOff className="w-4 h-4 text-muted-foreground" />
              <span className="text-sm font-body">Offline</span>
            </div>
            <Switch
              checked={form.offlineMode}
              onCheckedChange={(v) => setForm(prev => ({ ...prev, offlineMode: v }))}
            />
          </div>
        </div>

        <Button
          type="submit"
          size="lg"
          className="w-full rounded-xl font-body text-base gap-2"
          disabled={isLoading || !form.origin || !form.destination}
        >
          {isLoading ? (
            <Loader2 className="w-4 h-4 animate-spin" />
          ) : (
            <Navigation className="w-4 h-4" />
          )}
          Plan RV-Safe Route
        </Button>
      </form>
    </Card>
  );
}