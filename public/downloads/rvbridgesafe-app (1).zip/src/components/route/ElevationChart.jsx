import React, { useEffect, useState } from 'react';
import { Card } from "@/components/ui/card";
import { Badge } from "@/components/ui/badge";
import { AreaChart, Area, XAxis, YAxis, Tooltip, ReferenceLine, ResponsiveContainer, CartesianGrid } from 'recharts';
import { Mountain, Loader2, AlertTriangle } from 'lucide-react';

// Sample ~50 evenly-spaced points from a coords array
function samplePoints(coords, n = 50) {
  if (coords.length <= n) return coords;
  const step = (coords.length - 1) / (n - 1);
  return Array.from({ length: n }, (_, i) => coords[Math.round(i * step)]);
}

// Fetch elevations for an array of [lat,lng] pairs via Open-Elevation
async function fetchElevations(points) {
  const locations = points.map(([lat, lng]) => ({ latitude: lat, longitude: lng }));
  const res = await fetch('https://api.open-elevation.com/api/v1/lookup', {
    method: 'POST',
    headers: { 'Content-Type': 'application/json' },
    body: JSON.stringify({ locations }),
  });
  const data = await res.json();
  return data.results.map(r => r.elevation); // meters
}

// Compute cumulative distance in miles between [lat,lng] points
function cumulativeMiles(points) {
  const R = 3958.8;
  let dist = 0;
  const miles = [0];
  for (let i = 1; i < points.length; i++) {
    const [lat1, lon1] = points[i - 1];
    const [lat2, lon2] = points[i];
    const dLat = ((lat2 - lat1) * Math.PI) / 180;
    const dLon = ((lon2 - lon1) * Math.PI) / 180;
    const a = Math.sin(dLat / 2) ** 2 + Math.cos((lat1 * Math.PI) / 180) * Math.cos((lat2 * Math.PI) / 180) * Math.sin(dLon / 2) ** 2;
    dist += 2 * R * Math.asin(Math.sqrt(a));
    miles.push(dist);
  }
  return miles;
}

const STEEP_GRADE_PCT = 6; // ≥6% grade = danger for heavy RVs

const CustomTooltip = ({ active, payload }) => {
  if (!active || !payload?.length) return null;
  const d = payload[0].payload;
  return (
    <div className="bg-card border border-border rounded-xl px-3 py-2 shadow-lg text-xs font-body">
      <p className="font-semibold text-foreground">{d.miles} mi</p>
      <p className="text-muted-foreground">{d.elevFt.toLocaleString()} ft</p>
      {d.gradePct !== null && (
        <p className={d.steep ? 'text-destructive font-semibold' : 'text-muted-foreground'}>
          Grade: {d.gradePct > 0 ? '+' : ''}{d.gradePct}%{d.steep ? ' ⚠️' : ''}
        </p>
      )}
    </div>
  );
};

export default function ElevationChart({ routeLine }) {
  const [chartData, setChartData] = useState([]);
  const [steepCount, setSteepCount] = useState(0);
  const [loading, setLoading] = useState(false);
  const [error, setError] = useState(null);

  useEffect(() => {
    if (!routeLine || routeLine.length < 2) return;
    setLoading(true);
    setError(null);

    const sampled = samplePoints(routeLine, 50);
    const miles = cumulativeMiles(sampled);

    fetchElevations(sampled).then(elevations => {
      let steeps = 0;
      const data = elevations.map((elev, i) => {
        const elevFt = Math.round(elev * 3.28084);
        let gradePct = null;
        let steep = false;
        if (i > 0) {
          const dElev = elev - elevations[i - 1]; // meters
          const dDist = (miles[i] - miles[i - 1]) * 1609.34; // meters
          if (dDist > 0) {
            gradePct = Math.round((dElev / dDist) * 100 * 10) / 10;
            steep = Math.abs(gradePct) >= STEEP_GRADE_PCT;
            if (steep) steeps++;
          }
        }
        return { miles: miles[i].toFixed(1), elevFt, gradePct, steep };
      });
      setChartData(data);
      setSteepCount(steeps);
      setLoading(false);
    }).catch(() => {
      setError('Elevation data unavailable.');
      setLoading(false);
    });
  }, [routeLine]);

  if (!routeLine || routeLine.length < 2) return null;

  const maxElev = chartData.length ? Math.max(...chartData.map(d => d.elevFt)) : 0;
  const minElev = chartData.length ? Math.min(...chartData.map(d => d.elevFt)) : 0;
  const steepPoints = chartData.filter(d => d.steep);

  return (
    <Card className="overflow-hidden">
      <div className="flex items-center justify-between gap-3 p-4 border-b border-border">
        <div className="flex items-center gap-3">
          <div className="w-8 h-8 rounded-lg bg-primary/10 flex items-center justify-center">
            <Mountain className="w-4 h-4 text-primary" />
          </div>
          <div>
            <p className="font-heading font-semibold text-sm text-foreground">Elevation Profile</p>
            <p className="text-xs text-muted-foreground font-body">Steep grades ≥{STEEP_GRADE_PCT}% highlighted in red</p>
          </div>
        </div>
        <div className="flex items-center gap-2">
          {loading && <Loader2 className="w-4 h-4 animate-spin text-primary" />}
          {!loading && steepCount > 0 && (
            <Badge variant="destructive" className="gap-1 text-xs">
              <AlertTriangle className="w-3 h-3" />
              {steepCount} steep section{steepCount > 1 ? 's' : ''}
            </Badge>
          )}
          {!loading && steepCount === 0 && chartData.length > 0 && (
            <Badge className="text-xs bg-primary/10 text-primary border-0">Grades look good</Badge>
          )}
        </div>
      </div>

      <div className="p-4">
        {error && (
          <p className="text-sm text-muted-foreground font-body text-center py-8">{error}</p>
        )}

        {!error && !loading && chartData.length > 0 && (
          <>
            <div className="flex gap-4 text-xs font-body text-muted-foreground mb-3">
              <span>High: <strong className="text-foreground">{maxElev.toLocaleString()} ft</strong></span>
              <span>Low: <strong className="text-foreground">{minElev.toLocaleString()} ft</strong></span>
              <span>Gain: <strong className="text-foreground">{(maxElev - minElev).toLocaleString()} ft</strong></span>
            </div>

            <ResponsiveContainer width="100%" height={200}>
              <AreaChart data={chartData} margin={{ top: 5, right: 10, left: 10, bottom: 5 }}>
                <defs>
                  <linearGradient id="elevGrad" x1="0" y1="0" x2="0" y2="1">
                    <stop offset="5%" stopColor="hsl(152,35%,38%)" stopOpacity={0.3} />
                    <stop offset="95%" stopColor="hsl(152,35%,38%)" stopOpacity={0.05} />
                  </linearGradient>
                </defs>
                <CartesianGrid strokeDasharray="3 3" stroke="hsl(var(--border))" />
                <XAxis
                  dataKey="miles"
                  tickFormatter={v => `${v}mi`}
                  tick={{ fontSize: 10, fontFamily: 'var(--font-body)', fill: 'hsl(var(--muted-foreground))' }}
                  interval="preserveStartEnd"
                />
                <YAxis
                  tickFormatter={v => `${v.toLocaleString()}ft`}
                  tick={{ fontSize: 10, fontFamily: 'var(--font-body)', fill: 'hsl(var(--muted-foreground))' }}
                  width={70}
                />
                <Tooltip content={<CustomTooltip />} />

                {/* Steep grade reference lines */}
                {steepPoints.map((d, i) => (
                  <ReferenceLine
                    key={i}
                    x={d.miles}
                    stroke="hsl(var(--destructive))"
                    strokeOpacity={0.5}
                    strokeWidth={2}
                    strokeDasharray="4 2"
                  />
                ))}

                <Area
                  type="monotone"
                  dataKey="elevFt"
                  stroke="hsl(152,35%,38%)"
                  strokeWidth={2}
                  fill="url(#elevGrad)"
                  dot={false}
                  activeDot={{ r: 4, fill: 'hsl(152,35%,38%)' }}
                />
              </AreaChart>
            </ResponsiveContainer>

            {steepCount > 0 && (
              <p className="text-xs text-muted-foreground font-body mt-3 flex items-center gap-1">
                <AlertTriangle className="w-3 h-3 text-destructive shrink-0" />
                Red dashed lines mark grades ≥{STEEP_GRADE_PCT}% — use lower gears and check brakes before descending.
              </p>
            )}
          </>
        )}

        {loading && (
          <div className="flex items-center justify-center py-12 gap-2 text-sm text-muted-foreground font-body">
            <Loader2 className="w-4 h-4 animate-spin" />
            Loading elevation data…
          </div>
        )}
      </div>
    </Card>
  );
}