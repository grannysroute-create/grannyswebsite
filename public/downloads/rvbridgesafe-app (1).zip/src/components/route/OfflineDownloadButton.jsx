import React, { useState } from 'react';
import { Button } from "@/components/ui/button";
import { WifiOff, Loader2, Download } from 'lucide-react';
import { toast } from "sonner";
import { base44 } from '@/api/base44Client';

function buildOfflineHTML(origin, destination, result) {
  const hazardsHTML = (result.hazards || []).map(h => `
    <div class="hazard">
      <strong>${h.name}</strong> — ${h.type}
      <br/><span class="sub">${h.detail}</span>
      <span class="badge">${h.clearance || h.info || ''}</span>
    </div>
  `).join('');

  return `<!DOCTYPE html>
<html lang="en">
<head>
  <meta charset="UTF-8"/>
  <meta name="viewport" content="width=device-width, initial-scale=1.0"/>
  <title>RVBridgeSafe Route: ${origin} → ${destination}</title>
  <style>
    body { font-family: system-ui, sans-serif; max-width: 700px; margin: 0 auto; padding: 20px; background: #f9f7f2; color: #1a2e1f; }
    h1 { font-size: 1.4rem; margin-bottom: 4px; }
    .meta { color: #6b7280; font-size: 0.85rem; margin-bottom: 24px; }
    .stats { display: grid; grid-template-columns: repeat(3, 1fr); gap: 12px; margin-bottom: 24px; }
    .stat { background: white; border-radius: 12px; padding: 16px; text-align: center; border: 1px solid #e5e7eb; }
    .stat-val { font-size: 1.8rem; font-weight: 700; color: #3d7a5a; }
    .stat-lbl { font-size: 0.75rem; color: #9ca3af; }
    .section { background: white; border-radius: 12px; padding: 16px; margin-bottom: 16px; border: 1px solid #e5e7eb; }
    .section h2 { font-size: 1rem; margin-bottom: 12px; color: #3d7a5a; }
    .hazard { padding: 10px; border-radius: 8px; background: #fdf8f0; margin-bottom: 8px; border-left: 3px solid #d97706; }
    .sub { font-size: 0.8rem; color: #6b7280; }
    .badge { display: inline-block; margin-top: 4px; background: #f3f4f6; padding: 2px 8px; border-radius: 20px; font-size: 0.75rem; }
    .summary { font-size: 0.9rem; line-height: 1.6; color: #374151; }
    .offline-badge { display: inline-block; background: #fef3c7; color: #92400e; padding: 4px 10px; border-radius: 20px; font-size: 0.75rem; margin-bottom: 16px; }
    .footer { text-align: center; font-size: 0.75rem; color: #9ca3af; margin-top: 32px; }
  </style>
</head>
<body>
  <div class="offline-badge">📴 Offline Route Pack — RVBridgeSafe</div>
  <h1>${origin} → ${destination}</h1>
  <p class="meta">Generated ${new Date().toLocaleDateString('en-US', { weekday: 'long', year: 'numeric', month: 'long', day: 'numeric' })}</p>

  <div class="stats">
    <div class="stat"><div class="stat-val">${result.distance}</div><div class="stat-lbl">miles</div></div>
    <div class="stat"><div class="stat-val">${result.time}</div><div class="stat-lbl">hours</div></div>
    <div class="stat"><div class="stat-val">${result.fuelStops}</div><div class="stat-lbl">fuel stops</div></div>
  </div>

  ${result.summary ? `<div class="section"><p class="summary">${result.summary}</p></div>` : ''}

  <div class="section">
    <h2>⚠️ Hazards Routed Around (${(result.hazards || []).length})</h2>
    ${hazardsHTML || '<p style="color:#9ca3af;font-size:0.85rem;">No hazards listed.</p>'}
  </div>

  <div class="footer">RVBridgeSafe · rvbridgesafe.app · Safe travels! 🚐</div>
</body>
</html>`;
}

export default function OfflineDownloadButton({ origin, destination, result }) {
  const [isUploading, setIsUploading] = useState(false);

  const handleDownload = async () => {
    setIsUploading(true);
    try {
      const html = buildOfflineHTML(origin, destination, result);
      const blob = new Blob([html], { type: 'text/html' });
      const file = new File([blob], `rvroute-${Date.now()}.html`, { type: 'text/html' });

      const { file_url } = await base44.integrations.Core.UploadFile({ file });

      // Trigger browser download via anchor
      const a = document.createElement('a');
      a.href = file_url;
      a.download = `RVRoute_${origin.replace(/\s+/g, '_')}_to_${destination.replace(/\s+/g, '_')}.html`;
      document.body.appendChild(a);
      a.click();
      document.body.removeChild(a);

      toast.success("Offline route pack downloaded! Open it anytime without cell service. 📴");
    } catch {
      toast.error("Couldn't generate offline pack. Please try again.");
    } finally {
      setIsUploading(false);
    }
  };

  return (
    <Button
      onClick={handleDownload}
      variant="outline"
      className="w-full rounded-xl font-body gap-2"
      disabled={isUploading}
    >
      {isUploading ? <Loader2 className="w-4 h-4 animate-spin" /> : <WifiOff className="w-4 h-4" />}
      {isUploading ? 'Preparing Offline Pack…' : 'Download for Offline Use'}
    </Button>
  );
}