import React from 'react';
import { motion } from 'framer-motion';
import { Button } from "@/components/ui/button";
import { ExternalLink } from 'lucide-react';

const quickLinks = [
  { name: 'Walmart', url: 'https://www.walmart.com/cp/rv-accessories/1231459' },
  { name: 'Amazon', url: 'https://www.amazon.com/s?k=rv+essentials' },
  { name: 'GasBuddy', url: 'https://www.gasbuddy.com/' },
  { name: 'Gumroad', url: 'https://gumroad.com/l/rvbridgesafe' },
  { name: 'Upside', url: 'https://www.upside.com/' },
  { name: 'Visible', url: 'https://www.visible.com/' },
];

export default function QuickLinksSection() {
  return (
    <section className="py-12 bg-background border-b border-border/50">
      <div className="max-w-7xl mx-auto px-4 sm:px-6 lg:px-8">
        <div className="text-center mb-8">
          <h2 className="font-heading text-2xl font-bold text-foreground">
            Quick Links
          </h2>
        </div>
        <div className="flex flex-wrap justify-center gap-4">
          {quickLinks.map((link, i) => (
            <motion.a
              key={i}
              href={link.url}
              target="_blank"
              rel="noopener noreferrer"
              initial={{ opacity: 0, y: 10 }}
              whileInView={{ opacity: 1, y: 0 }}
              viewport={{ once: true }}
              transition={{ duration: 0.3, delay: i * 0.05 }}
            >
              <Button variant="outline" className="rounded-full shadow-sm gap-2 font-body px-6 hover:bg-secondary/40 transition-colors">
                {link.name}
                <ExternalLink className="w-3 h-3 text-muted-foreground" />
              </Button>
            </motion.a>
          ))}
        </div>
      </div>
    </section>
  );
}