import React, { useState } from 'react';
import { Link } from 'react-router-dom';
import { Button } from "@/components/ui/button";
import { ExternalLink, ArrowRight, ChevronDown, ChevronUp } from 'lucide-react';
import { motion, AnimatePresence } from 'framer-motion';

const spots = [
  { emoji: '🛡️', name: "Granny's Route", tagline: 'Premium — coming soon', url: '#' },
  { emoji: '🛍️', name: 'Gumroad', tagline: 'Digital downloads', url: 'https://gumroad.com/l/rvbridgesafe' },
  { emoji: '⛽', name: 'GasBuddy', tagline: 'Cheapest diesel', url: 'https://www.gasbuddy.com/' },
  { emoji: '💸', name: 'Upside', tagline: 'Gas cashback', url: 'https://www.upside.com/' },
  { emoji: '📱', name: 'Visible', tagline: '$25 unlimited', url: 'https://www.visible.com/' },
  { emoji: '🛒', name: 'Walmart', tagline: 'Overnight parking', url: 'https://www.walmart.com/cp/rv-accessories/1231459' },
  { emoji: '📦', name: 'Amazon', tagline: 'RV essentials', url: 'https://www.amazon.com/s?k=rv+essentials' },
];

export default function AffiliateStrip() {
  const [open, setOpen] = useState(false);

  return (
    <section className="border-y border-border bg-card/50">
      {/* Toggle header */}
      <div
        onClick={() => setOpen(o => !o)}
        className="w-full flex items-center justify-between px-4 sm:px-8 py-4 cursor-pointer hover:bg-secondary/40 transition-colors"
        role="button"
        tabIndex={0}
        onKeyDown={(e) => {
          if (e.key === 'Enter' || e.key === ' ') {
            setOpen(o => !o);
          }
        }}
      >
        <div className="flex items-center gap-3">
          <span className="text-xl">🛒</span>
          <div className="text-left">
            <p className="font-heading text-sm font-semibold text-foreground">Trusted Gear &amp; Services</p>
            <p className="text-xs text-muted-foreground font-body">Fuel, essentials &amp; RV life — community picks</p>
          </div>
        </div>
        <div className="flex items-center gap-2 shrink-0">
          <Link to="/gear" onClick={e => e.stopPropagation()}>
            <Button variant="ghost" size="sm" className="rounded-xl font-body gap-1 text-xs hidden sm:flex">
              See All <ArrowRight className="w-3 h-3" />
            </Button>
          </Link>
          {open ? <ChevronUp className="w-4 h-4 text-muted-foreground" /> : <ChevronDown className="w-4 h-4 text-muted-foreground" />}
        </div>
      </div>

      {/* Expandable grid */}
      <AnimatePresence initial={false}>
        {open && (
          <motion.div
            key="affiliate-grid"
            initial={{ height: 0, opacity: 0 }}
            animate={{ height: 'auto', opacity: 1 }}
            exit={{ height: 0, opacity: 0 }}
            transition={{ duration: 0.25, ease: 'easeInOut' }}
            className="overflow-hidden"
          >
            <div className="px-4 sm:px-8 pb-6 pt-2">
              <div className="grid grid-cols-2 sm:grid-cols-4 lg:grid-cols-8 gap-3">
                {spots.map((item, i) => (
                  <a
                    key={i}
                    href={item.url}
                    target="_blank"
                    rel="noopener noreferrer"
                    className="group flex flex-col items-center gap-2 p-4 rounded-2xl border border-border bg-background hover:border-primary/30 hover:shadow-md transition-all duration-200 text-center"
                  >
                    <span className="text-3xl group-hover:scale-110 transition-transform">{item.emoji}</span>
                    <div>
                      <p className="font-body font-semibold text-sm text-foreground">{item.name}</p>
                      <p className="text-xs text-muted-foreground font-body">{item.tagline}</p>
                    </div>
                    <ExternalLink className="w-3 h-3 text-muted-foreground/40 group-hover:text-primary transition-colors" />
                  </a>
                ))}
              </div>
              <p className="text-center text-xs text-muted-foreground/50 font-body mt-4">
                Affiliate links — we earn a small commission at no cost to you. Thank you! ♥
              </p>
            </div>
          </motion.div>
        )}
      </AnimatePresence>
    </section>
  );
}