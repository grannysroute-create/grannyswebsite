import React from 'react';
import { motion } from 'framer-motion';
import { Star, Quote } from 'lucide-react';

const testimonials = [
  {
    name: 'Linda & Doug M.',
    rig: 'Class A, 13\'2"',
    text: 'We nearly hit a 12\'6" bridge our first week full-timing. RVBridgeSafe warned us a mile out. That app paid for itself before we even reached Florida.',
    location: 'Full-timers, 2 years',
    stars: 5
  },
  {
    name: 'Tom R.',
    rig: '5th Wheel, 12\'11"',
    text: 'My insurance agent actually recommended this app after my neighbor filed a bridge strike claim. Best advice he ever gave me — and he\'s usually just trying to sell me stuff.',
    location: 'Weekend warrior',
    stars: 5
  },
  {
    name: 'The Hendersons',
    rig: 'Toy Hauler, 13\'6"',
    text: 'Downloaded offline maps for Utah before our trip. Hit a dead zone for 4 hours straight. The app never blinked. Routed us around a 12\'0" tunnel like it was nothing.',
    location: 'Family of 5 + 2 dogs',
    stars: 5
  }
];

export default function TestimonialsSection() {
  return (
    <section className="py-20 md:py-28 bg-gradient-to-b from-secondary/30 to-transparent">
      <div className="max-w-7xl mx-auto px-4 sm:px-6 lg:px-8">
        <div className="text-center mb-16">
          <h2 className="font-heading text-3xl md:text-4xl font-bold text-foreground mb-4">
            Folks who sleep better at night
          </h2>
          <p className="text-muted-foreground font-body text-lg">
            Real stories from real RVers. No actors, no scripts — just grateful travelers.
          </p>
        </div>

        <div className="grid grid-cols-1 md:grid-cols-3 gap-8">
          {testimonials.map((t, i) => (
            <motion.div
              key={i}
              initial={{ opacity: 0, y: 20 }}
              whileInView={{ opacity: 1, y: 0 }}
              viewport={{ once: true }}
              transition={{ duration: 0.5, delay: i * 0.15 }}
              className="relative p-8 rounded-2xl bg-card border border-border"
            >
              <Quote className="w-8 h-8 text-primary/15 absolute top-6 right-6" />
              <div className="flex gap-0.5 mb-4">
                {Array(t.stars).fill(0).map((_, j) => (
                  <Star key={j} className="w-4 h-4 text-accent fill-accent" />
                ))}
              </div>
              <p className="text-foreground font-body leading-relaxed mb-6 text-sm">"{t.text}"</p>
              <div className="border-t border-border pt-4">
                <p className="font-heading font-semibold text-foreground">{t.name}</p>
                <p className="text-xs text-muted-foreground font-body">{t.rig} · {t.location}</p>
              </div>
            </motion.div>
          ))}
        </div>
      </div>
    </section>
  );
}