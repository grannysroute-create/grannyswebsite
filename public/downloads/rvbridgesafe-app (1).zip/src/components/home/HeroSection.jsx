import React from 'react';
import { Link } from 'react-router-dom';
import { Button } from "@/components/ui/button";
import { Shield, ArrowRight, ChevronDown } from 'lucide-react';
import { motion } from 'framer-motion';

export default function HeroSection() {
  return (
    <section className="relative overflow-hidden">
      {/* Background pattern */}
      <div className="absolute inset-0 bg-gradient-to-br from-primary/5 via-transparent to-accent/5" />
      <div className="absolute top-20 right-10 w-72 h-72 bg-primary/5 rounded-full blur-3xl" />
      <div className="absolute bottom-10 left-10 w-96 h-96 bg-accent/5 rounded-full blur-3xl" />

      <div className="relative max-w-7xl mx-auto px-4 sm:px-6 lg:px-8 pt-16 pb-20 md:pt-24 md:pb-32">
        <div className="max-w-3xl mx-auto text-center">
          <motion.div
            initial={{ opacity: 0, y: 20 }}
            animate={{ opacity: 1, y: 0 }}
            transition={{ duration: 0.6 }}
          >
            <div className="inline-flex items-center gap-2 px-4 py-2 rounded-full bg-secondary border border-border mb-8">
              <Shield className="w-4 h-4 text-primary" />
              <span className="text-sm font-body font-medium text-foreground">Built by RVers, for RVers</span>
            </div>
          </motion.div>

          <motion.h1
            initial={{ opacity: 0, y: 20 }}
            animate={{ opacity: 1, y: 0 }}
            transition={{ duration: 0.6, delay: 0.1 }}
            className="font-heading text-3xl sm:text-4xl md:text-5xl font-bold text-foreground leading-tight mb-4"
          >
            Stop white-knuckling{' '}
            <span className="text-primary">under every bridge</span>{' '}
            you cross.
          </motion.h1>

          <motion.p
            initial={{ opacity: 0, y: 20 }}
            animate={{ opacity: 1, y: 0 }}
            transition={{ duration: 0.6, delay: 0.2 }}
            className="text-base md:text-lg text-muted-foreground font-body leading-relaxed mb-6 max-w-2xl mx-auto"
          >
            Your regular GPS thinks you're in a sedan. We know you're 13'6" tall and 40 feet long. 
            Enter your rig once, and we'll keep you safe on every mile of every adventure.
          </motion.p>

          <motion.div
            initial={{ opacity: 0, y: 20 }}
            animate={{ opacity: 1, y: 0 }}
            transition={{ duration: 0.6, delay: 0.3 }}
            className="flex flex-col sm:flex-row items-center justify-center gap-4"
          >
            <Link to="/rig-profile">
              <Button size="lg" className="font-body text-base px-8 gap-2 rounded-xl shadow-lg shadow-primary/20">
                Set Up My Rig
                <ArrowRight className="w-4 h-4" />
              </Button>
            </Link>
            <Link to="/route-planner">
              <Button variant="outline" size="lg" className="font-body text-base px-8 rounded-xl">
                Plan a Route
              </Button>
            </Link>
          </motion.div>

          {/* Stats */}
          <motion.div
            initial={{ opacity: 0, y: 20 }}
            animate={{ opacity: 1, y: 0 }}
            transition={{ duration: 0.6, delay: 0.5 }}
            className="grid grid-cols-3 gap-6 mt-8 max-w-lg mx-auto"
          >
            {[
              { number: '500K+', label: 'Verified Bridges' },
              { number: '50K+', label: 'Active RVers' },
              { number: '$0', label: 'Bridge Strikes' },
            ].map((stat, i) => (
              <div key={i} className="text-center">
                <p className="font-heading text-xl md:text-2xl font-bold text-primary">{stat.number}</p>
                <p className="text-xs md:text-sm text-muted-foreground font-body mt-1">{stat.label}</p>
              </div>
            ))}
          </motion.div>
        </div>

        <motion.div
          initial={{ opacity: 0 }}
          animate={{ opacity: 1 }}
          transition={{ delay: 1, duration: 1 }}
          className="flex justify-center mt-8"
        >
          <ChevronDown className="w-5 h-5 text-muted-foreground animate-bounce" />
        </motion.div>
      </div>
    </section>
  );
}