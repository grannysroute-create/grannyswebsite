import React, { useState } from 'react';
import { useNavigate } from 'react-router-dom';
import { Button } from "@/components/ui/button";
import { Input } from "@/components/ui/input";
import { MapPin, Navigation, Route } from 'lucide-react';
import { motion } from 'framer-motion';

export default function HomePlannerSection() {
  const navigate = useNavigate();
  const [origin, setOrigin] = useState('');
  const [destination, setDestination] = useState('');

  const handlePlan = (e) => {
    e.preventDefault();
    const params = new URLSearchParams();
    if (origin) params.set('origin', origin);
    if (destination) params.set('destination', destination);
    navigate(`/route-planner?${params.toString()}`);
  };

  return (
    <section className="py-16 bg-primary/5 border-y border-border">
      <div className="max-w-4xl mx-auto px-4 sm:px-6 lg:px-8">
        <motion.div
          initial={{ opacity: 0, y: 20 }}
          whileInView={{ opacity: 1, y: 0 }}
          viewport={{ once: true }}
          transition={{ duration: 0.5 }}
          className="text-center mb-8"
        >
          <div className="w-12 h-12 rounded-2xl bg-primary/10 flex items-center justify-center mx-auto mb-4">
            <Route className="w-6 h-6 text-primary" />
          </div>
          <h2 className="font-heading text-3xl font-bold text-foreground mb-2">Plan Your RV-Safe Route</h2>
          <p className="text-muted-foreground font-body">Enter your start and destination — we'll handle the bridges.</p>
        </motion.div>

        <motion.div
          initial={{ opacity: 0, y: 20 }}
          whileInView={{ opacity: 1, y: 0 }}
          viewport={{ once: true }}
          transition={{ duration: 0.5, delay: 0.1 }}
          className="bg-card border border-border rounded-2xl shadow-lg p-6"
        >
          <form onSubmit={handlePlan} className="flex flex-col sm:flex-row gap-3">
            <div className="flex-1 relative">
              <MapPin className="absolute left-3 top-1/2 -translate-y-1/2 w-4 h-4 text-primary pointer-events-none" />
              <Input
                placeholder="From… e.g. Nashville, TN"
                value={origin}
                onChange={e => setOrigin(e.target.value)}
                className="pl-9 rounded-xl font-body"
              />
            </div>
            <div className="flex-1 relative">
              <Navigation className="absolute left-3 top-1/2 -translate-y-1/2 w-4 h-4 text-accent pointer-events-none" />
              <Input
                placeholder="To… e.g. Grand Canyon, AZ"
                value={destination}
                onChange={e => setDestination(e.target.value)}
                className="pl-9 rounded-xl font-body"
              />
            </div>
            <Button
              type="submit"
              size="lg"
              className="rounded-xl font-body gap-2 shrink-0"
              disabled={!origin || !destination}
            >
              <Navigation className="w-4 h-4" />
              Plan Route
            </Button>
          </form>
        </motion.div>
      </div>
    </section>
  );
}