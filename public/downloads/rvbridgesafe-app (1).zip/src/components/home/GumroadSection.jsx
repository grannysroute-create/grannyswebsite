import React from 'react';
import { motion } from 'framer-motion';
import { Badge } from "@/components/ui/badge";
import { ShoppingCart, Shield, WifiOff, Map, Bell, Zap } from 'lucide-react';

const APPS = [
  {
    label: "Granny's Garage",
    url: 'https://grannysroute.gumroad.com/l/grannysgaragee',
    icon: Zap,
    desc: 'RV maintenance tracker & reminders',
  },
  {
    label: "Granny's RV Pre-trip Check",
    url: 'https://grannysroute.gumroad.com/l/rvpretrip',
    icon: Map,
    desc: 'Departure checklist for every trip',
  },
  {
    label: "Granny's Solar Weekend Power Check",
    url: 'https://grannysroute.gumroad.com/l/solarpowercheck',
    icon: Bell,
    desc: 'Solar & battery planner for off-grid weekends',
  },
  {
    label: 'RVBridgeSafe',
    url: 'https://grannysroute.gumroad.com/l/rvbridgesafe',
    icon: WifiOff,
    desc: 'Bridge clearance alerts & RV-safe routing',
  },
];


export default function GumroadSection() {
  return (
    <section className="py-14 px-4 bg-secondary/40">
      <div className="max-w-4xl mx-auto">
        <motion.div
          initial={{ opacity: 0, y: 20 }}
          whileInView={{ opacity: 1, y: 0 }}
          viewport={{ once: true }}
          className="text-center mb-8"
        >
          <Badge className="mb-4 bg-accent text-accent-foreground font-body">Now on Gumroad</Badge>
          <h2 className="font-heading text-3xl md:text-4xl font-bold text-foreground mb-3">
            Granny's App Family
          </h2>
          <p className="text-muted-foreground font-body text-base max-w-xl mx-auto">
            A suite of RV tools built for real travelers. All available on Gumroad.
          </p>
        </motion.div>

        <div className="grid grid-cols-1 sm:grid-cols-2 gap-4">
          {APPS.map(({ label, url, icon: Icon, desc }, i) => (
            <motion.a
              key={label}
              href={url}
              target="_blank"
              rel="noopener noreferrer"
              initial={{ opacity: 0, y: 16 }}
              whileInView={{ opacity: 1, y: 0 }}
              viewport={{ once: true }}
              transition={{ delay: i * 0.07 }}
              className="bg-card border border-border rounded-2xl p-5 flex items-start gap-4 hover:shadow-md hover:border-primary/40 transition-all group"
            >
              <div className="w-10 h-10 rounded-xl bg-primary/10 flex items-center justify-center shrink-0 group-hover:bg-primary/20 transition-colors">
                <Icon className="w-5 h-5 text-primary" />
              </div>
              <div className="flex-1 min-w-0">
                <div className="flex items-center gap-2 mb-1">
                  <span className="font-body font-semibold text-foreground text-sm">{label}</span>
                  <ShoppingCart className="w-3 h-3 text-muted-foreground shrink-0" />
                </div>
                <p className="text-xs text-muted-foreground font-body leading-relaxed">{desc}</p>
              </div>
            </motion.a>
          ))}
        </div>

        {/* Book feature */}
        <motion.div
          initial={{ opacity: 0, y: 16 }}
          whileInView={{ opacity: 1, y: 0 }}
          viewport={{ once: true }}
          transition={{ delay: 0.32 }}
          className="flex flex-col items-center mt-6"
        >
          <div className="bg-card border border-border rounded-2xl p-5 flex flex-col sm:flex-row items-center gap-5 hover:shadow-md hover:border-primary/40 transition-all max-w-md w-full">
            <a
              href="https://grannysroute.gumroad.com/l/rangersquad"
              target="_blank"
              rel="noopener noreferrer"
              className="shrink-0"
            >
              <img
                src="https://media.base44.com/images/public/69f80fae4d57b1fce069e110/99df2c182_RangerSquadseries1.png"
                alt="The $5 Ranger Squad book cover"
                className="w-28 rounded-xl shadow-md object-cover"
              />
            </a>
            <div className="flex flex-col items-center sm:items-start text-center sm:text-left gap-2">
              <span className="font-body font-semibold text-foreground text-sm">The $5 Ranger Squad</span>
              <p className="text-xs text-muted-foreground font-body leading-relaxed">A book series by Granny Foor — available on Gumroad & Kindle.</p>
              <span className="inline-block bg-primary/10 text-primary text-xs font-semibold font-body px-2 py-0.5 rounded-full">📖 1st Book is a FREE download!</span>
              <div className="flex gap-2 mt-1">
                <a
                  href="https://grannysroute.gumroad.com/l/rangersquad"
                  target="_blank"
                  rel="noopener noreferrer"
                  className="inline-flex items-center gap-1 text-xs font-body font-medium text-primary underline underline-offset-2 hover:text-primary/80"
                >
                  <ShoppingCart className="w-3 h-3" /> Gumroad
                </a>
                <span className="text-muted-foreground">·</span>
                <a
                  href="https://www.amazon.com/s?k=ranger+squad+granny+foor"
                  target="_blank"
                  rel="noopener noreferrer"
                  className="inline-flex items-center gap-1 text-xs font-body font-medium text-primary underline underline-offset-2 hover:text-primary/80"
                >
                  Kindle
                </a>
              </div>
            </div>
          </div>
        </motion.div>

        <motion.div
          initial={{ opacity: 0 }}
          whileInView={{ opacity: 1 }}
          viewport={{ once: true }}
          transition={{ delay: 0.45 }}
          className="flex items-center justify-center gap-1 mt-6 text-xs text-muted-foreground font-body"
        >
          <Shield className="w-3 h-3 text-primary" />
          30-day Gumroad money-back guarantee on all apps
        </motion.div>
      </div>
    </section>
  );
}