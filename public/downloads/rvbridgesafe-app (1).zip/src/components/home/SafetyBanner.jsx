import React from 'react';
import { Link } from 'react-router-dom';
import { motion } from 'framer-motion';
import { Button } from "@/components/ui/button";
import { Shield, ArrowRight, DollarSign, Clock, Wrench } from 'lucide-react';

export default function SafetyBanner() {
  return (
    <section className="py-20 md:py-28">
      <div className="max-w-7xl mx-auto px-4 sm:px-6 lg:px-8">
        <motion.div
          initial={{ opacity: 0, y: 20 }}
          whileInView={{ opacity: 1, y: 0 }}
          viewport={{ once: true }}
          transition={{ duration: 0.6 }}
          className="relative rounded-3xl bg-primary overflow-hidden p-10 md:p-16"
        >
          <div className="absolute top-0 right-0 w-80 h-80 bg-white/5 rounded-full -translate-y-1/2 translate-x-1/2" />
          <div className="absolute bottom-0 left-0 w-60 h-60 bg-white/5 rounded-full translate-y-1/2 -translate-x-1/2" />

          <div className="relative text-center max-w-2xl mx-auto">
            <Shield className="w-12 h-12 text-primary-foreground/80 mx-auto mb-6" />
            <h2 className="font-heading text-3xl md:text-4xl font-bold text-primary-foreground mb-4">
              The average bridge strike costs $15,000+
            </h2>
            <p className="text-primary-foreground/80 font-body text-lg mb-8">
              Plus 3 months off the road for repairs. That's a whole season of adventures gone.
              Set up your rig profile in 60 seconds and never worry again.
            </p>

            <div className="grid grid-cols-3 gap-6 mb-10">
              {[
                { icon: DollarSign, label: '$15,000+', sub: 'Average cost' },
                { icon: Clock, label: '3 months', sub: 'Off the road' },
                { icon: Wrench, label: '#1 claim', sub: 'RV insurance' },
              ].map((item, i) => (
                <div key={i} className="text-center">
                  <item.icon className="w-6 h-6 text-primary-foreground/60 mx-auto mb-2" />
                  <p className="font-heading text-xl font-bold text-primary-foreground">{item.label}</p>
                  <p className="text-xs text-primary-foreground/60 font-body">{item.sub}</p>
                </div>
              ))}
            </div>

            <Link to="/rig-profile">
              <Button size="lg" variant="secondary" className="font-body text-base px-8 gap-2 rounded-xl">
                Set Up My Rig — Free
                <ArrowRight className="w-4 h-4" />
              </Button>
            </Link>
          </div>
        </motion.div>
      </div>
    </section>
  );
}