import React from 'react';
import { motion } from 'framer-motion';
import {
  Ruler,
  AlertTriangle,
  Route,
  WifiOff,
  Fuel,
  Users,
  Monitor,
  ShieldCheck
} from 'lucide-react';

const features = [
  {
    icon: Ruler,
    title: 'Custom Rig Profile',
    description: 'Set your height, length, width, weight, and propane status once. No more generic "truck" routes.',
    color: 'bg-primary/10 text-primary'
  },
  {
    icon: AlertTriangle,
    title: 'Real-Time Alerts',
    description: 'Audio + visual warnings at 1 mile, half a mile, and 500 feet before any hazard. Like a friend riding shotgun.',
    color: 'bg-accent/10 text-accent'
  },
  {
    icon: Route,
    title: 'RV-Safe Routing',
    description: 'We dodge steep grades, tight turns, weight-restricted roads, and propane-restricted tunnels. You just enjoy the view.',
    color: 'bg-primary/10 text-primary'
  },
  {
    icon: WifiOff,
    title: 'Offline Maps',
    description: 'Download entire states before you head out. No cell signal in the boonies? No problem.',
    color: 'bg-accent/10 text-accent'
  },
  {
    icon: Fuel,
    title: 'Fuel Stop Planning',
    description: 'Finds diesel, DEF, and big-rig-friendly stations right along your route. No more surprise "NO TRUCKS" signs.',
    color: 'bg-primary/10 text-primary'
  },
  {
    icon: Users,
    title: 'Community Reports',
    description: '50,000+ RVers sharing close calls, bridge strikes, and road conditions. We look out for each other.',
    color: 'bg-accent/10 text-accent'
  },
  {
    icon: Monitor,
    title: 'CarPlay & Android Auto',
    description: 'Big-button interface right on your dash. Keep your eyes on the road, your hands upon the wheel.',
    color: 'bg-primary/10 text-primary'
  },
  {
    icon: ShieldCheck,
    title: '500K+ Bridge Database',
    description: 'Every bridge, tunnel, and overpass across US & Canada, verified and updated monthly with DOT data.',
    color: 'bg-accent/10 text-accent'
  }
];

export default function FeaturesGrid() {
  return (
    <section className="py-20 md:py-28">
      <div className="max-w-7xl mx-auto px-4 sm:px-6 lg:px-8">
        <div className="text-center mb-16">
          <h2 className="font-heading text-3xl md:text-4xl font-bold text-foreground mb-4">
            WE need to travel safely
          </h2>
          <p className="text-muted-foreground font-body text-lg max-w-2xl mx-auto">
            We built every feature after hearing real stories from real RVers. 
            Because nobody should have a $15,000 bridge strike ruin their trip.
          </p>
        </div>

        <div className="grid grid-cols-1 sm:grid-cols-2 lg:grid-cols-4 gap-6">
          {features.map((feature, i) => (
            <motion.div
              key={i}
              initial={{ opacity: 0, y: 20 }}
              whileInView={{ opacity: 1, y: 0 }}
              viewport={{ once: true }}
              transition={{ duration: 0.4, delay: i * 0.08 }}
              className="group p-6 rounded-2xl bg-card border border-border hover:border-primary/30 hover:shadow-lg hover:shadow-primary/5 transition-all duration-300"
            >
              <div className={`w-12 h-12 rounded-xl ${feature.color} flex items-center justify-center mb-4 group-hover:scale-110 transition-transform`}>
                <feature.icon className="w-6 h-6" />
              </div>
              <h3 className="font-heading text-lg font-semibold text-foreground mb-2">{feature.title}</h3>
              <p className="text-sm text-muted-foreground font-body leading-relaxed">{feature.description}</p>
            </motion.div>
          ))}
        </div>
      </div>
    </section>
  );
}