import { Toaster } from "@/components/ui/toaster"
import { QueryClientProvider } from '@tanstack/react-query'
import { queryClientInstance } from '@/lib/query-client'
import { BrowserRouter as Router, Route, Routes } from 'react-router-dom';
import PageNotFound from './lib/PageNotFound';
import { AuthProvider, useAuth } from '@/lib/AuthContext';
import UserNotRegisteredError from '@/components/UserNotRegisteredError';
import AppLayout from './components/layout/AppLayout';
import Home from './pages/Home';
import Dashboard from './pages/Dashboard';
import RoutePlanner from './pages/RoutePlanner';
import Community from './pages/Community';
import RigProfile from './pages/RigProfile';
import Reviews from './pages/Reviews';
import Affiliates from './pages/Affiliates';
import Upgrade from './pages/Upgrade';
import HazardMap from './pages/HazardMap';
import DOTResources from './pages/DOTResources';
import GumroadGuide from './pages/GumroadGuide';

const AuthenticatedApp = () => {
  const { isLoadingAuth, isLoadingPublicSettings, authError, navigateToLogin } = useAuth();

  // Show loading spinner while checking app public settings or auth
  if (isLoadingPublicSettings || isLoadingAuth) {
    return (
      <div className="fixed inset-0 flex items-center justify-center">
        <div className="w-8 h-8 border-4 border-slate-200 border-t-slate-800 rounded-full animate-spin"></div>
      </div>
    );
  }

  // Handle authentication errors
  if (authError) {
    if (authError.type === 'user_not_registered') {
      return <UserNotRegisteredError />;
    } else if (authError.type === 'auth_required') {
      // Redirect to login automatically
      navigateToLogin();
      return null;
    }
  }

  // Render the main app
  return (
    <Routes>
      <Route element={<AppLayout />}>
        <Route path="/" element={<Home />} />
        <Route path="/dashboard" element={<Dashboard />} />
        <Route path="/route-planner" element={<RoutePlanner />} />
        <Route path="/community" element={<Community />} />
        <Route path="/rig-profile" element={<RigProfile />} />
        <Route path="/hazard-map" element={<HazardMap />} />
        <Route path="/reviews" element={<Reviews />} />
        <Route path="/gear" element={<Affiliates />} />
        <Route path="/upgrade" element={<Upgrade />} />
        <Route path="/dot-resources" element={<DOTResources />} />
        <Route path="/gumroad-guide" element={<GumroadGuide />} />
      </Route>
      <Route path="*" element={<PageNotFound />} />
    </Routes>
  );
};


function App() {

  return (
    <AuthProvider>
      <QueryClientProvider client={queryClientInstance}>
        <Router>
          <AuthenticatedApp />
        </Router>
        <Toaster />
      </QueryClientProvider>
    </AuthProvider>
  )
}

export default App