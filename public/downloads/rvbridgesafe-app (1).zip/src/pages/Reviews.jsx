import React, { useState } from 'react';
import { base44 } from '@/api/base44Client';
import { useQuery, useMutation, useQueryClient } from '@tanstack/react-query';
import { toast } from "sonner";
import { Star } from 'lucide-react';
import { motion } from 'framer-motion';
import ReviewForm from '../components/community/ReviewForm';
import ReviewsList from '../components/community/ReviewsList';

function RatingBar({ stars, count, total }) {
  const pct = total > 0 ? Math.round((count / total) * 100) : 0;
  return (
    <div className="flex items-center gap-3">
      <span className="text-xs font-body text-muted-foreground w-3">{stars}</span>
      <Star className="w-3.5 h-3.5 text-accent fill-accent shrink-0" />
      <div className="flex-1 h-2 rounded-full bg-muted overflow-hidden">
        <div className="h-full bg-accent rounded-full transition-all" style={{ width: `${pct}%` }} />
      </div>
      <span className="text-xs font-body text-muted-foreground w-6 text-right">{count}</span>
    </div>
  );
}

export default function Reviews() {
  const queryClient = useQueryClient();

  const { data: reviews } = useQuery({
    queryKey: ['reviews'],
    queryFn: () => base44.entities.CommunityReview.list('-created_date', 50),
    initialData: [],
  });

  const createMutation = useMutation({
    mutationFn: (data) => base44.entities.CommunityReview.create(data),
    onSuccess: () => {
      queryClient.invalidateQueries({ queryKey: ['reviews'] });
      toast.success("Thank you kindly! Your review means the world to us. 🌟");
    },
  });

  const helpfulMutation = useMutation({
    mutationFn: (review) =>
      base44.entities.CommunityReview.update(review.id, { helpful_votes: (review.helpful_votes || 0) + 1 }),
    onSuccess: () => {
      queryClient.invalidateQueries({ queryKey: ['reviews'] });
    },
  });

  // Calculate stats
  const total = reviews.length;
  const avgRating = total > 0
    ? (reviews.reduce((sum, r) => sum + (r.rating || 0), 0) / total).toFixed(1)
    : '0.0';
  const ratingCounts = [5, 4, 3, 2, 1].map(stars => ({
    stars,
    count: reviews.filter(r => r.rating === stars).length,
  }));

  return (
    <div className="max-w-7xl mx-auto px-4 sm:px-6 lg:px-8 py-8 md:py-12">
      <motion.div initial={{ opacity: 0, y: 20 }} animate={{ opacity: 1, y: 0 }}>

        <div className="text-center mb-10">
          <div className="w-16 h-16 rounded-2xl bg-accent/10 flex items-center justify-center mx-auto mb-4">
            <Star className="w-8 h-8 text-accent fill-accent" />
          </div>
          <h1 className="font-heading text-3xl font-bold text-foreground mb-2">Community Reviews</h1>
          <p className="text-muted-foreground font-body max-w-xl mx-auto">
            Real stories from real RVers. No bots, no paid reviews — just honest folks sharing what they've experienced on the road.
          </p>
        </div>

        {/* Rating summary */}
        {total > 0 && (
          <div className="flex flex-col sm:flex-row items-center gap-8 p-6 rounded-2xl bg-secondary/50 border border-border mb-10 max-w-xl mx-auto">
            <div className="text-center shrink-0">
              <p className="font-heading text-5xl font-bold text-foreground">{avgRating}</p>
              <div className="flex justify-center gap-0.5 my-1.5">
                {[...Array(5)].map((_, i) => (
                  <Star key={i} className={`w-4 h-4 ${i < Math.round(parseFloat(avgRating)) ? 'text-accent fill-accent' : 'text-muted-foreground/20'}`} />
                ))}
              </div>
              <p className="text-sm text-muted-foreground font-body">{total} reviews</p>
            </div>
            <div className="flex-1 w-full space-y-2">
              {ratingCounts.map(({ stars, count }) => (
                <RatingBar key={stars} stars={stars} count={count} total={total} />
              ))}
            </div>
          </div>
        )}

        <div className="grid grid-cols-1 lg:grid-cols-3 gap-8">
          <div className="lg:col-span-1">
            <ReviewForm onSubmit={(data) => createMutation.mutate(data)} isSubmitting={createMutation.isPending} />
          </div>
          <div className="lg:col-span-2">
            <ReviewsList reviews={reviews} onHelpful={(r) => helpfulMutation.mutate(r)} />
          </div>
        </div>

      </motion.div>
    </div>
  );
}