import React from 'react';
import HeroSection from '../components/home/HeroSection';
import HomePlannerSection from '../components/home/HomePlannerSection';
import FeaturesGrid from '../components/home/FeaturesGrid';
import AffiliateStrip from '../components/home/AffiliateStrip';
import TestimonialsSection from '../components/home/TestimonialsSection';
import SafetyBanner from '../components/home/SafetyBanner';
import GumroadSection from '../components/home/GumroadSection';
import QuickLinksSection from '../components/home/QuickLinksSection';

export default function Home() {
  return (
    <div>
      <HeroSection />
      <HomePlannerSection />
      <GumroadSection />
      <QuickLinksSection />
      <FeaturesGrid />
      <AffiliateStrip />
      <TestimonialsSection />
      <SafetyBanner />
    </div>
  );
}