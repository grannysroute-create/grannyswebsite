import React, { useState } from 'react';
import { motion } from 'framer-motion';
import { Card } from "@/components/ui/card";
import { Badge } from "@/components/ui/badge";
import { ExternalLink, Database, FileText, Map, BarChart3, AlertTriangle, ChevronDown } from 'lucide-react';

const resources = [
  {
    category: 'Bridge Inventory & Clearances',
    icon: Database,
    color: 'bg-primary/10 text-primary',
    items: [
      {
        name: 'National Bridge Inventory (NBI)',
        org: 'FHWA / U.S. DOT',
        description: 'The definitive federal database of over 620,000 bridges in the U.S. Includes vertical clearances, structural condition ratings, load limits, and inspection history for every public road bridge.',
        url: 'https://www.fhwa.dot.gov/bridge/nbi.cfm',
        badge: 'Primary Source',
        badgeColor: 'bg-primary/10 text-primary',
        note: 'This is the data backbone behind most RV bridge safety tools — including our own hazard map.',
      },
      {
        name: 'NBI Data Download (2024)',
        org: 'FHWA',
        description: 'Download the full 2024 NBI ASCII dataset by state. Includes bridge clearance fields (Items 10, 47, 53) used by navigation apps to flag low-clearance structures.',
        url: 'https://www.fhwa.dot.gov/bridge/nbi/ascii2024.cfm',
        badge: 'Raw Data',
        badgeColor: 'bg-secondary text-foreground',
        note: 'Useful for developers building clearance tools. Filter for vertical clearance < your rig height.',
      },
      {
        name: 'National Bridge Inventory — ArcGIS Open Data',
        org: 'MWCOG / FHWA',
        description: 'Interactive map layer of the full NBI dataset. Browse bridge locations, filter by condition, clearance, and year built. Great for visual research before planning a route.',
        url: 'https://rtdc-mwcog.opendata.arcgis.com/datasets/mwcog::national-bridge-inventory-nbi-2023/about',
        badge: 'Interactive Map',
        badgeColor: 'bg-accent/10 text-accent',
        note: 'You can filter to show only bridges under 14 feet clearance — helpful for tall rigs.',
      },
    ],
  },
  {
    category: 'Bridge Condition & Safety Reports',
    icon: BarChart3,
    color: 'bg-accent/10 text-accent',
    items: [
      {
        name: 'Bridge Condition by Highway System (2024)',
        org: 'FHWA',
        description: 'Annual summary of bridge structural conditions across the U.S. highway system. Breaks down poor, fair, and good condition ratings by state and road type.',
        url: 'https://www.fhwa.dot.gov/bridge/nbi/no10/condition24.cfm',
        badge: '2024 Data',
        badgeColor: 'bg-primary/10 text-primary',
        note: 'Structurally deficient bridges are not always visually obvious — this report shows where to be extra cautious.',
      },
      {
        name: 'Structurally Deficient Bridge Report',
        org: 'ARTBA / FHWA',
        description: 'The American Road & Transportation Builders Association publishes an annual state-by-state breakdown of bridges rated structurally deficient — over 43,000 bridges nationwide.',
        url: 'https://artbabridgereport.org/',
        badge: 'Annual Report',
        badgeColor: 'bg-secondary text-foreground',
        note: 'Check your home state and planned travel states before hitting the road.',
      },
    ],
  },
  {
    category: 'Route Planning & Restrictions',
    icon: Map,
    color: 'bg-primary/10 text-primary',
    items: [
      {
        name: 'FHWA Office of Freight Management',
        org: 'FHWA / U.S. DOT',
        description: 'Federal hub for truck and oversized vehicle routing regulations, including height, width, and weight restrictions by corridor and state.',
        url: 'https://www.fhwa.dot.gov/policy/otps/freight.cfm',
        badge: 'Regulations',
        badgeColor: 'bg-secondary text-foreground',
        note: 'Essential reading if you\'re towing a wide load or have an unusually tall or heavy rig.',
      },
      {
        name: 'Permit Routing Information — FHWA',
        org: 'FHWA',
        description: 'State-by-state oversize/overweight permit routing and contact information. Know before you go if your rig needs a special permit for your route.',
        url: 'https://ops.fhwa.dot.gov/freight/sw/permitnet/',
        badge: 'Permits',
        badgeColor: 'bg-accent/10 text-accent',
        note: 'Most Class A motorhomes over 13\'6" may require permits on certain roads or in certain states.',
      },
    ],
  },
  {
    category: 'Safety Notices & Alerts',
    icon: AlertTriangle,
    color: 'bg-destructive/10 text-destructive',
    items: [
      {
        name: 'FHWA Bridge Safety Homepage',
        org: 'FHWA',
        description: 'Central hub for federal bridge safety programs, inspection standards, load rating policies, and safety improvement initiatives.',
        url: 'https://www.fhwa.dot.gov/bridge/safety/',
        badge: 'Official',
        badgeColor: 'bg-primary/10 text-primary',
        note: 'Bookmark this if you\'re serious about understanding the federal standards behind bridge ratings.',
      },
      {
        name: 'NTSB Bridge Accident Reports',
        org: 'National Transportation Safety Board',
        description: 'Detailed investigation reports on major bridge incidents including RV and commercial vehicle bridge strikes. Sobering reading — and a reminder of why clearance matters.',
        url: 'https://www.ntsb.gov/investigations/AccidentReports/Pages/highway.aspx',
        badge: 'Incident Reports',
        badgeColor: 'bg-destructive/10 text-destructive',
        note: 'Real reports, real consequences. A great resource to share with new full-timers.',
      },
    ],
  },
  {
    category: 'Reference Documents',
    icon: FileText,
    color: 'bg-secondary text-foreground',
    items: [
      {
        name: 'Recording and Coding Guide for NBI (PDF)',
        org: 'FHWA',
        description: 'The official manual for interpreting NBI data fields including Item 47 (vertical clearance over deck) and Item 53 (minimum vertical clearance under bridges). Essential for developers and researchers.',
        url: 'https://www.fhwa.dot.gov/bridge/mtguide.pdf',
        badge: 'Technical',
        badgeColor: 'bg-secondary text-foreground',
        note: 'Item 47 is the field you want — it\'s the posted vertical clearance that affects RV routing.',
      },
    ],
  },
];

function ResourceCard({ item }) {
  const [expanded, setExpanded] = useState(false);
  return (
    <Card
      className="border-border hover:shadow-md hover:border-primary/20 transition-all duration-200 overflow-hidden cursor-pointer"
      onClick={() => setExpanded(e => !e)}
    >
      <div className="p-5 flex items-start gap-4">
        <div className="flex-1 min-w-0">
          <div className="flex items-start justify-between gap-2 flex-wrap">
            <div>
              <h3 className="font-heading font-semibold text-foreground leading-snug">{item.name}</h3>
              <p className="text-xs text-muted-foreground font-body mt-0.5">{item.org}</p>
            </div>
            <Badge className={`${item.badgeColor} text-xs shrink-0 font-body`}>{item.badge}</Badge>
          </div>
        </div>
        <ChevronDown
          className={`w-4 h-4 text-muted-foreground shrink-0 transition-transform duration-200 mt-1 ${expanded ? 'rotate-180' : ''}`}
        />
      </div>

      {expanded && (
        <div className="px-5 pb-5 pt-0 border-t border-border">
          <p className="text-sm font-body text-foreground leading-relaxed mt-4 mb-2">{item.description}</p>
          <p className="text-xs text-muted-foreground font-body italic mb-4">"{item.note}"</p>
          <a
            href={item.url}
            target="_blank"
            rel="noopener noreferrer"
            onClick={e => e.stopPropagation()}
            className="inline-flex items-center gap-1.5 text-sm font-body text-primary font-medium hover:underline"
          >
            Open Resource <ExternalLink className="w-3.5 h-3.5" />
          </a>
        </div>
      )}
    </Card>
  );
}

export default function DOTResources() {
  return (
    <div className="max-w-5xl mx-auto px-4 sm:px-6 lg:px-8 py-10 md:py-16">
      <motion.div initial={{ opacity: 0, y: 20 }} animate={{ opacity: 1, y: 0 }}>

        {/* Header */}
        <div className="text-center mb-12">
          <div className="inline-flex items-center gap-2 px-4 py-1.5 rounded-full bg-primary/10 border border-primary/20 mb-5">
            <Database className="w-4 h-4 text-primary" />
            <span className="text-sm font-body font-medium text-primary">Official Government Data</span>
          </div>
          <h1 className="font-heading text-4xl md:text-5xl font-bold text-foreground mb-4">
            DOT Bridge Resources
          </h1>
          <p className="text-muted-foreground font-body text-lg max-w-2xl mx-auto leading-relaxed">
            Direct links to FHWA, NBI, and NTSB data — the official federal sources behind bridge clearance and safety information used by RVers and navigation apps nationwide.
          </p>
          <p className="text-xs text-muted-foreground/60 font-body mt-3">
            ✦ Tap any card to expand details and access the resource.
          </p>
        </div>

        {/* Resource Groups */}
        <div className="space-y-12">
          {resources.map((group, gi) => (
            <motion.div
              key={group.category}
              initial={{ opacity: 0, y: 20 }}
              whileInView={{ opacity: 1, y: 0 }}
              viewport={{ once: true }}
              transition={{ delay: gi * 0.05 }}
            >
              <div className="flex items-center gap-3 mb-5">
                <div className={`w-9 h-9 rounded-xl ${group.color} flex items-center justify-center`}>
                  <group.icon className="w-5 h-5" />
                </div>
                <h2 className="font-heading text-xl font-semibold text-foreground">{group.category}</h2>
              </div>
              <div className="grid grid-cols-1 gap-4">
                {group.items.map((item, ii) => (
                  <ResourceCard key={ii} item={item} />
                ))}
              </div>
            </motion.div>
          ))}
        </div>

        {/* Footer note */}
        <motion.div
          initial={{ opacity: 0 }}
          whileInView={{ opacity: 1 }}
          viewport={{ once: true }}
          className="mt-14 p-6 rounded-2xl bg-primary/5 border border-primary/15 text-center"
        >
          <p className="font-heading text-base font-semibold text-foreground mb-1">
            Data freshness matters on the road.
          </p>
          <p className="text-sm text-muted-foreground font-body">
            The NBI is updated annually. Always cross-reference official DOT data with community reports —
            field conditions can change faster than federal databases are updated.
          </p>
        </motion.div>

      </motion.div>
    </div>
  );
}