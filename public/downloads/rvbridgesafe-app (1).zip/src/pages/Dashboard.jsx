import React from 'react';
import { Link } from 'react-router-dom';
import { base44 } from '@/api/base44Client';
import { useQuery } from '@tanstack/react-query';
import { Button } from "@/components/ui/button";
import { Route, Map } from 'lucide-react';
import QuickStats from '../components/dashboard/QuickStats';
import RigCard from '../components/dashboard/RigCard';
import RecentAlerts from '../components/dashboard/RecentAlerts';
import UpgradeBanner from '../components/dashboard/UpgradeBanner';

export default function Dashboard() {
  const { data: rigs } = useQuery({
    queryKey: ['rigs'],
    queryFn: () => base44.entities.RigProfile.list(),
    initialData: [],
  });

  const { data: reports } = useQuery({
    queryKey: ['reports'],
    queryFn: () => base44.entities.BridgeReport.list('-created_date', 10),
    initialData: [],
  });

  const activeRig = rigs.find(r => r.is_active) || rigs[0];

  return (
    <div className="max-w-7xl mx-auto px-4 sm:px-6 lg:px-8 py-6 md:py-9">
      <div className="flex flex-col sm:flex-row items-start sm:items-center justify-between gap-3 mb-6">
        <div>
          <h1 className="font-heading text-3xl font-bold text-foreground">Welcome back, traveler</h1>
          <p className="text-muted-foreground font-body mt-1">Here's what's happening on the road today.</p>
        </div>
        <Link to="/route-planner">
          <Button className="gap-2 rounded-xl font-body">
            <Route className="w-4 h-4" />
            Plan a Route
          </Button>
        </Link>
      </div>

      <QuickStats />

      <div className="grid grid-cols-1 lg:grid-cols-3 gap-5 mt-6">
        <div className="lg:col-span-1">
          <h2 className="font-heading text-lg font-semibold text-foreground mb-4">My Rig</h2>
          <RigCard rig={activeRig} />
        </div>
        <div className="lg:col-span-2">
          <div className="flex items-center justify-between mb-4">
            <h2 className="font-heading text-lg font-semibold text-foreground">Recent Alerts</h2>
            <Link to="/community">
              <Button variant="ghost" size="sm" className="font-body text-sm gap-1">
                View All
                <Map className="w-3.5 h-3.5" />
              </Button>
            </Link>
          </div>
          <RecentAlerts reports={reports} />
        </div>
      </div>
    </div>
  );
}