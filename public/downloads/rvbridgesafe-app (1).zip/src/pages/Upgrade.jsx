import React from 'react';
import { motion } from 'framer-motion';
import { Button } from "@/components/ui/button";
import { Card } from "@/components/ui/card";
import { Badge } from "@/components/ui/badge";
import {
  Shield, Check, Star, Zap, WifiOff, Map,
  Route, Bell, Users, Crown, ArrowRight, X, Minus
} from 'lucide-react';

const allFeatures = [
  'Full rig profile setup',
  'Community hazard reports & upvotes',
  'Interactive hazard map (DOT data)',
  'Route planner',
  'Unlimited saved routes',
  'Bridge strike alerts from community',
  'Reviews & community tips',
  'Gear & affiliate recommendations',
  'Offline route pack download (HTML)',
  '100% free — no credit card ever',
];

const plans = [
  {
    name: 'Free Forever',
    badge: '🎉 Always Free',
    price: '$0',
    period: 'forever',
    description: "Every feature, every tool — at no cost. RVBridgeSafe is and always will be free.",
    features: allFeatures,
    cta: "You're Already In!",
    disabled: true,
    highlight: true,
  },
  {
    name: "Granny's Route",
    badge: 'Coming Soon',
    price: 'TBD',
    period: 'optional add-on',
    description: "Our upcoming premium layer — real-time alerts, offline maps, AI routing. Join the waitlist at GrannysRoute.org!",
    features: [
      'Everything in Free',
      'AI-powered RV-Safe routing',
      'Real-time 1-mile advance alerts',
      'Offline maps & route packs — all 50 states',
      'Apple CarPlay & Android Auto',
      'Priority DOT database updates',
      'Ad-free experience',
      'Early access to new features',
    ],
    cta: 'Visit GrannysRoute.org',
    proLink: 'https://grannysroute.org',
    highlight: false,
    comingSoon: true,
  },
];

const testimonialQuote = {
  text: "I can't believe this is free. It routed me around a bridge I had no idea was there. Absolute lifesaver.",
  author: "Carolyn D., Class A, Texas"
};

export default function Upgrade() {
  return (
    <div className="max-w-6xl mx-auto px-4 sm:px-6 lg:px-8 py-10 md:py-16">
      <motion.div initial={{ opacity: 0, y: 20 }} animate={{ opacity: 1, y: 0 }}>

        {/* Header */}
        <div className="text-center mb-14">
          <div className="inline-flex items-center gap-2 px-4 py-1.5 rounded-full bg-primary/10 border border-primary/20 mb-5">
            <Shield className="w-4 h-4 text-primary" />
            <span className="text-sm font-body font-medium text-primary">100% Free Product</span>
          </div>
          <h1 className="font-heading text-4xl md:text-5xl font-bold text-foreground mb-4">
            Free. Forever. For RVers.
          </h1>
          <p className="text-muted-foreground font-body text-lg max-w-2xl mx-auto">
            RVBridgeSafe is a free community safety tool — every feature is included at no cost.
            Our premium add-on, Granny's Route, is coming soon for those who want even more.
          </p>
        </div>

        {/* Pricing Cards */}
        <div className="grid grid-cols-1 md:grid-cols-2 gap-6 mb-16 max-w-3xl mx-auto">
          {plans.map((plan, i) => (
            <motion.div
              key={plan.name}
              initial={{ opacity: 0, y: 20 }}
              animate={{ opacity: 1, y: 0 }}
              transition={{ delay: i * 0.1 }}
            >
              <Card className={`relative p-7 flex flex-col h-full ${plan.highlight ? 'border-primary ring-2 ring-primary/20 shadow-xl shadow-primary/10' : 'border-border'}`}>
                {plan.badge && (
                  <div className="absolute -top-3 left-1/2 -translate-x-1/2">
                    <Badge className={`px-3 py-1 font-body text-xs ${plan.comingSoon ? 'bg-accent text-accent-foreground' : 'bg-primary text-primary-foreground'}`}>
                      {plan.badge}
                    </Badge>
                  </div>
                )}

                <div className="mb-6">
                  <h3 className="font-heading text-xl font-bold text-foreground mb-1">{plan.name}</h3>
                  <p className="text-sm text-muted-foreground font-body mb-4">{plan.description}</p>
                  <div className="flex items-end gap-2">
                    <span className="font-heading text-4xl font-bold text-foreground">{plan.price}</span>
                    <span className="text-muted-foreground font-body text-sm mb-1">/{plan.period}</span>
                  </div>
                </div>

                <ul className="space-y-2.5 flex-1 mb-6">
                  {plan.features.map((f, j) => (
                    <li key={j} className="flex items-start gap-2.5">
                      <Check className="w-4 h-4 text-primary shrink-0 mt-0.5" />
                      <span className="text-sm font-body text-foreground">{f}</span>
                    </li>
                  ))}
                </ul>

                {plan.comingSoon ? (
                  <a href={plan.proLink} target="_blank" rel="noopener noreferrer">
                    <Button className="w-full rounded-xl font-body gap-2" variant="outline">
                      {plan.cta} <ArrowRight className="w-4 h-4" />
                    </Button>
                  </a>
                ) : (
                  <Button className="w-full rounded-xl font-body" variant={plan.highlight ? 'default' : 'secondary'} disabled={plan.disabled}>
                    {plan.cta}
                  </Button>
                )}
              </Card>
            </motion.div>
          ))}
        </div>

        {/* Competitor Comparison */}
        <motion.div
          initial={{ opacity: 0, y: 20 }}
          whileInView={{ opacity: 1, y: 0 }}
          viewport={{ once: true }}
          className="mb-16"
        >
          <div className="text-center mb-8">
            <h2 className="font-heading text-2xl md:text-3xl font-bold text-foreground mb-2">How We Compare</h2>
            <p className="text-muted-foreground font-body">RVBridgeSafe vs. the other bridge-safety & RV routing apps</p>
          </div>

          <div className="overflow-x-auto rounded-2xl border border-border">
            <table className="w-full text-sm font-body">
              <thead>
                <tr className="bg-secondary/60 border-b border-border">
                  <th className="text-left p-4 font-heading font-semibold text-foreground min-w-[180px]">Feature</th>
                  {[
                    { name: 'RVBridgeSafe', sub: 'Free', highlight: true },
                    { name: 'HeadRoom', sub: '$4.99/mo', highlight: false },
                    { name: 'SmartTruckRoute', sub: '$15.95/mo', highlight: false },
                    { name: 'CoPilot Truck', sub: '$14.99/yr+', highlight: false },
                    { name: 'RV Trip Wizard', sub: '$39.99/yr', highlight: false },
                  ].map((app) => (
                    <th key={app.name} className={`p-4 text-center font-heading font-semibold min-w-[120px] ${app.highlight ? 'text-primary bg-primary/5' : 'text-foreground'}`}>
                      <div>{app.name}</div>
                      <div className={`text-xs font-body font-normal mt-0.5 ${app.highlight ? 'text-primary' : 'text-muted-foreground'}`}>{app.sub}</div>
                    </th>
                  ))}
                </tr>
              </thead>
              <tbody>
                {[
                  { feature: 'RV-specific routing', vals: [true, true, true, true, true] },
                  { feature: 'Community hazard reports', vals: [true, false, false, false, false] },
                  { feature: 'Bridge strike alerts', vals: [true, true, false, false, false] },
                  { feature: 'Interactive hazard map', vals: [true, false, false, false, true] },
                  { feature: 'Rig profile (height/weight)', vals: [true, true, true, true, true] },
                  { feature: 'Reroute around low bridges', vals: [true, true, true, true, 'partial'] },
                  { feature: 'Offline route packs', vals: [true, false, false, true, false] },
                  { feature: 'Verified bridge database', vals: ['community', '23k+', 'yes', 'yes', 'yes'] },
                  { feature: 'Completely free', vals: [true, false, false, false, false] },
                  { feature: 'RV community reviews', vals: [true, false, false, false, false] },
                ].map((row, ri) => (
                  <tr key={ri} className={`border-b border-border last:border-0 ${ri % 2 === 0 ? '' : 'bg-muted/30'}`}>
                    <td className="p-4 text-foreground font-medium">{row.feature}</td>
                    {row.vals.map((val, vi) => (
                      <td key={vi} className={`p-4 text-center ${vi === 0 ? 'bg-primary/5' : ''}`}>
                        {val === true && <Check className="w-4 h-4 text-primary mx-auto" />}
                        {val === false && <X className="w-4 h-4 text-muted-foreground/40 mx-auto" />}
                        {val === 'partial' && <Minus className="w-4 h-4 text-accent mx-auto" />}
                        {val === 'soon' && <span className="text-xs text-accent font-body font-medium">Soon</span>}
                        {val === 'community' && <span className="text-xs text-primary font-body font-medium">Community</span>}
                        {val === '23k+' && <span className="text-xs text-muted-foreground font-body">23k+</span>}
                        {val === 'yes' && <Check className="w-4 h-4 text-muted-foreground mx-auto" />}
                      </td>
                    ))}
                  </tr>
                ))}
              </tbody>
            </table>
          </div>
          <p className="text-xs text-muted-foreground/50 font-body text-center mt-3">
            Competitor data sourced from public listings as of 2026. Features subject to change.
          </p>
        </motion.div>

        {/* Testimonial */}
        <motion.div
          initial={{ opacity: 0 }}
          whileInView={{ opacity: 1 }}
          viewport={{ once: true }}
          className="bg-secondary/60 rounded-2xl p-8 text-center mb-16 max-w-2xl mx-auto"
        >
          <div className="flex justify-center gap-1 mb-3">
            {[...Array(5)].map((_, i) => <Star key={i} className="w-4 h-4 text-accent fill-accent" />)}
          </div>
          <p className="font-body text-foreground text-lg italic mb-3">"{testimonialQuote.text}"</p>
          <p className="text-sm text-muted-foreground font-body">— {testimonialQuote.author}</p>
        </motion.div>

        {/* Feature highlights */}
        <div className="grid grid-cols-2 md:grid-cols-4 gap-5">
          {[
            { icon: Bell, label: 'Real-Time Alerts', sub: '1 mile advance warning' },
            { icon: WifiOff, label: 'Full Offline Maps', sub: 'All 50 states downloaded' },
            { icon: Route, label: 'AI Route Planning', sub: 'Built for your exact rig' },
            { icon: Map, label: 'CarPlay Ready', sub: 'Eyes on the road' },
          ].map((item, i) => (
            <div key={i} className="text-center p-5 rounded-2xl bg-card border border-border">
              <div className="w-12 h-12 rounded-xl bg-primary/10 flex items-center justify-center mx-auto mb-3">
                <item.icon className="w-6 h-6 text-primary" />
              </div>
              <p className="font-heading font-semibold text-sm text-foreground">{item.label}</p>
              <p className="text-xs text-muted-foreground font-body mt-1">{item.sub}</p>
            </div>
          ))}
        </div>

      </motion.div>
    </div>
  );
}