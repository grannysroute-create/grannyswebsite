import React, { useState, useRef } from 'react';
import { base44 } from '@/api/base44Client';
import { useQuery, useMutation, useQueryClient } from '@tanstack/react-query';
import { MapContainer, TileLayer, CircleMarker, Popup, useMap } from 'react-leaflet';
import { motion } from 'framer-motion';
import { Map, Layers, RefreshCw } from 'lucide-react';
import { Button } from "@/components/ui/button";
import { Badge } from "@/components/ui/badge";
import { toast } from "sonner";
import HazardPopup from '../components/map/HazardPopup';
import MapLegend from '../components/map/MapLegend';
import MapDisclaimer from '../components/map/MapDisclaimer';
import 'leaflet/dist/leaflet.css';

// Pin color by report type
const pinColor = (report) => {
  if (report.report_type === 'bridge_strike') return '#dc2626';
  if (report.report_type === 'low_clearance') return '#f59e0b';
  if (report.report_type === 'close_call') return '#f97316';
  if (report.report_type === 'weight_restriction') return '#8b5cf6';
  if (report.report_type === 'steep_grade') return '#3b82f6';
  return '#6b7280';
};

const pinRadius = (report) => {
  if (report.severity === 'danger') return 11;
  if (report.severity === 'warning') return 9;
  return 7;
};

// Synthetic coordinates for seeded reports (real lat/lng for US locations)
const FALLBACK_COORDS = [
  { lat: 39.6418, lng: -77.7199 }, // Hagerstown MD
  { lat: 35.5, lng: -82.5 },       // Blue Ridge Parkway NC
  { lat: 35.2, lng: -101.8 },      // Amarillo TX
  { lat: 40.7, lng: -74.2 },       // NJ I-78
  { lat: 39.6, lng: -105.9 },      // Eisenhower Tunnel CO
  { lat: 42.8, lng: -76.9 },       // Finger Lakes NY
];

// Assign fallback coords if none on record
function getCoords(report, index) {
  if (report.latitude && report.longitude) {
    return [report.latitude, report.longitude];
  }
  // Spread pins across the US map using fallbacks deterministically
  const fb = FALLBACK_COORDS[index % FALLBACK_COORDS.length];
  return [fb.lat, fb.lng];
}

const typeLabels = {
  low_clearance: 'Low Clearance',
  close_call: 'Close Call',
  bridge_strike: 'Bridge Strike',
  tight_turn: 'Tight Turn',
  steep_grade: 'Steep Grade',
  weight_restriction: 'Weight Restriction',
  road_closed: 'Road Closed',
};

export default function HazardMap() {
  const queryClient = useQueryClient();
  const [selectedReport, setSelectedReport] = useState(null);
  const [filter, setFilter] = useState('all');

  const { data: reports, isLoading } = useQuery({
    queryKey: ['reports'],
    queryFn: () => base44.entities.BridgeReport.list('-created_date', 100),
    initialData: [],
  });

  const upvoteMutation = useMutation({
    mutationFn: (report) =>
      base44.entities.BridgeReport.update(report.id, { upvotes: (report.upvotes || 0) + 1 }),
    onSuccess: () => {
      queryClient.invalidateQueries({ queryKey: ['reports'] });
      toast.success("Marked as helpful!");
    },
  });

  const filterTypes = [
    { value: 'all', label: 'All' },
    { value: 'bridge_strike', label: 'Bridge Strikes' },
    { value: 'low_clearance', label: 'Low Clearance' },
    { value: 'close_call', label: 'Close Calls' },
    { value: 'weight_restriction', label: 'Weight Limits' },
    { value: 'steep_grade', label: 'Steep Grades' },
  ];

  const filtered = filter === 'all' ? reports : reports.filter(r => r.report_type === filter);

  return (
    <div className="max-w-7xl mx-auto px-4 sm:px-6 lg:px-8 py-6 md:py-9">
      <motion.div initial={{ opacity: 0, y: 20 }} animate={{ opacity: 1, y: 0 }}>

        {/* Header */}
        <div className="flex flex-col sm:flex-row items-start sm:items-center justify-between gap-3 mb-5">
          <div>
            <div className="flex items-center gap-2 mb-1">
              <div className="w-9 h-9 rounded-xl bg-primary/10 flex items-center justify-center">
                <Map className="w-5 h-5 text-primary" />
              </div>
              <h1 className="font-heading text-3xl font-bold text-foreground">Hazard Map</h1>
            </div>
            <p className="text-muted-foreground font-body text-sm">
              Community-reported hazards + U.S. DOT / FHWA bridge data.{' '}
              <span className="text-amber-600 font-medium">See disclaimer below.*</span>
            </p>
          </div>
          <div className="flex items-center gap-2">
            <Badge variant="secondary" className="font-body">
              {filtered.length} hazard{filtered.length !== 1 ? 's' : ''}
            </Badge>
            <Button
              variant="outline"
              size="sm"
              className="rounded-xl font-body gap-2"
              onClick={() => queryClient.invalidateQueries({ queryKey: ['reports'] })}
            >
              <RefreshCw className="w-3.5 h-3.5" /> Refresh
            </Button>
          </div>
        </div>

        {/* Filter tabs */}
        <div className="flex flex-wrap gap-2 mb-3">
          {filterTypes.map(ft => (
            <button
              key={ft.value}
              onClick={() => setFilter(ft.value)}
              className={`px-3 py-1.5 rounded-full text-xs font-body font-medium border transition-all ${
                filter === ft.value
                  ? 'bg-primary text-primary-foreground border-primary'
                  : 'bg-card text-muted-foreground border-border hover:border-primary/40'
              }`}
            >
              {ft.label}
            </button>
          ))}
        </div>

        {/* Map */}
        <div className="relative rounded-2xl overflow-hidden border border-border shadow-xl" style={{ height: '520px' }}>
          {isLoading && (
            <div className="absolute inset-0 bg-background/60 z-50 flex items-center justify-center">
              <div className="w-8 h-8 border-4 border-primary/30 border-t-primary rounded-full animate-spin" />
            </div>
          )}

          <MapContainer
            center={[39.5, -98.35]}
            zoom={4}
            style={{ height: '100%', width: '100%' }}
            scrollWheelZoom={true}
          >
            <TileLayer
              url="https://{s}.tile.openstreetmap.org/{z}/{x}/{y}.png"
              attribution='&copy; <a href="https://www.openstreetmap.org/copyright">OpenStreetMap</a> contributors'
            />

            {filtered.map((report, index) => {
              const [lat, lng] = getCoords(report, index);
              const color = pinColor(report);
              const radius = pinRadius(report);
              return (
                <CircleMarker
                  key={report.id}
                  center={[lat, lng]}
                  radius={radius}
                  pathOptions={{
                    color: report.verified ? '#16a34a' : color,
                    fillColor: color,
                    fillOpacity: 0.85,
                    weight: report.verified ? 3 : 2,
                  }}
                  eventHandlers={{
                    click: () => setSelectedReport(report),
                  }}
                >
                  <Popup>
                    <HazardPopup
                      report={report}
                      onUpvote={(r) => upvoteMutation.mutate(r)}
                      onClose={() => setSelectedReport(null)}
                    />
                  </Popup>
                </CircleMarker>
              );
            })}
          </MapContainer>

          {/* Legend overlay */}
          <div className="absolute bottom-4 left-4 z-[999]">
            <MapLegend />
          </div>
        </div>

        {/* Quick stats row */}
        <div className="grid grid-cols-2 sm:grid-cols-4 gap-3 mt-3">
          {[
            { label: 'Bridge Strikes', count: reports.filter(r => r.report_type === 'bridge_strike').length, color: 'bg-red-100 text-red-700' },
            { label: 'Low Clearances', count: reports.filter(r => r.report_type === 'low_clearance').length, color: 'bg-amber-100 text-amber-700' },
            { label: 'Close Calls', count: reports.filter(r => r.report_type === 'close_call').length, color: 'bg-orange-100 text-orange-700' },
            { label: 'DOT Verified', count: reports.filter(r => r.verified).length, color: 'bg-green-100 text-green-700' },
          ].map((stat, i) => (
            <div key={i} className={`rounded-xl p-3 text-center font-body ${stat.color}`}>
              <p className="text-2xl font-bold font-heading">{stat.count}</p>
              <p className="text-xs">{stat.label}</p>
            </div>
          ))}
        </div>

        {/* Disclaimer */}
        <div className="mt-5">
          <MapDisclaimer />
        </div>

      </motion.div>
    </div>
  );
}