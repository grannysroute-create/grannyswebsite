import React, { useState } from 'react';
import { motion } from 'framer-motion';
import { Button } from "@/components/ui/button";
import { Card } from "@/components/ui/card";
import { Badge } from "@/components/ui/badge";
import { base44 } from '@/api/base44Client';
import { toast } from "sonner";
import {
  Download, ShoppingCart, FileText, CheckCircle2,
  ExternalLink, Clipboard, ClipboardCheck, ArrowRight
} from 'lucide-react';

const GUMROAD_URL = 'https://grannysroute.gumroad.com/l/rvbridgesafe';

// ─── FILE BUILDERS ────────────────────────────────────────────────────────────

function buildSellerInstructionsHTML() {
  return `<!DOCTYPE html>
<html lang="en">
<head>
  <meta charset="UTF-8"/>
  <meta name="viewport" content="width=device-width, initial-scale=1.0"/>
  <title>Granny's Route — Gumroad Seller Setup Guide</title>
  <style>
    body { font-family: system-ui, sans-serif; max-width: 720px; margin: 0 auto; padding: 28px 20px; background: #f9f7f2; color: #1a2e1f; }
    h1 { font-size: 1.6rem; margin-bottom: 4px; }
    .badge { display:inline-block; background:#d1fae5; color:#065f46; padding:4px 12px; border-radius:20px; font-size:0.75rem; margin-bottom:20px; font-weight:600; }
    h2 { font-size: 1.05rem; color: #3d7a5a; margin: 28px 0 8px; border-bottom: 1px solid #e5e7eb; padding-bottom: 4px; }
    .step { background: white; border-radius: 12px; padding: 18px 20px; margin-bottom: 12px; border: 1px solid #e5e7eb; }
    .step-num { display:inline-block; background:#3d7a5a; color:white; border-radius:50%; width:24px; height:24px; text-align:center; line-height:24px; font-size:0.8rem; font-weight:700; margin-right:8px; }
    code { background:#f3f4f6; padding:2px 7px; border-radius:6px; font-size:0.85rem; }
    .box { background:#fef3c7; border-left:4px solid #d97706; border-radius:8px; padding:12px 16px; font-size:0.88rem; margin:12px 0; }
    ul { padding-left: 20px; } li { margin-bottom: 6px; font-size:0.92rem; }
    a { color:#3d7a5a; }
    .footer { text-align:center; font-size:0.75rem; color:#9ca3af; margin-top:40px; padding-top:16px; border-top:1px solid #e5e7eb; }
  </style>
</head>
<body>
  <div class="badge">✅ Seller Guide — Keep This File</div>
  <h1>Granny's Route on Gumroad</h1>
  <p style="color:#6b7280;font-size:0.9rem;margin-bottom:28px;">Step-by-step instructions for setting up and selling your offline route pack product on Gumroad.</p>

  <h2>Step 1 — Create Your Gumroad Account</h2>
  <div class="step">
    <span class="step-num">1</span> Go to <a href="https://gumroad.com" target="_blank">gumroad.com</a> and sign up for a free account.<br/><br/>
    <span class="step-num">2</span> Connect your bank account or PayPal under <strong>Settings → Payouts</strong>.<br/><br/>
    <span class="step-num">3</span> Gumroad takes a <strong>10% fee</strong> on each sale (no monthly charge on the free plan).
  </div>

  <h2>Step 2 — Create the Product Listing</h2>
  <div class="step">
    <span class="step-num">1</span> Click <strong>+ New Product</strong> → choose <strong>Digital Product</strong>.<br/><br/>
    <span class="step-num">2</span> Set the product name: <code>Granny's Route — RV-Safe Offline Route Pack</code><br/><br/>
    <span class="step-num">3</span> Set price. Suggested: <code>$9</code> (or "pay what you want" with $5 minimum).<br/><br/>
    <span class="step-num">4</span> Upload your <strong>offline route HTML file</strong> as the downloadable product file.<br/><br/>
    <span class="step-num">5</span> Use the product description below (copy-paste ready):
  </div>

  <h2>Step 3 — Copy-Paste Product Description</h2>
  <div class="step">
    <pre style="white-space:pre-wrap;font-size:0.85rem;color:#374151;background:#f9fafb;padding:14px;border-radius:8px;line-height:1.6;">🚐 Granny's Route — RV-Safe Offline Route Pack

Never get surprised by a low bridge again.

This offline route pack opens in any browser — no cell service, no app needed. Perfect for rural stretches with zero signal.

✅ What's included:
• Pre-planned RV-safe routes avoiding low bridges, weight limits & tight turns
• Hazard details with clearance heights
• Fuel stop suggestions
• Printable format — works on any device

🔒 Works 100% offline — just open the HTML file in Chrome, Safari or Firefox
📱 Save to your phone for instant access on the road

Questions? Reply to your Gumroad receipt and we'll help you out.

Safe travels, dear! 🌿 — The RVBridgeSafe Team</pre>
  </div>

  <h2>Step 4 — Set Your Gumroad Product URL</h2>
  <div class="step">
    Under <strong>Product → Permalink</strong>, set a clean URL like: <code>grannysroute</code><br/>
    Your product link will be: <code>https://[yourname].gumroad.com/l/grannysroute</code><br/><br/>
    Update the link in the RVBridgeSafe app (<code>components/home/GumroadSection.jsx</code>, line 7) to match your real URL.
  </div>

  <h2>Step 5 — Add a Cover Image</h2>
  <div class="step">
    Use a landscape RV/road photo. Recommended size: <strong>1280 × 720px</strong>.<br/>
    Free photos: <a href="https://unsplash.com/s/photos/rv-road" target="_blank">unsplash.com/s/photos/rv-road</a>
  </div>

  <h2>Step 6 — Publish & Test</h2>
  <div class="step">
    <span class="step-num">1</span> Hit <strong>Publish</strong> on Gumroad.<br/><br/>
    <span class="step-num">2</span> Do a test purchase using Gumroad's "Buy as a test" button.<br/><br/>
    <span class="step-num">3</span> Confirm the HTML file downloads and opens correctly offline.<br/><br/>
    <span class="step-num">4</span> Update the <code>GUMROAD_URL</code> constant in the app to your live product URL.
  </div>

  <div class="box">
    💡 <strong>Tip:</strong> Offer a free sample (Nashville → Memphis) to build trust. The app already has a "Free Sample Download" button that handles this automatically.
  </div>

  <h2>Useful Links</h2>
  <ul>
    <li><a href="https://gumroad.com" target="_blank">Gumroad Dashboard</a></li>
    <li><a href="https://help.gumroad.com" target="_blank">Gumroad Help Center</a></li>
    <li><a href="https://grannysroute.org" target="_blank">GrannysRoute.org</a></li>
    <li><a href="https://rvbridgesafe.org" target="_blank">RVBridgeSafe.org</a></li>
  </ul>

  <div class="footer">Generated by RVBridgeSafe · rvbridgesafe.org · ${new Date().toLocaleDateString('en-US', { year: 'numeric', month: 'long', day: 'numeric' })}</div>
</body>
</html>`;
}

function buildProductFileHTML() {
  return `<!DOCTYPE html>
<html lang="en">
<head>
  <meta charset="UTF-8"/>
  <meta name="viewport" content="width=device-width, initial-scale=1.0"/>
  <title>Granny's Route — RV-Safe Offline Route Pack</title>
  <style>
    body { font-family: system-ui, sans-serif; max-width: 720px; margin: 0 auto; padding: 24px 20px; background: #f9f7f2; color: #1a2e1f; }
    h1 { font-size: 1.5rem; margin-bottom: 4px; }
    .badge { display:inline-block; background:#d1fae5; color:#065f46; padding:4px 12px; border-radius:20px; font-size:0.75rem; margin-bottom:20px; font-weight:600; }
    .stats { display: grid; grid-template-columns: repeat(3, 1fr); gap: 12px; margin-bottom: 20px; }
    .stat { background: white; border-radius: 12px; padding: 16px; text-align: center; border: 1px solid #e5e7eb; }
    .stat-val { font-size: 1.8rem; font-weight: 700; color: #3d7a5a; }
    .stat-lbl { font-size: 0.75rem; color: #9ca3af; }
    .section { background: white; border-radius: 12px; padding: 18px 20px; margin-bottom: 14px; border: 1px solid #e5e7eb; }
    h2 { color: #3d7a5a; font-size: 1rem; margin-bottom: 10px; }
    .hazard { padding: 10px; background: #fdf8f0; border-left: 3px solid #d97706; border-radius: 8px; margin-bottom: 8px; }
    .hazard strong { font-size:0.92rem; }
    .sub { font-size: 0.8rem; color: #6b7280; }
    .tip { background:#f0fdf4; border-left:3px solid #3d7a5a; border-radius:8px; padding:10px 14px; font-size:0.85rem; margin-bottom:8px; }
    .footer { text-align:center; font-size:0.75rem; color:#9ca3af; margin-top:32px; padding-top:12px; border-top:1px solid #e5e7eb; }
  </style>
</head>
<body>
  <div class="badge">📴 Offline Pack — Granny's Route by RVBridgeSafe</div>
  <h1>Nashville, TN → Memphis, TN</h1>
  <p style="color:#6b7280;font-size:0.85rem;margin-bottom:20px;">RV-safe route · Generated ${new Date().toLocaleDateString('en-US', { year:'numeric', month:'long', day:'numeric' })}</p>

  <div class="stats">
    <div class="stat"><div class="stat-val">212</div><div class="stat-lbl">miles</div></div>
    <div class="stat"><div class="stat-val">3.5</div><div class="stat-lbl">hours</div></div>
    <div class="stat"><div class="stat-val">2</div><div class="stat-lbl">fuel stops</div></div>
  </div>

  <div class="section">
    <h2>📝 Route Summary</h2>
    <p style="font-size:0.9rem;line-height:1.6;color:#374151;">
      Head west on I-40 from Nashville to Memphis. This route is pre-cleared for Class A, 5th wheel, and travel trailers up to 13'6". Two low-clearance bridges on US-70 and one weight-restricted county road near Jackson have been routed around. Smooth sailing — no propane restrictions on this corridor.
    </p>
  </div>

  <div class="section">
    <h2>⛽ Fuel Stops</h2>
    <div class="tip">🛢 <strong>Pilot Travel Center</strong> — Mile Marker 179, Lebanon, TN · Pull-through bays available</div>
    <div class="tip">🛢 <strong>Love's Travel Stop</strong> — Mile Marker 87, Jackson, TN · RV dump station on site</div>
  </div>

  <div class="section">
    <h2>⚠️ Hazards Avoided (3)</h2>
    <div class="hazard"><strong>Old Hickory Blvd Bridge, Nashville</strong> — Low Clearance<br/><span class="sub">Posted 11'6" — community-verified dangerous for rigs over 11'</span></div>
    <div class="hazard"><strong>US-70 Overpass at Lebanon</strong> — Bridge Strike Risk<br/><span class="sub">12'2" clearance — reported tight fit for Class A coaches</span></div>
    <div class="hazard"><strong>County Rd 45 Near Jackson</strong> — Weight Restriction<br/><span class="sub">10-ton limit — avoid if fully loaded 5th wheel or toy hauler</span></div>
  </div>

  <div class="section">
    <h2>📋 Pre-Drive Checklist</h2>
    <div class="tip">✅ Confirm your rig height matches the clearances above</div>
    <div class="tip">✅ Check weather — I-40 West can have crosswinds near Jackson</div>
    <div class="tip">✅ Screenshot or print this page before leaving cell range</div>
    <div class="tip">✅ Always verify bridge signs visually — never trust data alone</div>
  </div>

  <div class="footer">Granny's Route · Powered by RVBridgeSafe · rvbridgesafe.org · Safe travels! 🚐</div>
</body>
</html>`;
}

// ─── STEP COMPONENT ───────────────────────────────────────────────────────────

function Step({ num, title, children }) {
  return (
    <div className="flex gap-4">
      <div className="w-8 h-8 rounded-full bg-primary text-primary-foreground flex items-center justify-center font-heading font-bold text-sm shrink-0 mt-0.5">
        {num}
      </div>
      <div className="flex-1 pb-6 border-b border-border last:border-0">
        <h3 className="font-heading font-semibold text-foreground mb-2">{title}</h3>
        <div className="font-body text-sm text-muted-foreground space-y-1">{children}</div>
      </div>
    </div>
  );
}

// ─── COPY BUTTON ─────────────────────────────────────────────────────────────

function CopyButton({ text }) {
  const [copied, setCopied] = useState(false);
  const handleCopy = () => {
    navigator.clipboard.writeText(text);
    setCopied(true);
    setTimeout(() => setCopied(false), 2000);
  };
  return (
    <button onClick={handleCopy} className="flex items-center gap-1.5 text-xs text-primary hover:underline font-body mt-1">
      {copied ? <ClipboardCheck className="w-3.5 h-3.5" /> : <Clipboard className="w-3.5 h-3.5" />}
      {copied ? 'Copied!' : 'Copy'}
    </button>
  );
}

// ─── DOWNLOAD HELPER ─────────────────────────────────────────────────────────

async function downloadFile(buildFn, filename, label, setLoading) {
  setLoading(true);
  try {
    const html = buildFn();
    const blob = new Blob([html], { type: 'text/html' });
    const file = new File([blob], filename, { type: 'text/html' });
    const { file_url } = await base44.integrations.Core.UploadFile({ file });
    const a = document.createElement('a');
    a.href = file_url;
    a.download = filename;
    document.body.appendChild(a);
    a.click();
    document.body.removeChild(a);
    toast.success(`${label} downloaded!`);
  } catch {
    toast.error('Download failed — please try again.');
  } finally {
    setLoading(false);
  }
}

// ─── MAIN PAGE ────────────────────────────────────────────────────────────────

export default function GumroadGuide() {
  const [dlGuide, setDlGuide] = useState(false);
  const [dlProduct, setDlProduct] = useState(false);

  const PRODUCT_DESCRIPTION = `🚐 Granny's Route — RV-Safe Offline Route Pack

Never get surprised by a low bridge again.

This offline route pack opens in any browser — no cell service, no app needed. Perfect for rural stretches with zero signal.

✅ What's included:
• Pre-planned RV-safe routes avoiding low bridges, weight limits & tight turns
• Hazard details with clearance heights
• Fuel stop suggestions  
• Printable format — works on any device

🔒 Works 100% offline — just open the HTML file in Chrome, Safari or Firefox
📱 Save to your phone for instant access on the road

Questions? Reply to your Gumroad receipt and we'll help you out.

Safe travels! 🌿 — The RVBridgeSafe Team`;

  return (
    <div className="max-w-3xl mx-auto px-4 sm:px-6 py-10 md:py-14">
      <motion.div initial={{ opacity: 0, y: 20 }} animate={{ opacity: 1, y: 0 }}>

        {/* Header */}
        <div className="mb-10">
          <Badge className="mb-4 bg-accent text-accent-foreground font-body">Seller Guide</Badge>
          <h1 className="font-heading text-3xl md:text-4xl font-bold text-foreground mb-3">
            Download & Setup
          </h1>
          <p className="text-muted-foreground font-body">
            Everything you need to list and sell the offline route pack on Gumroad, plus the files to upload.
          </p>
        </div>

        {/* Download Files */}
        <Card className="p-6 mb-10 border-primary/20 bg-primary/5">
          <h2 className="font-heading font-semibold text-foreground mb-1">Your Files</h2>
          <p className="text-sm text-muted-foreground font-body mb-5">Download these two files. One goes on Gumroad; the other is your reference guide.</p>
          <div className="flex flex-col sm:flex-row gap-3">
            <Button
              className="flex-1 rounded-xl font-body gap-2"
              onClick={() => downloadFile(buildProductFileHTML, 'GrannysRoute_Nashville_Memphis.html', 'Product file', setDlProduct)}
              disabled={dlProduct}
            >
              {dlProduct ? <span className="animate-spin">⏳</span> : <Download className="w-4 h-4" />}
              {dlProduct ? 'Preparing…' : 'Download Product File'}
            </Button>
            <Button
              variant="outline"
              className="flex-1 rounded-xl font-body gap-2"
              onClick={() => downloadFile(buildSellerInstructionsHTML, 'GumroadSellerGuide_RVBridgeSafe.html', 'Seller guide', setDlGuide)}
              disabled={dlGuide}
            >
              {dlGuide ? <span className="animate-spin">⏳</span> : <FileText className="w-4 h-4" />}
              {dlGuide ? 'Preparing…' : 'Download Seller Guide'}
            </Button>
          </div>
          <p className="text-xs text-muted-foreground font-body mt-3">
            Both files open in any browser — no special software needed.
          </p>
        </Card>

        {/* Steps */}
        <Card className="p-6 mb-8">
          <h2 className="font-heading font-semibold text-foreground mb-6">Setup Steps</h2>
          <div className="space-y-0">
            <Step num="1" title="Create a Gumroad Account">
              <p>Go to <a href="https://gumroad.com" target="_blank" rel="noopener noreferrer" className="text-primary underline">gumroad.com</a> and sign up (free).</p>
              <p>Connect your bank or PayPal under <strong>Settings → Payouts</strong>.</p>
              <p>Gumroad takes 10% per sale — no monthly fee on the free plan.</p>
            </Step>

            <Step num="2" title="Create a New Product">
              <p>Click <strong>+ New Product → Digital Product</strong>.</p>
              <p>Product name: <code className="bg-muted px-1.5 py-0.5 rounded text-xs">Granny's Route — RV-Safe Offline Route Pack</code>
                <CopyButton text="Granny's Route — RV-Safe Offline Route Pack" /></p>
              <p>Set your price (suggested: <strong>$9</strong>, or "pay what you want" min $5).</p>
              <p>Upload the <strong>Product File</strong> you downloaded above as the purchasable file.</p>
            </Step>

            <Step num="3" title="Add the Product Description">
              <p>Paste the text below into Gumroad's description field:</p>
              <div className="relative bg-muted rounded-xl p-3 mt-2 text-xs font-mono whitespace-pre-wrap leading-relaxed">
                {PRODUCT_DESCRIPTION}
                <CopyButton text={PRODUCT_DESCRIPTION} />
              </div>
            </Step>

            <Step num="4" title="Set a Clean Permalink">
              <p>Under <strong>Product → Permalink</strong>, set: <code className="bg-muted px-1.5 py-0.5 rounded text-xs">grannysroute</code></p>
              <p>Your link will be: <code className="bg-muted px-1.5 py-0.5 rounded text-xs">https://[you].gumroad.com/l/grannysroute</code></p>
              <p className="text-accent font-medium">Then update <code className="bg-muted px-1.5 py-0.5 rounded text-xs">GUMROAD_URL</code> in <code className="bg-muted px-1.5 py-0.5 rounded text-xs">components/home/GumroadSection.jsx</code> to your real URL.</p>
            </Step>

            <Step num="5" title="Add a Cover Photo">
              <p>Recommended size: <strong>1280 × 720px</strong>.</p>
              <p>Free RV photos: <a href="https://unsplash.com/s/photos/rv-road" target="_blank" rel="noopener noreferrer" className="text-primary underline">unsplash.com/s/photos/rv-road</a></p>
            </Step>

            <Step num="6" title="Publish & Test">
              <p>Hit <strong>Publish</strong>, then use Gumroad's "Buy as a test" button.</p>
              <p>Confirm the HTML file downloads and opens offline correctly.</p>
              <p className="flex items-center gap-1.5 text-primary font-medium mt-1">
                <CheckCircle2 className="w-3.5 h-3.5" /> You're live!
              </p>
            </Step>
          </div>
        </Card>

        {/* Links */}
        <div className="flex flex-wrap gap-3">
          <a href="https://gumroad.com" target="_blank" rel="noopener noreferrer">
            <Button variant="outline" className="rounded-xl font-body gap-2 text-sm">
              <ShoppingCart className="w-4 h-4" /> Open Gumroad
            </Button>
          </a>
          <a href={GUMROAD_URL} target="_blank" rel="noopener noreferrer">
            <Button variant="outline" className="rounded-xl font-body gap-2 text-sm">
              <ExternalLink className="w-4 h-4" /> View Live Product
            </Button>
          </a>
          <a href="https://grannysroute.org" target="_blank" rel="noopener noreferrer">
            <Button variant="outline" className="rounded-xl font-body gap-2 text-sm">
              <ArrowRight className="w-4 h-4" /> GrannysRoute.org
            </Button>
          </a>
        </div>

      </motion.div>
    </div>
  );
}