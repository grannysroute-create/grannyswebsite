import React, { useState } from 'react';
import { motion, AnimatePresence } from 'framer-motion';
import { Card } from "@/components/ui/card";
import { Badge } from "@/components/ui/badge";
import { Button } from "@/components/ui/button";
import { ExternalLink, Star, ShoppingCart, Fuel, Smartphone, Package, Percent, Heart, ChevronDown } from 'lucide-react';

const affiliateGroups = [
  {
    category: "Granny's Route Premium",
    icon: Star,
    color: 'bg-primary/10 text-primary',
    partners: [
      {
        name: "Granny's Route — Premium Features",
        logo: '🛡️',
        tagline: 'Unlock offline maps, real-time bridge alerts, unlimited saved routes, and priority DOT data updates. Coming soon — join the waitlist!',
        offer: 'Coming Soon — Free to join waitlist',
        badge: '⭐ Our Premium Plan',
        badgeColor: 'bg-primary/10 text-primary',
        url: '#',
        stars: 5,
        note: 'Built by RVers, for RVers. Granny\'s Route is the safest way to travel — with a little extra love baked in.',
        comingSoon: true,
      },
    ]
  },
  {
    category: 'Digital Downloads',
    icon: ShoppingCart,
    color: 'bg-accent/10 text-accent',
    partners: [
      {
        name: 'RVBridgeSafe on Gumroad',
        logo: '🛍️',
        tagline: 'Printable Low Clearance Safety Checklist, Pre-Trip Bridge Safety Audit, and the full RVBridgeSafe route guide — instant download.',
        offer: 'Digital download — instant access',
        badge: 'Our Own Product',
        badgeColor: 'bg-accent/10 text-accent',
        url: 'https://gumroad.com/l/rvbridgesafe',
        stars: 5,
        note: 'Checklists, guides, and our "First 30 Days Full-Timing Safety Pack." Made by us, for you.',
      },
    ]
  },
  {
    category: 'Fuel Savings',
    icon: Fuel,
    color: 'bg-accent/10 text-accent',
    partners: [
      {
        name: 'GasBuddy',
        logo: '⛽',
        tagline: 'Find the cheapest diesel near you. Filter by big-rig access, DEF availability, and canopy height.',
        offer: 'Free fuel card — save up to 25¢/gal',
        badge: 'Save Money',
        badgeColor: 'bg-accent/10 text-accent',
        url: 'https://www.gasbuddy.com/',
        stars: 4,
        note: 'Diesel is expensive, sugar. Every penny counts on a long haul.',
      },
      {
        name: 'Upside',
        logo: '💸',
        tagline: 'Get cash back on gas, groceries, and restaurants — just by scanning your receipt.',
        offer: 'Up to 25¢/gal cashback on your first fillup',
        badge: 'Cashback',
        badgeColor: 'bg-accent/10 text-accent',
        url: 'https://www.upside.com/',
        stars: 4,
        note: 'Stack Upside on top of GasBuddy. We call that a double dip, and it\'s perfectly legal.',
      },
    ]
  },
  {
    category: 'Mobile & Connectivity',
    icon: Smartphone,
    color: 'bg-primary/10 text-primary',
    partners: [
      {
        name: 'Visible by Verizon',
        logo: '📱',
        tagline: 'Unlimited data on the Verizon network — no contracts, no hidden fees. Perfect for full-timers.',
        offer: '$25/month — no contract',
        badge: 'Full-Timer Pick',
        badgeColor: 'bg-primary/10 text-primary',
        url: 'https://www.visible.com/',
        stars: 5,
        note: 'Full-timers need reliable data. Visible delivers Verizon coverage without the Verizon bill.',
      },
    ]
  },
  {
    category: 'RV Supplies & Gear',
    icon: Package,
    color: 'bg-secondary text-foreground',
    partners: [
      {
        name: 'Amazon',
        logo: '📦',
        tagline: 'RV essentials delivered to your campsite — surge protectors, leveling blocks, water filters, and more.',
        offer: 'Free Prime shipping on qualifying orders',
        badge: 'Gear Up',
        badgeColor: 'bg-secondary text-foreground',
        url: 'https://www.amazon.com/s?k=rv+essentials',
        stars: 4,
        note: 'Our curated RV essentials list — the stuff we actually use in our own rigs.',
      },
      {
        name: 'Walmart',
        logo: '🛒',
        tagline: 'Overnight parking + everything you need for the road. Cooking supplies, bedding, propane accessories.',
        offer: 'Price match + free pickup',
        badge: 'Overnight Friendly',
        badgeColor: 'bg-secondary text-foreground',
        url: 'https://www.walmart.com/cp/rv-accessories/1231459',
        stars: 4,
        note: 'Most Walmart stores allow overnight RV parking. Stock up and sleep for free, hon!',
      },
    ]
  },
];

function StarRating({ count }) {
  return (
    <div className="flex gap-0.5">
      {[...Array(5)].map((_, i) => (
        <Star key={i} className={`w-3.5 h-3.5 ${i < count ? 'text-accent fill-accent' : 'text-muted-foreground/30'}`} />
      ))}
    </div>
  );
}

function PartnerCard({ partner }) {
  const [expanded, setExpanded] = useState(false);

  return (
    <Card
      className="border-border hover:shadow-lg hover:border-primary/20 transition-all duration-300 overflow-hidden cursor-pointer"
      onClick={() => !partner.comingSoon && setExpanded(e => !e)}
    >
      {/* Always-visible summary row */}
      <div className="p-5 flex items-center gap-4">
        <span className="text-3xl shrink-0">{partner.logo}</span>
        <div className="flex-1 min-w-0">
          <div className="flex items-center justify-between gap-2 flex-wrap">
            <h3 className="font-heading font-semibold text-foreground truncate">{partner.name}</h3>
            <Badge className={`${partner.badgeColor} text-xs shrink-0 font-body`}>{partner.badge}</Badge>
          </div>
          <StarRating count={partner.stars} />
          <div className="flex items-center gap-1.5 text-xs text-primary font-body font-medium mt-1">
            <Percent className="w-3 h-3 shrink-0" />
            {partner.offer}
          </div>
        </div>
        {!partner.comingSoon && (
          <ChevronDown
            className={`w-4 h-4 text-muted-foreground shrink-0 transition-transform duration-200 ${expanded ? 'rotate-180' : ''}`}
          />
        )}
        {partner.comingSoon && (
          <span className="text-xs font-body text-muted-foreground opacity-60 shrink-0">Soon</span>
        )}
      </div>

      {/* Expandable description */}
      <AnimatePresence initial={false}>
        {expanded && (
          <motion.div
            key="desc"
            initial={{ height: 0, opacity: 0 }}
            animate={{ height: 'auto', opacity: 1 }}
            exit={{ height: 0, opacity: 0 }}
            transition={{ duration: 0.2, ease: 'easeInOut' }}
            className="overflow-hidden"
          >
            <div className="px-5 pb-5 pt-0 border-t border-border mt-0">
              <p className="text-sm font-body text-foreground leading-relaxed mt-4 mb-2">{partner.tagline}</p>
              <p className="text-xs text-muted-foreground font-body italic mb-4">"{partner.note}"</p>
              <a
                href={partner.url}
                target="_blank"
                rel="noopener noreferrer"
                onClick={e => e.stopPropagation()}
                className="inline-flex items-center gap-1.5 text-sm font-body text-primary font-medium hover:underline"
              >
                Visit {partner.name} <ExternalLink className="w-3.5 h-3.5" />
              </a>
            </div>
          </motion.div>
        )}
      </AnimatePresence>
    </Card>
  );
}

export default function Affiliates() {
  return (
    <div className="max-w-6xl mx-auto px-4 sm:px-6 lg:px-8 py-10 md:py-16">
      <motion.div initial={{ opacity: 0, y: 20 }} animate={{ opacity: 1, y: 0 }}>

        {/* Header */}
        <div className="text-center mb-14">
          <div className="inline-flex items-center gap-2 px-4 py-1.5 rounded-full bg-secondary border border-border mb-5">
            <Heart className="w-4 h-4 text-accent fill-accent" />
            <span className="text-sm font-body font-medium text-foreground">Trusted by Our Community</span>
          </div>
          <h1 className="font-heading text-4xl md:text-5xl font-bold text-foreground mb-4">
            Gear, Gas, & Grub
          </h1>
          <p className="text-muted-foreground font-body text-lg max-w-2xl mx-auto leading-relaxed">
            Everything our community actually uses on the road — hand-picked, road-tested, and worth every penny.
          </p>
          <p className="text-xs text-muted-foreground/60 font-body mt-3">
            ✦ Tap any card for details. We earn a small commission on qualifying purchases at no extra cost to you.
          </p>
        </div>

        {/* Groups */}
        <div className="space-y-14">
          {affiliateGroups.map((group, gi) => (
            <motion.div
              key={group.category}
              initial={{ opacity: 0, y: 20 }}
              whileInView={{ opacity: 1, y: 0 }}
              viewport={{ once: true }}
              transition={{ delay: gi * 0.05 }}
            >
              <div className="flex items-center gap-3 mb-5">
                <div className={`w-9 h-9 rounded-xl ${group.color} flex items-center justify-center`}>
                  <group.icon className="w-5 h-5" />
                </div>
                <h2 className="font-heading text-xl font-semibold text-foreground">{group.category}</h2>
              </div>

              <div className="grid grid-cols-1 md:grid-cols-2 gap-5">
                {group.partners.map((partner, pi) => (
                  <PartnerCard key={pi} partner={partner} />
                ))}
              </div>
            </motion.div>
          ))}
        </div>

        {/* Bottom CTA */}
        <motion.div
          initial={{ opacity: 0 }}
          whileInView={{ opacity: 1 }}
          viewport={{ once: true }}
          className="mt-16 p-8 rounded-3xl bg-primary/5 border border-primary/15 text-center"
        >
          <p className="font-heading text-lg font-semibold text-foreground mb-2">
            Have a product you'd like us to review?
          </p>
          <p className="text-sm text-muted-foreground font-body mb-4">
            We test everything ourselves before recommending it to our community. No paid placements without honest reviews.
          </p>
          <Button variant="outline" className="rounded-xl font-body gap-2">
            Contact Us
            <ExternalLink className="w-4 h-4" />
          </Button>
        </motion.div>

      </motion.div>
    </div>
  );
}