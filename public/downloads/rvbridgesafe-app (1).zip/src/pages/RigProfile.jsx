import React, { useState, useEffect } from 'react';
import { base44 } from '@/api/base44Client';
import { useQuery, useMutation, useQueryClient } from '@tanstack/react-query';
import { Card } from "@/components/ui/card";
import { Button } from "@/components/ui/button";
import { Input } from "@/components/ui/input";
import { Label } from "@/components/ui/label";
import { Switch } from "@/components/ui/switch";
import { Select, SelectContent, SelectItem, SelectTrigger, SelectValue } from "@/components/ui/select";
import { toast } from "sonner";
import { Truck, Save, Shield, Loader2 } from 'lucide-react';
import { motion } from 'framer-motion';

const rigTypes = [
  { value: 'motorhome_class_a', label: 'Class A Motorhome' },
  { value: 'motorhome_class_b', label: 'Class B Motorhome' },
  { value: 'motorhome_class_c', label: 'Class C Motorhome' },
  { value: 'fifth_wheel', label: 'Fifth Wheel' },
  { value: 'travel_trailer', label: 'Travel Trailer' },
  { value: 'truck_camper', label: 'Truck Camper' },
  { value: 'toy_hauler', label: 'Toy Hauler' },
];

const defaultRig = {
  rig_name: '',
  rig_type: 'motorhome_class_a',
  height_feet: '',
  height_inches: '',
  length_feet: '',
  width_feet: '',
  weight_lbs: '',
  has_propane: false,
  is_active: true,
};

export default function RigProfile() {
  const queryClient = useQueryClient();
  const [form, setForm] = useState(defaultRig);
  const [editingId, setEditingId] = useState(null);

  const { data: rigs, isLoading } = useQuery({
    queryKey: ['rigs'],
    queryFn: () => base44.entities.RigProfile.list(),
    initialData: [],
  });

  useEffect(() => {
    const active = rigs.find(r => r.is_active) || rigs[0];
    if (active) {
      setForm({
        rig_name: active.rig_name || '',
        rig_type: active.rig_type || 'motorhome_class_a',
        height_feet: active.height_feet || '',
        height_inches: active.height_inches || '',
        length_feet: active.length_feet || '',
        width_feet: active.width_feet || '',
        weight_lbs: active.weight_lbs || '',
        has_propane: active.has_propane || false,
        is_active: true,
      });
      setEditingId(active.id);
    }
  }, [rigs]);

  const saveMutation = useMutation({
    mutationFn: async (data) => {
      const payload = {
        ...data,
        height_feet: Number(data.height_feet) || 0,
        height_inches: Number(data.height_inches) || 0,
        length_feet: Number(data.length_feet) || 0,
        width_feet: Number(data.width_feet) || 0,
        weight_lbs: Number(data.weight_lbs) || 0,
      };
      if (editingId) {
        return base44.entities.RigProfile.update(editingId, payload);
      }
      return base44.entities.RigProfile.create(payload);
    },
    onSuccess: () => {
      queryClient.invalidateQueries({ queryKey: ['rigs'] });
      toast.success("Rig profile saved! You're all set. 🚐");
    },
  });

  const handleSubmit = (e) => {
    e.preventDefault();
    saveMutation.mutate(form);
  };

  const updateField = (field, value) => {
    setForm(prev => ({ ...prev, [field]: value }));
  };

  return (
    <div className="max-w-3xl mx-auto px-4 sm:px-6 lg:px-8 py-6 md:py-9">
      <motion.div initial={{ opacity: 0, y: 20 }} animate={{ opacity: 1, y: 0 }}>
        <div className="text-center mb-8">
          <div className="w-16 h-16 rounded-2xl bg-primary/10 flex items-center justify-center mx-auto mb-4">
            <Truck className="w-8 h-8 text-primary" />
          </div>
          <h1 className="font-heading text-3xl font-bold text-foreground mb-2">My Rig Profile</h1>
          <p className="text-muted-foreground font-body">
            Tell us about your rig. We'll make sure every route is safe for your exact dimensions.
          </p>
        </div>

        <Card className="p-5 md:p-6">
          <form onSubmit={handleSubmit} className="space-y-5">
            <div className="grid grid-cols-1 sm:grid-cols-2 gap-3">
              <div className="sm:col-span-2">
                <Label className="font-body text-sm">Rig Nickname</Label>
                <Input
                  placeholder="e.g., Big Bertha, The Wanderer"
                  value={form.rig_name}
                  onChange={(e) => updateField('rig_name', e.target.value)}
                  className="mt-1.5 rounded-xl font-body"
                />
              </div>
              <div className="sm:col-span-2">
                <Label className="font-body text-sm">Rig Type</Label>
                <Select value={form.rig_type} onValueChange={(v) => updateField('rig_type', v)}>
                  <SelectTrigger className="mt-1.5 rounded-xl font-body">
                    <SelectValue />
                  </SelectTrigger>
                  <SelectContent>
                    {rigTypes.map(t => (
                      <SelectItem key={t.value} value={t.value} className="font-body">{t.label}</SelectItem>
                    ))}
                  </SelectContent>
                </Select>
              </div>
            </div>

            <div className="border-t border-border pt-5">
              <h3 className="font-heading text-lg font-semibold mb-3 flex items-center gap-2">
                <Shield className="w-5 h-5 text-primary" />
                Dimensions — This is the important stuff!
              </h3>
              <div className="grid grid-cols-2 sm:grid-cols-4 gap-3">
                <div>
                  <Label className="font-body text-sm">Height (ft)</Label>
                  <Input
                    type="number"
                    placeholder="13"
                    value={form.height_feet}
                    onChange={(e) => updateField('height_feet', e.target.value)}
                    className="mt-1.5 rounded-xl font-body"
                  />
                </div>
                <div>
                  <Label className="font-body text-sm">Height (in)</Label>
                  <Input
                    type="number"
                    placeholder="6"
                    min="0"
                    max="11"
                    value={form.height_inches}
                    onChange={(e) => updateField('height_inches', e.target.value)}
                    className="mt-1.5 rounded-xl font-body"
                  />
                </div>
                <div>
                  <Label className="font-body text-sm">Length (ft)</Label>
                  <Input
                    type="number"
                    placeholder="40"
                    value={form.length_feet}
                    onChange={(e) => updateField('length_feet', e.target.value)}
                    className="mt-1.5 rounded-xl font-body"
                  />
                </div>
                <div>
                  <Label className="font-body text-sm">Width (ft)</Label>
                  <Input
                    type="number"
                    placeholder="8.5"
                    value={form.width_feet}
                    onChange={(e) => updateField('width_feet', e.target.value)}
                    className="mt-1.5 rounded-xl font-body"
                  />
                </div>
              </div>
            </div>

            <div className="grid grid-cols-1 sm:grid-cols-2 gap-3">
               <div>
                 <Label className="font-body text-sm">Weight (lbs)</Label>
                <Input
                  type="number"
                  placeholder="26,000"
                  value={form.weight_lbs}
                  onChange={(e) => updateField('weight_lbs', e.target.value)}
                  className="mt-1.5 rounded-xl font-body"
                />
              </div>
              <div className="flex items-center justify-between p-4 rounded-xl bg-secondary/50">
                <div>
                  <Label className="font-body text-sm font-semibold">Carrying Propane?</Label>
                  <p className="text-xs text-muted-foreground font-body">Some tunnels restrict propane</p>
                </div>
                <Switch
                  checked={form.has_propane}
                  onCheckedChange={(v) => updateField('has_propane', v)}
                />
              </div>
            </div>

            <Button
              type="submit"
              size="lg"
              className="w-full rounded-xl font-body text-base gap-2"
              disabled={saveMutation.isPending}
            >
              {saveMutation.isPending ? (
                <Loader2 className="w-4 h-4 animate-spin" />
              ) : (
                <Save className="w-4 h-4" />
              )}
              {editingId ? 'Update My Rig' : 'Save My Rig'}
            </Button>
          </form>
        </Card>
      </motion.div>
    </div>
  );
}