import React, { useState } from 'react';
import { base44 } from '@/api/base44Client';
import { useQuery, useMutation, useQueryClient } from '@tanstack/react-query';
import { toast } from "sonner";
import { Users } from 'lucide-react';
import { Tabs, TabsList, TabsTrigger } from "@/components/ui/tabs";
import { motion } from 'framer-motion';
import ReportForm from '../components/community/ReportForm';
import ReportsList from '../components/community/ReportsList';

export default function Community() {
  const queryClient = useQueryClient();
  const [filter, setFilter] = useState('all');

  const { data: reports } = useQuery({
    queryKey: ['reports'],
    queryFn: () => base44.entities.BridgeReport.list('-created_date', 50),
    initialData: [],
  });

  const createMutation = useMutation({
    mutationFn: (data) => base44.entities.BridgeReport.create(data),
    onSuccess: () => {
      queryClient.invalidateQueries({ queryKey: ['reports'] });
      toast.success("Thank you, sugar! Your report helps keep everyone safe. 🙏");
    },
  });

  const upvoteMutation = useMutation({
    mutationFn: (report) =>
      base44.entities.BridgeReport.update(report.id, { upvotes: (report.upvotes || 0) + 1 }),
    onSuccess: () => {
      queryClient.invalidateQueries({ queryKey: ['reports'] });
    },
  });

  const filteredReports = filter === 'all'
    ? reports
    : reports.filter(r => r.report_type === filter);

  return (
    <div className="max-w-7xl mx-auto px-4 sm:px-6 lg:px-8 py-6 md:py-9">
      <motion.div initial={{ opacity: 0, y: 20 }} animate={{ opacity: 1, y: 0 }}>
        <div className="text-center mb-8">
          <div className="w-16 h-16 rounded-2xl bg-accent/10 flex items-center justify-center mx-auto mb-4">
            <Users className="w-8 h-8 text-accent" />
          </div>
          <h1 className="font-heading text-3xl font-bold text-foreground mb-2">Community Reports</h1>
          <p className="text-muted-foreground font-body max-w-xl mx-auto">
            We're all in this together, folks. Report hazards, share close calls, and help keep fellow RVers safe on the road.
          </p>
        </div>

        <div className="grid grid-cols-1 lg:grid-cols-3 gap-6">
          <div className="lg:col-span-1">
            <ReportForm onSubmit={(data) => createMutation.mutate(data)} isSubmitting={createMutation.isPending} />
          </div>
          <div className="lg:col-span-2">
            <div className="mb-4">
              <Tabs defaultValue="all" onValueChange={setFilter}>
                <TabsList className="font-body">
                  <TabsTrigger value="all">All</TabsTrigger>
                  <TabsTrigger value="low_clearance">Low Clearance</TabsTrigger>
                  <TabsTrigger value="bridge_strike">Strikes</TabsTrigger>
                  <TabsTrigger value="close_call">Close Calls</TabsTrigger>
                </TabsList>
              </Tabs>
            </div>
            <ReportsList reports={filteredReports} onUpvote={(r) => upvoteMutation.mutate(r)} />
          </div>
        </div>
      </motion.div>
    </div>
  );
}