import React, { useState } from 'react';
import { base44 } from '@/api/base44Client';
import { useQuery, useMutation, useQueryClient } from '@tanstack/react-query';
import { toast } from "sonner";
import { Route as RouteIcon } from 'lucide-react';
import { motion } from 'framer-motion';
import RouteForm from '../components/route/RouteForm';
import RouteResult from '../components/route/RouteResult';
import RouteMap from '../components/route/RouteMap';
import ElevationChart from '../components/route/ElevationChart';

export default function RoutePlanner() {
  const queryClient = useQueryClient();
  const urlParams = new URLSearchParams(window.location.search);
  const [form, setForm] = useState({
    origin: urlParams.get('origin') || '',
    destination: urlParams.get('destination') || '',
    includeFuelStops: true,
    offlineMode: false,
  });
  const [result, setResult] = useState(null);
  const [isPlanning, setIsPlanning] = useState(false);
  const [routeLine, setRouteLine] = useState([]);

  const { data: rigs } = useQuery({
    queryKey: ['rigs'],
    queryFn: () => base44.entities.RigProfile.list(),
    initialData: [],
  });

  const { data: savedRoutes } = useQuery({
    queryKey: ['routes'],
    queryFn: () => base44.entities.SavedRoute.list(),
    initialData: [],
  });

  const activeRig = rigs.find(r => r.is_active) || rigs[0];
  const atRouteLimit = savedRoutes.length >= 2;

  const planRoute = async (e) => {
    e.preventDefault();
    setIsPlanning(true);

    const rigInfo = activeRig
      ? `Height: ${activeRig.height_feet}'${activeRig.height_inches || 0}", Length: ${activeRig.length_feet || 'unknown'}ft, Weight: ${activeRig.weight_lbs || 'unknown'}lbs, Propane: ${activeRig.has_propane ? 'yes' : 'no'}`
      : 'No rig profile set — assume large Class A motorhome, 13\'6" tall, 40ft long';

    const response = await base44.integrations.Core.InvokeLLM({
      prompt: `You are an RV route planning assistant. Plan a safe RV route from "${form.origin}" to "${form.destination}".
      
RV Specs: ${rigInfo}

Include fuel stops: ${form.includeFuelStops ? 'yes' : 'no'}

Generate a realistic route result with:
1. Estimated distance in miles
2. Estimated drive time in hours (RV speed, not car speed)
3. Number of recommended fuel stops
4. A list of 3-5 specific hazards (low bridges, steep grades, tunnels) that would be avoided, with realistic clearance heights and locations along or near this route.

Be specific with bridge/tunnel names and clearance heights.`,
      response_json_schema: {
        type: "object",
        properties: {
          distance: { type: "string", description: "e.g. '847'" },
          time: { type: "string", description: "e.g. '14.5'" },
          fuelStops: { type: "number" },
          hazards: {
            type: "array",
            items: {
              type: "object",
              properties: {
                name: { type: "string" },
                type: { type: "string", enum: ["bridge", "grade", "tunnel"] },
                detail: { type: "string" },
                clearance: { type: "string" },
                info: { type: "string" }
              }
            }
          },
          summary: { type: "string" }
        }
      }
    });

    setResult(response);
    setIsPlanning(false);
  };

  const saveMutation = useMutation({
    mutationFn: () => base44.entities.SavedRoute.create({
      name: `${form.origin} → ${form.destination}`,
      origin: form.origin,
      destination: form.destination,
      distance_miles: parseFloat(result.distance) || 0,
      estimated_hours: parseFloat(result.time) || 0,
      hazards_avoided: result.hazards?.length || 0,
      fuel_stops: result.fuelStops || 0,
    }),
    onSuccess: () => {
      queryClient.invalidateQueries({ queryKey: ['routes'] });
      toast.success("Route saved! You can find it in your dashboard, dear. 🗺️");
    },
    onError: () => {
      toast.error("Couldn't save the route. Please try again.");
    },
  });

  return (
    <div className="max-w-7xl mx-auto px-4 sm:px-6 lg:px-8 py-6 md:py-9">
      <motion.div initial={{ opacity: 0, y: 20 }} animate={{ opacity: 1, y: 0 }}>
        <div className="text-center mb-8">
          <div className="w-16 h-16 rounded-2xl bg-primary/10 flex items-center justify-center mx-auto mb-4">
            <RouteIcon className="w-8 h-8 text-primary" />
          </div>
          <h1 className="font-heading text-3xl font-bold text-foreground mb-2">Plan Your Route</h1>
          <p className="text-muted-foreground font-body max-w-xl mx-auto">
            {activeRig
              ? `Routing for ${activeRig.rig_name} — ${activeRig.height_feet}'${activeRig.height_inches || 0}" tall. We'll keep you safe, promise.`
              : "Set up your rig profile first for the safest routes, hon!"}
          </p>
        </div>

        <div className="grid grid-cols-1 lg:grid-cols-2 gap-6 max-w-5xl mx-auto">
          <RouteForm form={form} setForm={setForm} onSubmit={planRoute} isLoading={isPlanning} />
          <RouteResult result={result} origin={form.origin} destination={form.destination} onSave={() => {
            if (atRouteLimit) {
              toast.error("You've reached the 2 saved trip limit. Delete one to save a new route.");
              return;
            }
            saveMutation.mutate();
          }} isSaving={saveMutation.isPending} saveDisabled={atRouteLimit} />
        </div>

        {(result || (form.origin && form.destination)) && (
          <div className="max-w-5xl mx-auto mt-5 space-y-3">
            <RouteMap
              origin={result ? form.origin : ''}
              destination={result ? form.destination : ''}
              onRouteLine={setRouteLine}
            />
            <ElevationChart routeLine={routeLine} />
          </div>
        )}
      </motion.div>
    </div>
  );
}