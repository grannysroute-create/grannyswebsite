import { createClientFromRequest } from 'npm:@base44/sdk@0.8.25';
import { jsPDF } from 'npm:jspdf@4.2.1';

const CATEGORIES = [
  {
    label: 'General Checks',
    items: [
      'Check Fluid Levels',
      'Inspect Tires',
      'Test Lights',
      'Inspect Battery',
      'Emergency Kit',
    ],
  },
  {
    label: 'Motorhome Specific Checks',
    items: [
      'Engine Check',
      'Generator Functionality',
      'Awning Operation',
    ],
  },
  {
    label: 'Towing Specific Checks',
    items: [
      'Hitch Inspection',
      'Load Balancing',
      'Safety Chains & Breakaway Switches',
    ],
  },
  {
    label: 'Interior Checks',
    items: [
      'Propane System Test',
      'Appliances & HVAC Functionality',
      'Fresh Water System',
    ],
  },
  {
    label: 'Exterior Checks',
    items: [
      'Seals & Caulking Inspection',
      'Clean Windows & Mirrors',
    ],
  },
  {
    label: 'Trip Prep',
    items: [
      'Roadside Assistance Plan',
      'Manuals Ready',
      'Confirm Reservations',
      'Trip Navigation Prep',
    ],
  },
];

Deno.serve(async (req) => {
  const doc = new jsPDF({ unit: 'pt', format: 'letter' });
  const W = doc.internal.pageSize.getWidth();
  const H = doc.internal.pageSize.getHeight();
  const L = 56;   // left margin
  const R = W - 56; // right boundary

  // ── Background ──────────────────────────────────────────────────────────────
  doc.setFillColor(244, 247, 242); // pale sage
  doc.rect(0, 0, W, H, 'F');

  // ── Header band ─────────────────────────────────────────────────────────────
  doc.setFillColor(107, 143, 94); // primary green
  doc.rect(0, 0, W, 80, 'F');

  doc.setTextColor(255, 255, 255);
  doc.setFontSize(22);
  doc.setFont('helvetica', 'bold');
  doc.text('RV PRE-TRIP CHECK', L, 38);

  doc.setFontSize(10);
  doc.setFont('helvetica', 'normal');
  doc.text('Grannysroute.org · Road-tested, granny-vetted', L, 58);

  // Right-side date placeholder
  doc.setFontSize(9);
  doc.text('Date: _______________', R - 110, 48);

  // ── Tagline ─────────────────────────────────────────────────────────────────
  doc.setTextColor(44, 62, 45);
  doc.setFontSize(10);
  doc.setFont('helvetica', 'italic');
  doc.text(
    'Check each item before you roll out. Safe travels, friend!',
    L, 106
  );

  // ── Categories ──────────────────────────────────────────────────────────────
  let y = 128;
  const boxSize = 11;
  const colMid = W / 2;   // two-column layout
  let col = 0; // 0 = left, 1 = right

  let globalNum = 0;

  for (const cat of CATEGORIES) {
    const colX = col === 0 ? L : colMid + 12;
    const colRX = col === 0 ? colMid - 20 : R;

    // Category label
    doc.setFontSize(7.5);
    doc.setFont('helvetica', 'bold');
    doc.setTextColor(139, 105, 20); // chamomile gold
    doc.text(cat.label.toUpperCase(), colX, y);
    y += 4;

    // Underline
    doc.setDrawColor(200, 213, 194);
    doc.setLineWidth(0.5);
    doc.line(colX, y + 1, colRX, y + 1);
    y += 12;

    for (const item of cat.items) {
      globalNum++;

      // Checkbox square
      doc.setDrawColor(107, 143, 94);
      doc.setLineWidth(0.8);
      doc.rect(colX, y - boxSize + 2, boxSize, boxSize);

      // Item number
      doc.setFontSize(7);
      doc.setFont('helvetica', 'normal');
      doc.setTextColor(120, 140, 120);
      doc.text(String(globalNum).padStart(2, '0'), colX + boxSize + 4, y - 2);

      // Item label
      doc.setFontSize(9.5);
      doc.setFont('helvetica', 'normal');
      doc.setTextColor(44, 62, 45);
      doc.text(item, colX + boxSize + 18, y - 1);

      y += 22;

      // Page break check (single column flow per category)
      if (y > H - 80) {
        doc.addPage();
        doc.setFillColor(244, 247, 242);
        doc.rect(0, 0, W, H, 'F');
        y = 60;
      }
    }

    y += 14; // gap after category

    // Switch column after every 2 categories
    // (simple: alternate cols based on category index)
    // For simplicity keep single column — cleaner for print
  }

  // ── Footer ──────────────────────────────────────────────────────────────────
  const pages = doc.getNumberOfPages();
  for (let p = 1; p <= pages; p++) {
    doc.setPage(p);
    doc.setFillColor(107, 143, 94);
    doc.rect(0, H - 36, W, 36, 'F');
    doc.setTextColor(255, 255, 255);
    doc.setFontSize(8);
    doc.setFont('helvetica', 'italic');
    doc.text('Grannysroute.org · Every provision on this site is road-tested and granny-vetted.', L, H - 14);
    doc.setFont('helvetica', 'normal');
    doc.text(`Page ${p} of ${pages}`, R - 40, H - 14);
  }

  const pdfBytes = doc.output('arraybuffer');

  return new Response(pdfBytes, {
    status: 200,
    headers: {
      'Content-Type': 'application/pdf',
      'Content-Disposition': 'attachment; filename=RV-Pre-trip-Checklist-Grannysroute.pdf',
    },
  });
});