# Grannysroute Design System — Reusable Theme Reference
Copy `index.css` tokens and `tailwind.config.js` settings below into any Base44 project.

---

## Palette: Herbal Tea

| Token | HSL | Description |
|---|---|---|
| `--background` | 110 18% 96% | #F4F7F2 pale sage mist |
| `--foreground` | 123 16% 21% | #2C3E2D deep forest green |
| `--card` | 110 16% 93% | #EEF2EB soft leaf tint |
| `--primary` | 105 21% 46% | #6B8F5E herbal sage green |
| `--secondary` | 39 82% 31% | #8B6914 chamomile gold |
| `--muted` | 110 14% 88% | #D8E2D4 misty leaf |
| `--border` | 110 18% 80% | #C8D5C2 misty green |

## Fonts

| Token | Value | Usage |
|---|---|---|
| `--font-lora` | 'Lora', serif | Headings, italic accents, granny voice |
| `--font-inter` | 'Inter', sans-serif | UI labels, body text, micro-copy |

Google Fonts import:
```css
@import url('https://fonts.googleapis.com/css2?family=Lora:ital,wght@0,400;0,500;0,600;0,700;1,400;1,500;1,600&family=Inter:wght@300;400;500;600&display=swap');
```

## index.css — Full :root block
```css
:root {
  --font-lora: 'Lora', serif;
  --font-inter: 'Inter', sans-serif;

  --background: 110 18% 96%;
  --foreground: 123 16% 21%;
  --card: 110 16% 93%;
  --card-foreground: 123 16% 21%;
  --popover: 110 18% 96%;
  --popover-foreground: 123 16% 21%;
  --primary: 105 21% 46%;
  --primary-foreground: 110 18% 97%;
  --secondary: 39 82% 31%;
  --secondary-foreground: 110 18% 97%;
  --muted: 110 14% 88%;
  --muted-foreground: 120 8% 42%;
  --accent: 39 82% 31%;
  --accent-foreground: 110 18% 97%;
  --destructive: 0 72% 51%;
  --destructive-foreground: 0 0% 98%;
  --border: 110 18% 80%;
  --input: 110 18% 80%;
  --ring: 105 21% 46%;
  --radius: 0.375rem;
}
```

## tailwind.config.js — fontFamily extension
```js
fontFamily: {
  lora: ['var(--font-lora)'],
  inter: ['var(--font-inter)'],
},
```

## Custom CSS Utilities (copy from index.css)
- `.paper-grain` — subtle noise texture overlay (fixed, z-50, pointer-events-none)
- `.stitch-line` — dashed horizontal divider using `border-border`
- `.provision-tilt` — card hover: rotate(-1deg) + lift
- `.granny-note` — hidden text revealed on `.provision-tilt:hover`
- `.deckle-edge` — wavy bottom mask effect

---

## Usage Notes
- Use `font-lora` for all headings and italic "voice" text.
- Use `font-inter` for all UI chrome: labels, buttons, badges, navigation.
- `text-secondary` (chamomile gold) works well for eyebrow labels / uppercase trackers.
- `bg-card` is slightly darker than `bg-background` — use for elevated surfaces.
- Button pattern: `bg-primary text-primary-foreground rounded-sm shadow-lg shadow-primary/20 hover:bg-primary/90`
- Secondary CTA: `bg-secondary text-secondary-foreground` same pattern