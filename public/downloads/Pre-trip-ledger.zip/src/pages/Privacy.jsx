import React from 'react';
import { motion } from 'framer-motion';
import { Link } from 'react-router-dom';
import { ArrowLeft } from 'lucide-react';
import Header from '../components/ledger/Header';

const SECTIONS = [
  {
    title: 'Affiliate Links',
    body: `Grannysroute.org participates in affiliate marketing programs. This means we may earn a small commission when you click a link on this site and make a purchase — at absolutely no extra cost to you. We only recommend products and services we genuinely use and believe in. Our editorial opinions are our own and are never influenced by affiliate relationships.`,
  },
  {
    title: 'Information We Collect',
    body: `When you submit a Community Note, we collect the display name you choose and the text of your note. We do not collect your email address, physical address, or payment information through this site. If you connect a user account, basic account details (name, email) are stored securely by our platform provider.`,
  },
  {
    title: 'How We Use Your Information',
    body: `Community Notes are displayed publicly on this site to help fellow travelers. We do not sell, rent, or share your personal information with third parties for marketing purposes.`,
  },
  {
    title: 'Cookies & Analytics',
    body: `We may use cookies or similar technologies to remember your preferences (such as whether you've dismissed the disclosure banner). We may also use anonymized analytics to understand how visitors use the site. No personally identifiable information is stored in these cookies.`,
  },
  {
    title: 'Third-Party Links',
    body: `This site contains links to external websites (Amazon, Walmart, GasBuddy, etc.). We are not responsible for the privacy practices or content of those sites. We encourage you to review their privacy policies before making a purchase.`,
  },
  {
    title: 'Children\'s Privacy',
    body: `This site is not directed at children under the age of 13. We do not knowingly collect personal information from children.`,
  },
  {
    title: 'Changes to This Policy',
    body: `We may update this Privacy Policy from time to time. Any changes will be posted on this page with an updated effective date. Your continued use of the site after changes are posted constitutes your acceptance of the revised policy.`,
  },
  {
    title: 'Contact',
    body: `If you have any questions about this Privacy Policy or how your information is used, you can reach us through the contact information on the About page.`,
  },
];

export default function Privacy() {
  return (
    <div className="paper-grain min-h-screen">
      <Header />

      <main className="pt-28 pb-20 px-6 md:px-12">
        <div className="max-w-2xl mx-auto">

          {/* Back link */}
          <motion.div
            initial={{ opacity: 0, x: -12 }}
            animate={{ opacity: 1, x: 0 }}
            transition={{ duration: 0.4 }}
          >
            <Link
              to="/"
              className="inline-flex items-center gap-2 font-inter text-xs tracking-wider uppercase text-muted-foreground hover:text-primary transition-colors mb-10"
            >
              <ArrowLeft className="w-3.5 h-3.5" />
              Back to the Pantry
            </Link>
          </motion.div>

          <motion.div
            initial={{ opacity: 0, y: 20 }}
            animate={{ opacity: 1, y: 0 }}
            transition={{ duration: 0.6 }}
          >
            <p className="font-inter text-[10px] tracking-[0.3em] uppercase text-secondary mb-4">
              Grannysroute.org · Legal
            </p>
            <h1 className="font-lora text-3xl md:text-4xl font-bold text-foreground mb-2">
              Privacy Policy &<br />
              <span className="italic font-normal text-primary">Affiliate Disclosure</span>
            </h1>
            <p className="font-inter text-xs text-muted-foreground mb-10">
              Effective date: May 2026
            </p>

            <div className="stitch-line" />
          </motion.div>

          <div className="space-y-10 mt-10">
            {SECTIONS.map((section, i) => (
              <motion.div
                key={section.title}
                initial={{ opacity: 0, y: 16 }}
                animate={{ opacity: 1, y: 0 }}
                transition={{ duration: 0.5, delay: 0.1 + i * 0.05 }}
              >
                <h2 className="font-lora text-lg font-semibold text-foreground mb-3">
                  {section.title}
                </h2>
                <p className="font-inter text-sm text-foreground/70 leading-relaxed">
                  {section.body}
                </p>
              </motion.div>
            ))}
          </div>

          <motion.div
            initial={{ opacity: 0 }}
            animate={{ opacity: 1 }}
            transition={{ duration: 0.6, delay: 0.6 }}
            className="mt-14 text-center"
          >
            <Link
              to="/"
              className="inline-flex items-center gap-2 px-6 py-3 bg-primary text-primary-foreground font-inter text-sm tracking-wider uppercase rounded-sm hover:bg-primary/90 transition-colors shadow-lg shadow-primary/20"
            >
              Back to the Pantry
            </Link>
          </motion.div>

        </div>
      </main>
    </div>
  );
}