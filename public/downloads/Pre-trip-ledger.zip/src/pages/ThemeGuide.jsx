import React, { useState } from 'react';
import { Printer, Copy, Check, Download } from 'lucide-react';

const AI_PROMPT = `Update my index.css — replace the entire :root block with this, and add the Google Fonts import at the very top if it's not already there:

@import url('https://fonts.googleapis.com/css2?family=Lora:ital,wght@0,400;0,500;0,600;0,700;1,400;1,500;1,600&family=Inter:wght@300;400;500;600&display=swap');

Then replace :root with:

:root {
  --font-lora: 'Lora', serif;
  --font-inter: 'Inter', sans-serif;
  --background: 110 18% 96%;
  --foreground: 123 16% 21%;
  --card: 110 16% 93%;
  --card-foreground: 123 16% 21%;
  --popover: 110 18% 96%;
  --popover-foreground: 123 16% 21%;
  --primary: 105 21% 46%;
  --primary-foreground: 110 18% 97%;
  --secondary: 39 82% 31%;
  --secondary-foreground: 110 18% 97%;
  --muted: 110 14% 88%;
  --muted-foreground: 120 8% 42%;
  --accent: 39 82% 31%;
  --accent-foreground: 110 18% 97%;
  --destructive: 0 72% 51%;
  --destructive-foreground: 0 0% 98%;
  --border: 110 18% 80%;
  --input: 110 18% 80%;
  --ring: 105 21% 46%;
  --radius: 0.375rem;
}

Then in tailwind.config.js inside theme.extend add:

fontFamily: {
  lora: ['var(--font-lora)'],
  inter: ['var(--font-inter)'],
},

Also update the body rule in index.css to:

body {
  @apply bg-background text-foreground font-inter;
  font-size: 1.125rem;
  line-height: 1.6;
}`;

const JSX_CONTENT = `// ============================================================
// Grannysroute.org — Herbal Tea Theme Reference Component
// Copy this file into any Base44 project as pages/ThemeGuide.jsx
// ============================================================

import React, { useState } from 'react';

const SWATCHES = [
  { label: 'Background', hsl: 'hsl(110,18%,96%)', hex: '#F4F7F2', token: '--background' },
  { label: 'Foreground', hsl: 'hsl(123,16%,21%)', hex: '#2C3E2D', token: '--foreground' },
  { label: 'Primary', hsl: 'hsl(105,21%,46%)', hex: '#6B8F5E', token: '--primary' },
  { label: 'Secondary', hsl: 'hsl(39,82%,31%)', hex: '#8B6914', token: '--secondary' },
  { label: 'Muted', hsl: 'hsl(110,14%,88%)', hex: '#D8E2D4', token: '--muted' },
  { label: 'Border', hsl: 'hsl(110,18%,80%)', hex: '#C8D5C2', token: '--border' },
  { label: 'Card', hsl: 'hsl(110,16%,93%)', hex: '#EEF2EB', token: '--card' },
];

export default function ThemeGuide() {
  return (
    <div style={{ fontFamily: 'sans-serif', maxWidth: 700, margin: '0 auto', padding: 32 }}>
      <h1>Herbal Tea Theme — Grannysroute.org</h1>
      <p>Paste the AI_PROMPT below into any Base44 app chat to apply this theme.</p>
      <h2>Color Palette</h2>
      <div style={{ display: 'flex', flexWrap: 'wrap', gap: 12 }}>
        {SWATCHES.map(s => (
          <div key={s.label} style={{ width: 100 }}>
            <div style={{ background: s.hsl, height: 48, borderRadius: 6, border: '1px solid #ccc' }} />
            <p style={{ margin: '4px 0 0', fontSize: 12, fontWeight: 600 }}>{s.label}</p>
            <p style={{ margin: 0, fontSize: 10, color: '#888', fontFamily: 'monospace' }}>{s.hex}</p>
            <p style={{ margin: 0, fontSize: 10, color: '#aaa', fontFamily: 'monospace' }}>{s.token}</p>
          </div>
        ))}
      </div>
    </div>
  );
}`;

const HTML_CONTENT = `<!DOCTYPE html>
<html lang="en">
<head>
  <meta charset="UTF-8" />
  <meta name="viewport" content="width=device-width, initial-scale=1.0" />
  <title>Herbal Tea Theme — Grannysroute.org</title>
  <link href="https://fonts.googleapis.com/css2?family=Lora:ital,wght@0,400;0,600;1,400&family=Inter:wght@300;400;500;600&display=swap" rel="stylesheet" />
  <style>
    :root {
      --background: hsl(110,18%,96%);
      --foreground: hsl(123,16%,21%);
      --card: hsl(110,16%,93%);
      --primary: hsl(105,21%,46%);
      --secondary: hsl(39,82%,31%);
      --muted: hsl(110,14%,88%);
      --border: hsl(110,18%,80%);
    }
    * { box-sizing: border-box; margin: 0; padding: 0; }
    body { background: var(--background); color: var(--foreground); font-family: 'Inter', sans-serif; font-size: 1.1rem; line-height: 1.6; padding: 2rem; }
    .wrap { max-width: 760px; margin: 0 auto; }
    h1 { font-family: 'Lora', serif; font-size: 2.2rem; margin-bottom: .25rem; }
    h2 { font-family: 'Inter', sans-serif; font-size: .65rem; letter-spacing: .25em; text-transform: uppercase; color: var(--secondary); margin: 2rem 0 1rem; }
    hr { border: none; border-top: 1px dashed var(--border); margin: 2rem 0; }
    .swatches { display: grid; grid-template-columns: repeat(auto-fill, minmax(90px, 1fr)); gap: 12px; }
    .swatch-box { height: 48px; border-radius: 6px; border: 1px solid var(--border); margin-bottom: 6px; }
    .swatch-label { font-size: .75rem; font-weight: 600; }
    .swatch-hex { font-size: .65rem; font-family: monospace; color: #888; }
    .changes { display: flex; flex-direction: column; gap: 10px; }
    .change { background: var(--card); border: 1px solid var(--border); border-radius: 6px; padding: 14px 16px; display: flex; gap: 14px; align-items: flex-start; }
    .num { background: #d1fae5; color: #065f46; font-size: .7rem; font-family: monospace; padding: 2px 7px; border-radius: 4px; white-space: nowrap; margin-top: 2px; }
    .change-file { font-size: .65rem; font-family: monospace; color: #aaa; margin-bottom: 2px; }
    .change-what { font-size: .85rem; font-weight: 600; margin-bottom: 3px; }
    .change-detail { font-size: .75rem; color: #666; line-height: 1.5; }
    pre { background: #111; color: #6ee7b7; font-size: .72rem; border-radius: 8px; padding: 1.25rem; overflow-x: auto; white-space: pre-wrap; line-height: 1.6; }
    .copy-btn { background: #15803d; color: #fff; border: none; border-radius: 6px; padding: 8px 16px; font-size: .75rem; cursor: pointer; margin-bottom: 12px; display: inline-flex; align-items: center; gap: 6px; }
    .copy-btn:hover { background: #166534; }
    footer { text-align: center; font-size: .65rem; color: #aaa; margin-top: 3rem; }
    @media print {
      .copy-btn, .print-btn { display: none !important; }
      body { padding: 1rem; }
    }
  </style>
</head>
<body>
<div class="wrap">
  <div style="display:flex;justify-content:space-between;align-items:flex-start;margin-bottom:1.5rem">
    <div>
      <p style="font-size:.65rem;letter-spacing:.25em;text-transform:uppercase;color:hsl(39,82%,31%);margin-bottom:4px">Grannysroute.org</p>
      <h1>Herbal Tea Theme</h1>
      <p style="font-size:.85rem;color:#888;margin-top:4px">Design system · All changes · AI prompt</p>
    </div>
    <button class="print-btn copy-btn" onclick="window.print()" style="background:#fff;color:#333;border:1px solid #ccc">🖨 Print / PDF</button>
  </div>
  <hr />
  <h2>Color Palette</h2>
  <div class="swatches">
    <div><div class="swatch-box" style="background:hsl(110,18%,96%)"></div><p class="swatch-label">Background</p><p class="swatch-hex">#F4F7F2</p></div>
    <div><div class="swatch-box" style="background:hsl(123,16%,21%)"></div><p class="swatch-label">Foreground</p><p class="swatch-hex">#2C3E2D</p></div>
    <div><div class="swatch-box" style="background:hsl(105,21%,46%)"></div><p class="swatch-label">Primary</p><p class="swatch-hex">#6B8F5E</p></div>
    <div><div class="swatch-box" style="background:hsl(39,82%,31%)"></div><p class="swatch-label">Secondary</p><p class="swatch-hex">#8B6914</p></div>
    <div><div class="swatch-box" style="background:hsl(110,14%,88%)"></div><p class="swatch-label">Muted</p><p class="swatch-hex">#D8E2D4</p></div>
    <div><div class="swatch-box" style="background:hsl(110,18%,80%)"></div><p class="swatch-label">Border</p><p class="swatch-hex">#C8D5C2</p></div>
    <div><div class="swatch-box" style="background:hsl(110,16%,93%)"></div><p class="swatch-label">Card</p><p class="swatch-hex">#EEF2EB</p></div>
  </div>
  <hr />
  <h2>All File Changes</h2>
  <div class="changes">
    <div class="change"><span class="num">01</span><div><p class="change-file">index.css</p><p class="change-what">Google Fonts import</p><p class="change-detail">Added Lora (serif) and Inter (sans-serif) from Google Fonts at the top of the file.</p></div></div>
    <div class="change"><span class="num">02</span><div><p class="change-file">index.css</p><p class="change-what">:root color tokens — Herbal Tea Palette</p><p class="change-detail">background: pale sage mist · foreground: deep forest green · primary: herbal sage green · secondary: chamomile gold · muted: misty leaf · border: misty green</p></div></div>
    <div class="change"><span class="num">03</span><div><p class="change-file">index.css</p><p class="change-what">body base styles</p><p class="change-detail">Set font-inter as default body font, 1.125rem base size, 1.6 line-height.</p></div></div>
    <div class="change"><span class="num">04</span><div><p class="change-file">index.css</p><p class="change-what">Custom utility classes</p><p class="change-detail">.paper-grain · .stitch-line · .provision-tilt · .granny-note · .deckle-edge</p></div></div>
    <div class="change"><span class="num">05</span><div><p class="change-file">tailwind.config.js</p><p class="change-what">fontFamily tokens</p><p class="change-detail">Added font-lora and font-inter mapped to CSS variables.</p></div></div>
    <div class="change"><span class="num">06</span><div><p class="change-file">components/ledger/HeroSection</p><p class="change-what">Quick Provisions links</p><p class="change-detail">External links for Granny's RV Garage and Bridgesafe. Improved mobile tap targets.</p></div></div>
    <div class="change"><span class="num">07</span><div><p class="change-file">lib/theme-reference.md</p><p class="change-what">Theme reference doc (new file)</p><p class="change-detail">Full palette, font tokens, utility docs saved for reuse across Base44 projects.</p></div></div>
  </div>
  <hr />
  <h2>AI Copy-Paste Prompt</h2>
  <p style="font-size:.8rem;color:#666;margin-bottom:10px">Open any Base44 app → chat with AI → paste this:</p>
  <button class="copy-btn" onclick="navigator.clipboard.writeText(document.getElementById('aiprompt').textContent)">📋 Copy Prompt</button>
  <pre id="aiprompt">Update my index.css — replace the entire :root block with this, and add the Google Fonts import at the very top if it's not already there:

@import url('https://fonts.googleapis.com/css2?family=Lora:ital,wght@0,400;0,500;0,600;0,700;1,400;1,500;1,600&family=Inter:wght@300;400;500;600&display=swap');

Then replace :root with:

:root {
  --font-lora: 'Lora', serif;
  --font-inter: 'Inter', sans-serif;
  --background: 110 18% 96%;
  --foreground: 123 16% 21%;
  --card: 110 16% 93%;
  --card-foreground: 123 16% 21%;
  --primary: 105 21% 46%;
  --primary-foreground: 110 18% 97%;
  --secondary: 39 82% 31%;
  --secondary-foreground: 110 18% 97%;
  --muted: 110 14% 88%;
  --muted-foreground: 120 8% 42%;
  --accent: 39 82% 31%;
  --accent-foreground: 110 18% 97%;
  --destructive: 0 72% 51%;
  --destructive-foreground: 0 0% 98%;
  --border: 110 18% 80%;
  --input: 110 18% 80%;
  --ring: 105 21% 46%;
  --radius: 0.375rem;
}

Then in tailwind.config.js inside theme.extend add:

fontFamily: {
  lora: ['var(--font-lora)'],
  inter: ['var(--font-inter)'],
},

Also update body in index.css to:

body {
  @apply bg-background text-foreground font-inter;
  font-size: 1.125rem;
  line-height: 1.6;
}</pre>
  <hr />
  <footer>Grannysroute.org · Herbal Tea Design System · ${new Date().getFullYear()}</footer>
</div>
</body>
</html>`;

const CHANGES = [
  { file: 'index.css', what: 'Google Fonts import', detail: 'Added Lora (serif) and Inter (sans-serif) from Google Fonts at the top of the file.' },
  { file: 'index.css', what: ':root color tokens — Herbal Tea Palette', detail: 'background: pale sage mist · foreground: deep forest green · primary: herbal sage green · secondary: chamomile gold · muted: misty leaf · border: misty green' },
  { file: 'index.css', what: 'body base styles', detail: 'Set font-inter as default body font, 1.125rem base size, 1.6 line-height.' },
  { file: 'index.css', what: 'Custom utility classes', detail: '.paper-grain · .stitch-line · .provision-tilt · .granny-note · .deckle-edge' },
  { file: 'tailwind.config.js', what: 'fontFamily tokens', detail: 'Added font-lora and font-inter mapped to CSS variables.' },
  { file: 'components/ledger/HeroSection', what: 'Quick Provisions links', detail: "External links for Granny's RV Garage and Bridgesafe. Improved mobile tap targets." },
  { file: 'lib/theme-reference.md', what: 'Theme reference doc (new file)', detail: 'Full palette, font tokens, utility docs saved for reuse across Base44 projects.' },
];

const SWATCHES = [
  { label: 'Background', hsl: 'hsl(110,18%,96%)', hex: '#F4F7F2' },
  { label: 'Foreground', hsl: 'hsl(123,16%,21%)', hex: '#2C3E2D' },
  { label: 'Primary', hsl: 'hsl(105,21%,46%)', hex: '#6B8F5E' },
  { label: 'Secondary', hsl: 'hsl(39,82%,31%)', hex: '#8B6914' },
  { label: 'Muted', hsl: 'hsl(110,14%,88%)', hex: '#D8E2D4' },
  { label: 'Border', hsl: 'hsl(110,18%,80%)', hex: '#C8D5C2' },
  { label: 'Card', hsl: 'hsl(110,16%,93%)', hex: '#EEF2EB' },
];

function download(filename, content, type) {
  const blob = new Blob([content], { type });
  const url = URL.createObjectURL(blob);
  const a = document.createElement('a');
  a.href = url;
  a.download = filename;
  a.click();
  URL.revokeObjectURL(url);
}

export default function ThemeGuide() {
  const [copied, setCopied] = useState(false);

  const handleCopy = () => {
    navigator.clipboard.writeText(AI_PROMPT);
    setCopied(true);
    setTimeout(() => setCopied(false), 2500);
  };

  return (
    <div className="min-h-screen bg-white text-gray-900 font-sans">
      {/* Print styles injected inline */}
      <style>{`@media print { .no-print { display: none !important; } }`}</style>

      <div className="max-w-3xl mx-auto px-5 py-8 print:py-4 print:px-3">

        {/* Header */}
        <div className="flex flex-col sm:flex-row sm:items-start sm:justify-between gap-4 mb-7">
          <div>
            <p className="text-xs tracking-widest uppercase text-amber-700 mb-1">Grannysroute.org</p>
            <h1 className="text-2xl font-bold text-gray-900 leading-tight">Herbal Tea Theme</h1>
            <p className="text-xs text-gray-400 mt-1">Design system · All changes · AI prompt · Downloads</p>
          </div>
          <div className="no-print flex flex-wrap gap-2">
            <button
              onClick={() => window.print()}
              className="flex items-center gap-1.5 px-3 py-2 border border-gray-300 rounded text-xs text-gray-600 hover:bg-gray-50 transition-colors"
            >
              <Printer className="w-3.5 h-3.5" /> PDF
            </button>
            <button
              onClick={() => download('theme-guide.jsx', JSX_CONTENT, 'text/plain')}
              className="flex items-center gap-1.5 px-3 py-2 border border-gray-300 rounded text-xs text-gray-600 hover:bg-gray-50 transition-colors"
            >
              <Download className="w-3.5 h-3.5" /> .jsx
            </button>
            <button
              onClick={() => download('theme-guide.html', HTML_CONTENT, 'text/html')}
              className="flex items-center gap-1.5 px-3 py-2 bg-green-700 text-white rounded text-xs hover:bg-green-800 transition-colors"
            >
              <Download className="w-3.5 h-3.5" /> .html
            </button>
          </div>
        </div>

        <hr className="border-dashed border-gray-300 mb-7" />

        {/* Color Palette */}
        <section className="mb-8">
          <h2 className="text-[10px] tracking-widest uppercase text-amber-700 mb-3">Color Palette</h2>
          <div className="grid grid-cols-4 sm:grid-cols-7 gap-2">
            {SWATCHES.map((s) => (
              <div key={s.label}>
                <div className="h-10 rounded border border-gray-200 mb-1.5" style={{ background: s.hsl }} />
                <p className="text-[10px] font-semibold text-gray-700 leading-tight">{s.label}</p>
                <p className="text-[9px] text-gray-400 font-mono">{s.hex}</p>
              </div>
            ))}
          </div>
        </section>

        <hr className="border-dashed border-gray-300 mb-7" />

        {/* All Changes */}
        <section className="mb-8">
          <h2 className="text-[10px] tracking-widest uppercase text-amber-700 mb-3">All File Changes</h2>
          <div className="space-y-2.5">
            {CHANGES.map((c, i) => (
              <div key={i} className="flex gap-3 border border-gray-100 rounded p-3 bg-gray-50">
                <div className="text-[10px] font-mono bg-green-100 text-green-800 px-2 py-0.5 rounded h-fit whitespace-nowrap mt-0.5">
                  {String(i + 1).padStart(2, '0')}
                </div>
                <div>
                  <p className="text-[10px] font-mono text-gray-400">{c.file}</p>
                  <p className="text-xs font-semibold text-gray-800 mt-0.5 mb-0.5">{c.what}</p>
                  <p className="text-[11px] text-gray-500 leading-relaxed">{c.detail}</p>
                </div>
              </div>
            ))}
          </div>
        </section>

        <hr className="border-dashed border-gray-300 mb-7" />

        {/* AI Prompt */}
        <section className="mb-8">
          <div className="flex items-center justify-between mb-2">
            <h2 className="text-[10px] tracking-widest uppercase text-amber-700">AI Copy-Paste Prompt</h2>
            <button
              onClick={handleCopy}
              className="no-print flex items-center gap-1.5 px-3 py-1.5 bg-green-700 text-white text-xs rounded hover:bg-green-800 transition-colors"
            >
              {copied ? <Check className="w-3 h-3" /> : <Copy className="w-3 h-3" />}
              {copied ? 'Copied!' : 'Copy All'}
            </button>
          </div>
          <p className="text-[11px] text-gray-400 mb-2">
            Open any Base44 app → chat with AI → paste this entire block:
          </p>
          <pre className="bg-gray-900 text-green-300 text-[10px] rounded p-4 overflow-x-auto whitespace-pre-wrap leading-relaxed">
            {AI_PROMPT}
          </pre>
        </section>

        <hr className="border-dashed border-gray-300 mb-5" />
        <p className="text-[10px] text-gray-400 text-center">
          Grannysroute.org · Herbal Tea Design System · {new Date().getFullYear()}
        </p>
      </div>
    </div>
  );
}