import React from 'react';
import { motion } from 'framer-motion';
import { Link } from 'react-router-dom';
import { ArrowLeft, Heart } from 'lucide-react';
import Header from '../components/ledger/Header';

const ABOUT_IMG = 'https://media.base44.com/images/public/69f920d5e7e93373fc4461bb/4153142cb_generated_image.png';

export default function About() {
  return (
    <div className="paper-grain min-h-screen">
      <Header />

      <main className="pt-28 pb-20 px-6 md:px-12">
        <div className="max-w-3xl mx-auto">

          {/* Back link */}
          <motion.div
            initial={{ opacity: 0, x: -12 }}
            animate={{ opacity: 1, x: 0 }}
            transition={{ duration: 0.4 }}
          >
            <Link
              to="/"
              className="inline-flex items-center gap-2 font-inter text-xs tracking-wider uppercase text-muted-foreground hover:text-primary transition-colors mb-10"
            >
              <ArrowLeft className="w-3.5 h-3.5" />
              Back to the Pantry
            </Link>
          </motion.div>

          {/* Hero image */}
          <motion.div
            initial={{ opacity: 0, y: 20 }}
            animate={{ opacity: 1, y: 0 }}
            transition={{ duration: 0.6 }}
            className="provision-tilt rounded-sm overflow-hidden border border-border mb-12"
          >
            <img
              src={ABOUT_IMG}
              alt="A travel journal, steaming herbal tea, and a vintage road map on a warm kitchen table"
              className="w-full aspect-[16/7] object-cover"
            />
          </motion.div>

          {/* Label */}
          <motion.div
            initial={{ opacity: 0, y: 20 }}
            animate={{ opacity: 1, y: 0 }}
            transition={{ duration: 0.6, delay: 0.1 }}
          >
            <p className="font-inter text-[10px] tracking-[0.3em] uppercase text-secondary mb-4">
              Grannysroute.org · Our Story
            </p>

            <h1 className="font-lora text-3xl md:text-5xl font-bold text-foreground leading-tight mb-10">
              Welcome to our<br />
              <span className="italic font-normal text-primary">cozy haven!</span>
            </h1>
          </motion.div>

          {/* Body */}
          <motion.div
            initial={{ opacity: 0, y: 20 }}
            animate={{ opacity: 1, y: 0 }}
            transition={{ duration: 0.6, delay: 0.2 }}
            className="space-y-6 font-lora text-base md:text-lg text-foreground/80 leading-[1.8]"
          >
            <p>
              I'm so glad you stopped by! After many miles as a passenger with my
              truck-driver husband, Terry, I realized how naive I was about the world
              of solo RV traveling. The uncertainties can be daunting, and I knew
              there had to be a way to make it all easier and less stressful.
            </p>

            <p>
              So, off I went on a heartfelt journey of research — diving into safe
              travel tips, blogs, and everything in between. I pondered: Where should
              I start? Is my rig ready for the adventure ahead? Are my routes safe for
              my lovely RV? And let's not forget about those pesky bridges!
            </p>

            <p>
              Determined to find answers, I rolled up my sleeves and took matters into
              my own hands. The result? A wonderful little app called{' '}
              <span className="text-primary font-semibold">RVbridgesafe</span> that
              helps you navigate safely, along with our cherished{' '}
              <span className="text-primary font-semibold">grannysroute</span> app —
              both designed for weary travelers like us.
            </p>

            <div className="border-l-2 border-primary/30 pl-5 my-8">
              <p className="font-lora italic text-foreground/70">
                And there's even more warmth on the horizon! Coming soon is{' '}
                <span className="text-primary font-medium">grannysroute.org</span> — a
                delightful resource offering{' '}
                <span className="font-semibold text-foreground">FREE overnight stays</span>{' '}
                just waiting for you. Think of it as your home away from home wherever
                the road takes you.
              </p>
            </div>

            <p>
              We're here to wrap you in comfort and support during your adventures.
              So grab a cup of tea, settle in, and let's embrace the joy of wandering
              together!
            </p>
          </motion.div>

          {/* Signature */}
          <motion.div
            initial={{ opacity: 0, y: 20 }}
            animate={{ opacity: 1, y: 0 }}
            transition={{ duration: 0.6, delay: 0.35 }}
            className="mt-12"
          >
            <div className="stitch-line" />
            <div className="pt-8 flex items-start gap-4">
              <div>
                <p className="font-inter text-xs tracking-wider uppercase text-muted-foreground mb-1">
                  With love,
                </p>
                <p className="font-lora italic text-2xl md:text-3xl text-primary flex items-center gap-2">
                  Granny Foor
                  <Heart className="w-5 h-5 fill-primary text-primary" />
                </p>
                <p className="font-inter text-xs text-muted-foreground mt-1">
                  Founder, Grannysroute.org
                </p>
              </div>
            </div>
          </motion.div>

          {/* CTA back */}
          <motion.div
            initial={{ opacity: 0 }}
            animate={{ opacity: 1 }}
            transition={{ duration: 0.6, delay: 0.5 }}
            className="mt-14 text-center"
          >
            <Link
              to="/"
              className="inline-flex items-center gap-2 px-6 py-3 bg-primary text-primary-foreground font-inter text-sm tracking-wider uppercase rounded-sm hover:bg-primary/90 transition-colors shadow-lg shadow-primary/20"
            >
              Browse the Provisions
            </Link>
          </motion.div>

        </div>
      </main>
    </div>
  );
}