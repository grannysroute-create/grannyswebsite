import React, { useState } from 'react';
import { motion } from 'framer-motion';
import { Link } from 'react-router-dom';
import { ArrowLeft, RotateCcw, Printer, Download, ShoppingBag } from 'lucide-react';
import { base44 } from '@/api/base44Client';
import Header from '../components/ledger/Header';

const CATEGORIES = [
  {
    label: 'General Checks',
    items: [
      'Check Fluid Levels',
      'Inspect Tires',
      'Test Lights',
      'Inspect Battery',
      'Emergency Kit',
    ],
  },
  {
    label: 'Motorhome Specific Checks',
    items: [
      'Engine Check',
      'Generator Functionality',
      'Awning Operation',
    ],
  },
  {
    label: 'Towing Specific Checks',
    items: [
      'Hitch Inspection',
      'Load Balancing',
      'Safety Chains & Breakaway Switches',
    ],
  },
  {
    label: 'Interior Checks',
    items: [
      'Propane System Test',
      'Appliances & HVAC Functionality',
      'Fresh Water System',
    ],
  },
  {
    label: 'Exterior Checks',
    items: [
      'Seals & Caulking Inspection',
      'Clean Windows & Mirrors',
    ],
  },
  {
    label: 'Trip Prep',
    items: [
      'Roadside Assistance Plan',
      'Manuals Ready',
      'Confirm Reservations',
      'Trip Navigation Prep',
    ],
  },
];

// Flatten all items with a global index for tracking
const ALL_ITEMS = CATEGORIES.flatMap((cat) => cat.items);
const TOTAL = ALL_ITEMS.length;

export default function Checklist() {
  const [checked, setChecked] = useState({});
  const [downloading, setDownloading] = useState(false);

  const handleDownload = async () => {
    setDownloading(true);
    const res = await base44.functions.fetch('generateChecklistPDF');
    const blob = await res.blob();
    const url = URL.createObjectURL(blob);
    const a = document.createElement('a');
    a.href = url;
    a.download = 'RV-Pre-trip-Checklist-Grannysroute.pdf';
    a.click();
    URL.revokeObjectURL(url);
    setDownloading(false);
  };

  const toggle = (key) =>
    setChecked((prev) => ({ ...prev, [key]: !prev[key] }));

  const reset = () => setChecked({});

  const completedCount = Object.values(checked).filter(Boolean).length;
  const pct = Math.round((completedCount / TOTAL) * 100);

  let globalIndex = 0;

  return (
    <div className="paper-grain min-h-screen">
      <Header />

      <main className="pt-28 pb-20 px-6 md:px-12">
        <div className="max-w-2xl mx-auto">

          {/* Back */}
          <motion.div initial={{ opacity: 0, x: -12 }} animate={{ opacity: 1, x: 0 }} transition={{ duration: 0.4 }}>
            <Link
              to="/"
              className="inline-flex items-center gap-2 font-inter text-xs tracking-wider uppercase text-muted-foreground hover:text-primary transition-colors mb-10"
            >
              <ArrowLeft className="w-3.5 h-3.5" />
              Back to the Pantry
            </Link>
          </motion.div>

          {/* Header */}
          <motion.div initial={{ opacity: 0, y: 20 }} animate={{ opacity: 1, y: 0 }} transition={{ duration: 0.6 }}>
            <p className="font-inter text-[10px] tracking-[0.3em] uppercase text-secondary mb-4">
              Grannysroute.org · Pre-trip
            </p>
            <h1 className="font-lora text-3xl md:text-4xl font-bold text-foreground mb-2">
              RV Pre-trip<br />
              <span className="italic font-normal text-primary">Checklist</span>
            </h1>
            <p className="font-lora italic text-sm text-muted-foreground mb-8">
              Check each item before you roll out. Safe travels, friend!
            </p>

            {/* Progress bar */}
            <div className="mb-2 flex items-center justify-between font-inter text-xs text-muted-foreground">
              <span>{completedCount} of {TOTAL} complete</span>
              <span>{pct}%</span>
            </div>
            <div className="w-full h-2 bg-muted rounded-full overflow-hidden mb-3">
              <motion.div
                className="h-full bg-primary rounded-full"
                animate={{ width: `${pct}%` }}
                transition={{ duration: 0.4 }}
              />
            </div>
            {completedCount === TOTAL && (
              <p className="font-lora italic text-primary text-sm mb-4">
                ✓ All clear! You're ready to roll. Safe travels! 🌿
              </p>
            )}
          </motion.div>

          <div className="stitch-line" />

          {/* Categories */}
          <div className="space-y-10 mt-8">
            {CATEGORIES.map((cat, ci) => (
              <motion.div
                key={cat.label}
                initial={{ opacity: 0, y: 16 }}
                animate={{ opacity: 1, y: 0 }}
                transition={{ duration: 0.5, delay: 0.1 + ci * 0.06 }}
              >
                <p className="font-inter text-[10px] tracking-[0.25em] uppercase text-secondary mb-4">
                  {cat.label}
                </p>
                <div className="space-y-2">
                  {cat.items.map((item) => {
                    const key = `item-${globalIndex}`;
                    const num = ++globalIndex;
                    const isChecked = !!checked[key];
                    return (
                      <button
                        key={key}
                        onClick={() => toggle(key)}
                        className={`w-full flex items-center gap-4 px-4 py-3 rounded-sm border text-left transition-all duration-200 ${
                          isChecked
                            ? 'bg-primary/8 border-primary/30'
                            : 'bg-card border-border hover:border-primary/40 hover:bg-muted/40'
                        }`}
                      >
                        {/* Checkbox */}
                        <span className={`w-5 h-5 flex-shrink-0 rounded-sm border-2 flex items-center justify-center transition-colors duration-200 ${
                          isChecked ? 'bg-primary border-primary' : 'border-border'
                        }`}>
                          {isChecked && (
                            <svg className="w-3 h-3 text-primary-foreground" fill="none" viewBox="0 0 12 12">
                              <path d="M2 6l3 3 5-5" stroke="currentColor" strokeWidth="2" strokeLinecap="round" strokeLinejoin="round" />
                            </svg>
                          )}
                        </span>
                        <span className="font-inter text-xs text-muted-foreground w-5 flex-shrink-0">
                          {String(num).padStart(2, '0')}
                        </span>
                        <span className={`font-lora text-base transition-colors duration-200 ${
                          isChecked ? 'line-through text-muted-foreground' : 'text-foreground'
                        }`}>
                          {item}
                        </span>
                      </button>
                    );
                  })}
                </div>
              </motion.div>
            ))}
          </div>

          {/* Actions */}
          <div className="mt-12 flex flex-wrap gap-3 print:hidden">
            <button
              onClick={reset}
              className="inline-flex items-center gap-2 px-5 py-2.5 border border-border rounded-sm font-inter text-xs tracking-wider uppercase text-muted-foreground hover:text-foreground hover:border-foreground/30 transition-colors"
            >
              <RotateCcw className="w-3.5 h-3.5" />
              Reset
            </button>
            <button
              onClick={() => window.print()}
              className="inline-flex items-center gap-2 px-5 py-2.5 border border-border rounded-sm font-inter text-xs tracking-wider uppercase text-muted-foreground hover:text-foreground hover:border-foreground/30 transition-colors"
            >
              <Printer className="w-3.5 h-3.5" />
              Print
            </button>
            <button
              onClick={handleDownload}
              disabled={downloading}
              className="inline-flex items-center gap-2 px-5 py-2.5 bg-primary text-primary-foreground rounded-sm font-inter text-xs tracking-wider uppercase hover:bg-primary/90 transition-colors shadow-lg shadow-primary/20 disabled:opacity-60"
            >
              <Download className="w-3.5 h-3.5" />
              {downloading ? 'Generating...' : 'Download PDF'}
            </button>
            <a
              href="https://grannysroute.gumroad.com"
              target="_blank"
              rel="noopener noreferrer"
              className="inline-flex items-center gap-2 px-5 py-2.5 bg-secondary text-secondary-foreground rounded-sm font-inter text-xs tracking-wider uppercase hover:bg-secondary/90 transition-colors shadow-lg shadow-secondary/20"
            >
              <ShoppingBag className="w-3.5 h-3.5" />
              Get on Gumroad
            </a>
          </div>

        </div>
      </main>
    </div>
  );
}