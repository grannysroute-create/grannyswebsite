import React from 'react';
import Header from '../components/ledger/Header';
import HeroSection from '../components/ledger/HeroSection';
import PantryShelf from '../components/ledger/PantryShelf';
import CommunityFooter from '../components/ledger/CommunityFooter';
import DisclosureBanner from '../components/ledger/DisclosureBanner';

export default function Home() {
  return (
    <div className="paper-grain">
      <DisclosureBanner />
      <Header />
      <HeroSection />
      <PantryShelf />
      <CommunityFooter />
    </div>
  );
}