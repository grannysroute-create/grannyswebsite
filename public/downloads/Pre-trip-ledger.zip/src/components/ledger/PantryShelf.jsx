import React from 'react';
import { motion } from 'framer-motion';
import ProvisionCard from './ProvisionCard';

const provisions = [
  {
    name: 'Gumroad',
    url: 'https://gumroad.com',
    image: 'https://media.base44.com/images/public/69f920d5e7e93373fc4461bb/2375d02cc_generated_6f47d500.png',
    imageAlt: 'An open creative workbook with colorful bookmarks, a fountain pen, and dried flowers pressed between pages',
    category: 'Digital Goods & Crafts',
    description: 'The marketplace for creators who make things with heart. Sell your digital guides, templates, and handmade wisdom right from your kitchen table.',
    grannyNote: 'This is where I sell my little recipe eBook. Simple as pie to set up!',
    trustLine: 'Granny-tested since 2021',
  },
  {
    name: 'Amazon',
    url: 'https://amazon.com',
    image: 'https://media.base44.com/images/public/69f920d5e7e93373fc4461bb/2f1ab3e92_generated_3137fb9d.png',
    imageAlt: 'A brown paper package tied with string on a weathered porch step with gardening gloves and fresh vegetables',
    category: 'Home & Essentials',
    description: 'When you can\'t find it at the local five-and-dime, Amazon delivers it right to your door. We link only the things we\'d buy twice.',
    grannyNote: 'I only share what I\'d put in my own cart, sugar.',
    trustLine: 'The reliable neighbor',
  },
  {
    name: 'Upside',
    url: 'https://upside.app.link',
    image: 'https://media.base44.com/images/public/69f920d5e7e93373fc4461bb/8319dbd41_generated_31012253.png',
    imageAlt: 'A vintage leather coin purse with coins on a rustic table next to a receipt and potted herb',
    category: 'Savings & Cash Back',
    description: 'Get cash back on gas, groceries, and dining out. It\'s like finding a dollar in your coat pocket — every single time.',
    grannyNote: 'I saved $14 last month just pumping gas. That\'s a whole pie\'s worth of berries!',
    trustLine: 'Every penny counts',
  },
  {
    name: 'GasBuddy',
    url: 'https://gasbuddy.com',
    image: 'https://media.base44.com/images/public/69f920d5e7e93373fc4461bb/c92425bb4_generated_e4675035.png',
    imageAlt: 'A vintage gas gauge on a rustic wooden shelf beside a glass jar of coins and dried herbs',
    category: 'Travel & Fuel',
    description: 'Never overpay at the pump again. GasBuddy finds you the cheapest gas wherever your wheels take you.',
    grannyNote: 'Saved us from a $5-a-gallon station in Nevada. Bless this app!',
    trustLine: 'Road-tested wisdom',
  },
  {
    name: 'Visible',
    url: 'https://visible.com',
    image: 'https://media.base44.com/images/public/69f920d5e7e93373fc4461bb/25a8170a9_generated_3c92ca11.png',
    imageAlt: 'A stack of handwritten letters tied with twine on a wooden desk beside dried wildflowers',
    category: 'Phone & Connectivity',
    description: 'Affordable, no-contract phone service that keeps you connected without the big-company runaround. Just straightforward service.',
    grannyNote: 'I pay $25 a month. My grandkids can\'t believe it!',
    trustLine: 'Staying connected, simply',
  },
  {
    name: 'Walmart',
    url: 'https://walmart.com',
    image: 'https://media.base44.com/images/public/69f920d5e7e93373fc4461bb/a2ec0696a_generated_58630062.png',
    imageAlt: 'A well-stocked wooden pantry shelf with mason jars of grains, spices, and a woven basket of produce',
    category: 'Groceries & Household',
    description: 'From stocking the pantry to outfitting the grandkids. Reliable prices and pickup that saves your aching knees a trip down every aisle.',
    grannyNote: 'Pickup orders changed my life. More time for the garden!',
    trustLine: 'The family staple',
  },
];

export default function PantryShelf() {
  return (
    <section id="pantry" className="py-8 px-4">
      <div className="max-w-6xl mx-auto">
        <motion.div
          initial={{ opacity: 0, y: 20 }}
          whileInView={{ opacity: 1, y: 0 }}
          viewport={{ once: true }}
          transition={{ duration: 0.6 }}
          className="mb-12 md:mb-16"
        >
          <p className="font-inter text-[10px] tracking-[0.3em] uppercase text-secondary mb-3">
            Browse Our Shelves
          </p>
          <h2 className="font-lora text-3xl md:text-5xl font-bold text-foreground mb-4">
            Quick Provisions
          </h2>
          <p className="font-lora italic text-base text-muted-foreground max-w-xl leading-relaxed">
            Each provision below has been tested, used, and vouched for.
            Hover over any one to read the handwritten note I'd tuck
            inside if I were mailing this to you.
          </p>
        </motion.div>

        <div id="provisions" className="grid sm:grid-cols-2 lg:grid-cols-3 gap-6 md:gap-8">
          {provisions.map((p, i) => (
            <ProvisionCard key={p.name} provision={p} index={i} />
          ))}
        </div>
      </div>
    </section>
  );
}