import React from 'react';

export default function WaxSeal() {
  return (
    <svg
      width="80"
      height="80"
      viewBox="0 0 80 80"
      fill="none"
      xmlns="http://www.w3.org/2000/svg"
      className="opacity-60"
    >
      {/* Outer ring with wavy edges */}
      <path
        d="M40 2 L44 10 L52 4 L52 14 L60 10 L57 20 L66 18 L60 26 L68 28 L60 34 L68 38 L60 40 L68 44 L60 46 L66 54 L57 52 L60 62 L52 58 L52 66 L44 62 L40 70 L36 62 L28 66 L28 58 L20 62 L23 52 L14 54 L20 46 L12 44 L20 40 L12 38 L20 34 L12 28 L20 26 L14 18 L23 20 L20 10 L28 14 L28 4 L36 10 Z"
        fill="hsl(var(--primary))"
        opacity="0.15"
      />
      {/* Inner circle */}
      <circle cx="40" cy="38" r="22" fill="hsl(var(--primary))" opacity="0.12" />
      <circle cx="40" cy="38" r="18" stroke="hsl(var(--primary))" strokeWidth="1" fill="none" opacity="0.3" />
      {/* Text */}
      <text
        x="40"
        y="34"
        textAnchor="middle"
        fill="hsl(var(--primary))"
        fontSize="7"
        fontFamily="var(--font-lora)"
        letterSpacing="0.1em"
        opacity="0.5"
      >
        VETTED
      </text>
      <text
        x="40"
        y="44"
        textAnchor="middle"
        fill="hsl(var(--primary))"
        fontSize="6"
        fontFamily="var(--font-lora)"
        letterSpacing="0.08em"
        opacity="0.4"
      >
        & SEALED
      </text>
    </svg>
  );
}