import React, { useState, useEffect } from 'react';
import { base44 } from '@/api/base44Client';
import { motion, AnimatePresence } from 'framer-motion';
import { Send, MessageCircle } from 'lucide-react';
import TeaLeafRating from './TeaLeafRating';

export default function CommunityNotes({ provisionName }) {
  const [notes, setNotes] = useState([]);
  const [loading, setLoading] = useState(true);
  const [showForm, setShowForm] = useState(false);
  const [submitting, setSubmitting] = useState(false);
  const [form, setForm] = useState({ author_name: '', note: '', rating: 0 });

  useEffect(() => {
    base44.entities.CommunityNote
      .filter({ provision_name: provisionName }, '-created_date', 10)
      .then(setNotes)
      .finally(() => setLoading(false));
  }, [provisionName]);

  const handleSubmit = async (e) => {
    e.preventDefault();
    if (!form.note.trim() || form.rating === 0) return;
    setSubmitting(true);
    const created = await base44.entities.CommunityNote.create({
      provision_name: provisionName,
      author_name: form.author_name.trim() || 'A Friendly Neighbor',
      note: form.note.trim(),
      rating: form.rating,
    });
    setNotes((prev) => [created, ...prev]);
    setForm({ author_name: '', note: '', rating: 0 });
    setShowForm(false);
    setSubmitting(false);
  };

  return (
    <div
      className="border-t border-border pt-4 mt-2 bg-background"
      onClick={(e) => e.preventDefault()} // prevent card link navigation
    >
      {/* Header */}
      <div className="flex items-center justify-between mb-3">
        <p className="font-inter text-[10px] tracking-[0.2em] uppercase text-muted-foreground flex items-center gap-1.5">
          <MessageCircle className="w-3 h-3" />
          Community Notes
          {notes.length > 0 && (
            <span className="ml-1 bg-muted text-muted-foreground rounded-full px-1.5 py-0.5 text-[9px]">
              {notes.length}
            </span>
          )}
        </p>
        <button
          type="button"
          onClick={(e) => { e.preventDefault(); setShowForm(!showForm); }}
          className="font-inter text-[10px] tracking-wider uppercase text-primary hover:text-primary/80 transition-colors"
        >
          {showForm ? 'Cancel' : '+ Add Yours'}
        </button>
      </div>

      {/* Submission form */}
      <AnimatePresence>
        {showForm && (
          <motion.form
            initial={{ opacity: 0, height: 0 }}
            animate={{ opacity: 1, height: 'auto' }}
            exit={{ opacity: 0, height: 0 }}
            transition={{ duration: 0.3 }}
            onSubmit={handleSubmit}
            className="overflow-hidden mb-4"
          >
            <div className="bg-muted/40 rounded-sm border border-border p-3 space-y-3">
              <div>
                <label className="font-inter text-[10px] tracking-wider uppercase text-muted-foreground block mb-1">
                  Your Name (optional)
                </label>
                <input
                  type="text"
                  value={form.author_name}
                  onChange={(e) => setForm({ ...form, author_name: e.target.value })}
                  placeholder="e.g. Rose from Georgia"
                  className="w-full bg-background border border-border rounded-sm px-3 py-2 font-inter text-sm text-foreground placeholder:text-muted-foreground focus:outline-none focus:ring-1 focus:ring-primary"
                />
              </div>

              <div>
                <label className="font-inter text-[10px] tracking-wider uppercase text-muted-foreground block mb-1">
                  Your Tip *
                </label>
                <textarea
                  required
                  value={form.note}
                  onChange={(e) => setForm({ ...form, note: e.target.value })}
                  placeholder="Share a little granny wisdom…"
                  rows={2}
                  className="w-full bg-background border border-border rounded-sm px-3 py-2 font-lora italic text-sm text-foreground placeholder:text-muted-foreground focus:outline-none focus:ring-1 focus:ring-primary resize-none"
                />
              </div>

              <div>
                <label className="font-inter text-[10px] tracking-wider uppercase text-muted-foreground block mb-1.5">
                  Tea Leaf Rating *
                </label>
                <TeaLeafRating
                  value={form.rating}
                  onChange={(r) => setForm({ ...form, rating: r })}
                  size={22}
                />
              </div>

              <button
                type="submit"
                disabled={submitting || form.rating === 0 || !form.note.trim()}
                className="flex items-center gap-2 px-4 py-2 bg-primary text-primary-foreground font-inter text-xs tracking-wider uppercase rounded-sm hover:bg-primary/90 disabled:opacity-40 transition-colors"
              >
                <Send className="w-3 h-3" />
                {submitting ? 'Sharing…' : 'Share Wisdom'}
              </button>
            </div>
          </motion.form>
        )}
      </AnimatePresence>

      {/* Notes list */}
      {loading ? (
        <p className="font-inter text-xs text-muted-foreground italic">Loading notes…</p>
      ) : notes.length === 0 ? (
        <p className="font-lora italic text-xs text-muted-foreground">
          Be the first to share a tip about {provisionName}!
        </p>
      ) : (
        <div className="space-y-3">
          {notes.map((n) => (
            <div key={n.id} className="bg-muted/30 rounded-sm border border-border p-3">
              <div className="flex items-center justify-between mb-1.5">
                <span className="font-inter text-[10px] font-medium text-foreground/70">
                  {n.author_name || 'A Friendly Neighbor'}
                </span>
                <TeaLeafRating value={n.rating} readonly size={13} />
              </div>
              <p className="font-lora italic text-xs text-foreground/80 leading-relaxed">
                "{n.note}"
              </p>
            </div>
          ))}
        </div>
      )}
    </div>
  );
}