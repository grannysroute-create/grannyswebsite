import React from 'react';
import { motion } from 'framer-motion';
import { ChevronDown, ClipboardCheck } from 'lucide-react';
import { Link } from 'react-router-dom';

const HERO_IMG = 'https://media.base44.com/images/public/69f920d5e7e93373fc4461bb/b668fc5c6_generated_664b3e29.png';

export default function HeroSection() {
  return (
    <section id="hero" className="relative min-h-screen flex items-center">
      {/* Background image */}
      <div className="absolute inset-0">
        <img
          src={HERO_IMG}
          alt="A weathered wooden table with a leather journal, tea, and dried lavender in golden hour light"
          className="w-full h-full object-cover"
        />
        <div className="absolute inset-0 bg-gradient-to-b from-background/70 via-background/50 to-background" />
      </div>

      <div className="relative z-10 w-full max-w-5xl mx-auto px-6 md:px-12 py-24 md:py-32">
        <motion.div
          initial={{ opacity: 0, y: 30 }}
          animate={{ opacity: 1, y: 0 }}
          transition={{ duration: 0.8, ease: 'easeOut' }}
        >
          <p className="font-inter text-xs tracking-[0.3em] uppercase text-secondary mb-6">
            Grannysroute.org
          </p>

          <h1 className="font-lora text-4xl md:text-6xl lg:text-7xl font-bold text-foreground leading-[1.1] mb-6">
            RV Pre-trip<br />
            <span className="italic font-normal text-primary">Check</span>
          </h1>

          <div className="max-w-lg">
            <p className="font-lora text-lg md:text-xl text-foreground/80 leading-relaxed mb-2">
              Your granny-vetted road kit — tried, tested, and trusted.
            </p>
            <p className="font-lora italic text-base text-muted-foreground leading-relaxed">
              Every provision on this page has been road-tested by real folks 
              who live the RV life. No fluff, no fancy sales talk — 
              just the good stuff, shared the old-fashioned way.
            </p>
          </div>
        </motion.div>

        <motion.div
          initial={{ opacity: 0 }}
          animate={{ opacity: 1 }}
          transition={{ delay: 1, duration: 0.6 }}
          className="mt-16 flex flex-wrap items-center gap-6"
        >
          <Link
            to="/checklist"
            className="inline-flex items-center gap-2 px-6 py-3 bg-primary text-primary-foreground font-inter text-sm tracking-wider uppercase rounded-sm hover:bg-primary/90 transition-colors shadow-lg shadow-primary/20"
          >
            <ClipboardCheck className="w-4 h-4" />
            Pre-trip Checklist
          </Link>
          <a
            href="https://rvgarage.grannysroute.org"
            target="_blank"
            rel="noopener"
            className="inline-flex items-center gap-2 font-inter text-sm tracking-wider uppercase text-muted-foreground hover:text-primary transition-colors duration-300"
          >
            Granny's RV Garage
          </a>
        </motion.div>

        <motion.div
          initial={{ opacity: 0 }}
          animate={{ opacity: 1 }}
          transition={{ delay: 1.3, duration: 0.6 }}
          className="mt-18 pt-6 border-t border-border/40"
        >
          <p className="font-inter text-2xl tracking-[0.3em] uppercase text-secondary mb-3 text-center">
            Granny's App Family
          </p>

          <div className="flex flex-col gap-2 items-center">
            {/* Text-only promo pills row — centered */}
            <div className="flex flex-wrap gap-2 justify-center">
              {[
                { name: 'GrannysRoute Planner', href: '#provision-gumroad', tag: 'Trip Planning' },
                { name: "Granny's RV Garage", href: '#provision-amazon', tag: 'Maintenance' },
                { name: 'Solar Weekend Check', href: '#provision-upside', tag: 'Energy' },
                { name: 'BridgeSafe', href: '#provision-gasbuddy', tag: 'Safety' },
              ].map((item) => (
                <a
                  key={item.name}
                  href={item.href}
                  onClick={(e) => {
                    e.preventDefault();
                    document.querySelector(item.href)?.scrollIntoView({ behavior: 'smooth', block: 'center' });
                  }}
                  className="group flex flex-col px-3 py-2 bg-background/60 backdrop-blur-sm border border-border/60 rounded-md hover:border-primary/60 hover:bg-background/80 transition-all duration-200 min-w-[140px] text-center items-center"
                >
                  <span className="font-inter text-xs tracking-[0.2em] uppercase text-secondary mb-0.5">{item.tag}</span>
                  <span className="font-lora text-base font-semibold text-foreground group-hover:text-primary transition-colors">{item.name}</span>
                </a>
              ))}
            </div>

            {/* Featured book co-promo — centered below */}
            <a
              href="#provision-walmart"
              onClick={(e) => {
                e.preventDefault();
                document.querySelector('#provision-walmart')?.scrollIntoView({ behavior: 'smooth', block: 'center' });
              }}
              className="group flex items-center gap-3 px-3 py-2 bg-secondary/10 border border-secondary/40 rounded-md hover:border-secondary/80 hover:bg-secondary/20 transition-all duration-200"
            >
              <img
                src="https://media.base44.com/images/public/69f920d5e7e93373fc4461bb/ee079291d_RangerSquadseries1.png"
                alt="The $5 Ranger Squad"
                className="h-14 w-auto rounded shadow-md flex-shrink-0"
              />
              <div className="flex flex-col items-center text-center">
                <span className="font-inter text-xs tracking-[0.2em] uppercase text-secondary mb-0.5">Featured Book</span>
                <span className="font-lora text-base font-bold text-foreground group-hover:text-secondary transition-colors leading-tight">The $5 Ranger Squad</span>
                <span className="font-lora italic text-xs text-muted-foreground mt-0.5">by Granny Foor</span>
              </div>
            </a>
          </div>
        </motion.div>
      </div>
    </section>
  );
}