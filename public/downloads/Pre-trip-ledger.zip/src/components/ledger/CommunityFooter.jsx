import React from 'react';
import { motion } from 'framer-motion';
import { Heart } from 'lucide-react';
import { Link } from 'react-router-dom';
import WaxSeal from './WaxSeal';

const footerLinks = [
  { name: 'Gumroad', url: 'https://gumroad.com' },
  { name: 'Amazon', url: 'https://amazon.com' },
  { name: 'Upside', url: 'https://upside.app.link' },
  { name: 'GasBuddy', url: 'https://gasbuddy.com' },
  { name: 'Visible', url: 'https://visible.com' },
  { name: 'Walmart', url: 'https://walmart.com' },
];

export default function CommunityFooter() {
  return (
    <footer id="footer" className="bg-card border-t border-border">
      <div className="max-w-6xl mx-auto px-6 md:px-12 py-16 md:py-24">
        <motion.div
          initial={{ opacity: 0, y: 20 }}
          whileInView={{ opacity: 1, y: 0 }}
          viewport={{ once: true }}
          transition={{ duration: 0.6 }}
        >
          {/* Logo centered */}
          <div className="flex justify-center mb-8">
            <img
              src="https://media.base44.com/images/public/69f920d5e7e93373fc4461bb/354cceab9_1780191435503.png"
              alt="Granny's Route logo"
              className="w-48 h-48 object-contain"
            />
          </div>

          {/* Header row */}
          <div className="flex flex-col items-center text-center gap-4 mb-12">
            <h3 className="font-lora text-2xl md:text-3xl font-bold text-foreground">
              Every link here is a handshake.
            </h3>
            <p className="font-lora italic text-sm text-muted-foreground max-w-md leading-relaxed">
              These are affiliate links, which means we may earn a small 
              commission at no extra cost to you. But here's the promise: 
              we only share what we genuinely use and believe in. 
              Your trust is worth more than any commission.
            </p>
            <WaxSeal />
          </div>

          <div className="stitch-line" />

          {/* Bottom */}
          <div className="pt-8 flex flex-col items-center gap-3 text-center">
            <div className="flex flex-wrap justify-center items-center gap-2">
              <p className="font-inter text-xs text-muted-foreground">
                © {new Date().getFullYear()} Grannysroute.org — RV Pre-trip Check
              </p>
              <span className="text-muted-foreground text-xs">·</span>
              <Link to="/about" className="font-inter text-xs text-primary hover:text-primary/80 transition-colors">
                About Granny Foor
              </Link>
              <span className="text-muted-foreground text-xs">·</span>
              <Link to="/privacy" className="font-inter text-xs text-primary hover:text-primary/80 transition-colors">
                Privacy Policy
              </Link>
            </div>
            <p className="font-lora italic text-xs text-muted-foreground flex items-center gap-1.5">
              Made with <Heart className="w-3 h-3 text-primary fill-primary" /> and a good cup of tea
            </p>
          </div>
        </motion.div>
      </div>
    </footer>
  );
}