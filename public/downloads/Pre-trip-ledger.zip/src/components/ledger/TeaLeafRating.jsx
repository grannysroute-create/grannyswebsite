import React from 'react';

// SVG tea leaf used as the rating icon
function TeaLeaf({ filled, onClick, size = 20 }) {
  return (
    <button
      type="button"
      onClick={onClick}
      className="focus:outline-none transition-transform duration-150 hover:scale-125"
      aria-label={`Rate ${filled} tea leaves`}
    >
      <svg
        width={size}
        height={size}
        viewBox="0 0 24 24"
        fill="none"
        xmlns="http://www.w3.org/2000/svg"
      >
        {/* Leaf shape */}
        <path
          d="M12 2 C12 2 5 6 5 13 C5 17.4 8.1 21 12 21 C15.9 21 19 17.4 19 13 C19 6 12 2 12 2Z"
          fill={filled ? 'hsl(var(--primary))' : 'hsl(var(--muted))'}
          stroke={filled ? 'hsl(var(--primary))' : 'hsl(var(--border))'}
          strokeWidth="1"
          opacity={filled ? 1 : 0.5}
        />
        {/* Stem vein */}
        <line
          x1="12" y1="21" x2="12" y2="10"
          stroke={filled ? 'hsl(var(--primary-foreground))' : 'hsl(var(--muted-foreground))'}
          strokeWidth="1"
          strokeOpacity={filled ? 0.5 : 0.3}
        />
        {/* Side veins */}
        <line x1="12" y1="14" x2="9" y2="11"
          stroke={filled ? 'hsl(var(--primary-foreground))' : 'hsl(var(--muted-foreground))'}
          strokeWidth="0.8" strokeOpacity={filled ? 0.4 : 0.2} />
        <line x1="12" y1="14" x2="15" y2="11"
          stroke={filled ? 'hsl(var(--primary-foreground))' : 'hsl(var(--muted-foreground))'}
          strokeWidth="0.8" strokeOpacity={filled ? 0.4 : 0.2} />
      </svg>
    </button>
  );
}

export default function TeaLeafRating({ value, onChange, readonly = false, size = 20 }) {
  return (
    <div className="flex items-center gap-1">
      {[1, 2, 3, 4, 5].map((leaf) => (
        <TeaLeaf
          key={leaf}
          filled={leaf <= value}
          size={size}
          onClick={readonly ? undefined : () => onChange && onChange(leaf)}
        />
      ))}
    </div>
  );
}