import React, { useState } from 'react';
import { motion, AnimatePresence } from 'framer-motion';
import { X } from 'lucide-react';
import { useNavigate } from 'react-router-dom';

const menuItems = [
  { label: 'The Gathering Table', href: '#hero' },
  { label: 'The Shared Pantry', href: '#pantry' },
  { label: 'Our Provisions', href: '#provisions' },
  { label: 'Community Ledger', href: '#footer' },
  { label: 'Pre-trip Checklist', href: '/checklist', isPage: true },
  { label: 'About Granny', href: '/about', isPage: true },
];

export default function IndexMenu() {
  const [open, setOpen] = useState(false);
  const navigate = useNavigate();

  const scrollTo = (href, isPage) => {
    setOpen(false);
    if (isPage) { navigate(href); return; }
    setTimeout(() => {
      const el = document.querySelector(href);
      if (el) el.scrollIntoView({ behavior: 'smooth' });
    }, 300);
  };

  return (
    <>
      <button
        onClick={() => setOpen(true)}
        className="font-lora text-sm tracking-[0.2em] uppercase text-foreground/70 hover:text-primary transition-colors duration-300"
      >
        Menu
      </button>

      <AnimatePresence>
        {open && (
          <>
            <motion.div
              initial={{ opacity: 0 }}
              animate={{ opacity: 1 }}
              exit={{ opacity: 0 }}
              className="fixed inset-0 bg-foreground/20 backdrop-blur-sm z-40"
              onClick={() => setOpen(false)}
            />
            <motion.nav
              initial={{ x: '100%' }}
              animate={{ x: 0 }}
              exit={{ x: '100%' }}
              transition={{ type: 'spring', damping: 30, stiffness: 300 }}
              className="fixed top-0 right-0 h-full w-80 max-w-[85vw] bg-[#f0ead6]/95 border-l border-border z-50 p-8 flex flex-col"
            >
              <button
                onClick={() => setOpen(false)}
                className="self-end mb-12 text-muted-foreground hover:text-foreground transition-colors"
              >
                <X className="w-5 h-5" />
              </button>

              <p className="font-lora text-xs tracking-[0.25em] uppercase text-muted-foreground mb-8">
                Table of Contents
              </p>

              <div className="space-y-1">
                {menuItems.map((item, i) => (
                  <button
                    key={item.href}
                    onClick={() => scrollTo(item.href, item.isPage)}
                    className="block w-full text-left py-3 px-2 font-lora text-lg font-bold text-[#1a4a3a] hover:text-[#0f2e24] hover:bg-[#d6e8d6]/50 rounded transition-all duration-200"
                  >
                    <span className="text-muted-foreground text-sm mr-3 font-inter">
                      {String(i + 1).padStart(2, '0')}
                    </span>
                    {item.label}
                  </button>
                ))}
              </div>

              <div className="mt-auto stitch-line pt-6">
                <p className="font-lora italic text-sm text-muted-foreground leading-relaxed">
                  "Every good thing shared is a seed planted for someone else's harvest."
                </p>
              </div>
            </motion.nav>
          </>
        )}
      </AnimatePresence>
    </>
  );
}