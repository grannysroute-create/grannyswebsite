import React from 'react';
import { motion } from 'framer-motion';
import { ExternalLink } from 'lucide-react';
import CommunityNotes from './CommunityNotes';

export default function ProvisionCard({ provision, index }) {
  return (
    <motion.div
      initial={{ opacity: 0, y: 40 }}
      whileInView={{ opacity: 1, y: 0 }}
      viewport={{ once: true, margin: '-60px' }}
      transition={{ duration: 0.6, delay: index * 0.1 }}
      id={`provision-${provision.name.toLowerCase()}`}
      className="provision-tilt group bg-card rounded-sm border border-border overflow-hidden"
    >
      {/* Clickable image + header area */}
      <a
        href={provision.url}
        target="_blank"
        rel="noopener noreferrer"
        className="block"
      >
        {/* Content */}
        <div className="p-3">
          <p className="font-inter text-[10px] tracking-[0.25em] uppercase text-secondary mb-3">
            {provision.category}
          </p>

          <h3 className="font-lora text-xl md:text-2xl font-semibold text-foreground mb-2 group-hover:text-primary transition-colors duration-300">
            {provision.name}
          </h3>

          <p className="font-inter text-sm text-muted-foreground leading-relaxed mb-4">
            {provision.description}
          </p>

          <div className="stitch-line" />

          <div className="flex items-center justify-between mt-4">
            <span className="font-lora italic text-sm text-muted-foreground">
              {provision.trustLine}
            </span>
            <span className="flex items-center gap-1.5 font-inter text-xs tracking-wider uppercase text-primary group-hover:gap-2.5 transition-all duration-300">
              Visit
              <ExternalLink className="w-3.5 h-3.5" />
            </span>
          </div>
        </div>
      </a>

      {/* Community Notes — outside the <a> so clicks don't navigate */}
      <div className="px-3 pb-3">
        <CommunityNotes provisionName={provision.name} />
      </div>
    </motion.div>
  );
}