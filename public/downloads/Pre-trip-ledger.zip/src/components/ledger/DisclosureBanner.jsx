import React, { useState } from 'react';
import { X } from 'lucide-react';

const STORAGE_KEY = 'granny_disclosure_dismissed';

export default function DisclosureBanner() {
  const [visible, setVisible] = useState(() => {
    try { return !localStorage.getItem(STORAGE_KEY); } catch { return true; }
  });

  const dismiss = () => {
    try { localStorage.setItem(STORAGE_KEY, '1'); } catch {}
    setVisible(false);
  };

  if (!visible) return null;

  return (
    <div className="w-full bg-secondary/10 border-b border-secondary/20 px-4 py-2.5 flex items-center justify-between gap-4">
      <p className="font-inter text-xs text-foreground/70 leading-relaxed max-w-2xl mx-auto text-center">
        <span className="font-semibold text-secondary">Affiliate Disclosure:</span>{' '}
        Some links on this page are affiliate links. We may earn a small commission at no extra
        cost to you — we only recommend what we genuinely use and trust.{' '}
        <a href="/privacy" className="underline underline-offset-2 hover:text-primary transition-colors">
          Privacy Policy
        </a>
      </p>
      <button
        onClick={dismiss}
        aria-label="Dismiss disclosure"
        className="flex-shrink-0 text-muted-foreground hover:text-foreground transition-colors"
      >
        <X className="w-3.5 h-3.5" />
      </button>
    </div>
  );
}