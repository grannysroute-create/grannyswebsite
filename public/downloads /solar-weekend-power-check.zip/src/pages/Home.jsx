import { useState } from 'react';
import SetupScreen from './SetupScreen';
import ResultsScreen from './ResultsScreen';
import ShoppingListScreen from './ShoppingListScreen';
import { calculatePower } from '../lib/powerCalc';

// Screens
const SCREEN = {
  SETUP: 'setup',
  RESULTS: 'results',
  SHOPPING: 'shopping',
};

export default function Home() {
  const [screen, setScreen] = useState(SCREEN.SETUP);
  const [inputs, setInputs] = useState(null);
  const [result, setResult] = useState(null);

  const handleCalculate = (formInputs) => {
    const calc = calculatePower(formInputs);
    setInputs(formInputs);
    setResult(calc);
    setScreen(SCREEN.RESULTS);
    window.scrollTo(0, 0);
  };

  const handlePurchase = () => {
    // In a real native app this triggers StoreKit / Google Play Billing.
    // In the web preview we navigate to the purchase screen.
    setScreen(SCREEN.SHOPPING);
    window.scrollTo(0, 0);
  };

  const handleBack = () => {
    if (screen === SCREEN.SHOPPING) {
      setScreen(SCREEN.RESULTS);
    } else {
      setScreen(SCREEN.SETUP);
    }
    window.scrollTo(0, 0);
  };

  if (screen === SCREEN.RESULTS && result && inputs) {
    return (
      <ResultsScreen
        result={result}
        inputs={inputs}
        onBack={handleBack}
        onPurchase={handlePurchase}
      />
    );
  }

  if (screen === SCREEN.SHOPPING) {
    return (
      <ShoppingListScreen
        onBack={handleBack}
        onPurchase={() => alert('In the published app, this triggers your Apple / Google in-app purchase (product ID: weekend_power_list_999).')}
      />
    );
  }

  return <SetupScreen onCalculate={handleCalculate} />;
}