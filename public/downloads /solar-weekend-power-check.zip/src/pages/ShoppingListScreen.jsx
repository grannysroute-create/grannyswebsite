import React, { useMemo, useState } from "react";
import { useNavigate } from "react-router-dom";
import { motion } from "framer-motion";
import { ArrowLeft, Check, ShoppingCart, Lock, Heart } from "lucide-react";
import AppHeader from "../components/AppHeader";
import AppFooter from "../components/AppFooter";
import { calculatePower } from "../lib/powerCalc";

const benefits = [
  "Exact panel, battery & controller sizes for your trip",
  "Links to cheapest parts on Amazon & Walmart today",
  "Printable PDF to take to the RV store",
  "No monthly fees — yours forever",
];

export default function ShoppingListScreen() {
  const navigate = useNavigate();
  const [purchased, setPurchased] = useState(false);

  const input = useMemo(() => {
    const raw = sessionStorage.getItem("powerCalcInput");
    if (!raw) return null;
    return JSON.parse(raw);
  }, []);

  const result = useMemo(() => {
    if (!input) return null;
    return calculatePower(input);
  }, [input]);

  const handlePurchase = () => {
    // In a real app, this triggers Apple IAP or Google Play Billing
    // For Base44 web preview, we simulate the unlock
    setPurchased(true);
  };

  if (!input || !result) {
    return (
      <div className="min-h-screen bg-[#F5F5DC] flex flex-col items-center justify-center p-6">
        <p className="text-[#2F3E34] text-lg font-bold mb-4">Run a power check first!</p>
        <button
          onClick={() => navigate("/")}
          className="bg-[#6A8D73] text-white font-bold py-3 px-6 rounded-xl"
        >
          Go to Setup
        </button>
      </div>
    );
  }

  return (
    <div className="min-h-screen bg-[#F5F5DC] flex flex-col">
      <AppHeader title={purchased ? "Your Shopping List" : "$9.99 One-Time Purchase"} />

      <motion.div
        initial={{ opacity: 0, y: 12 }}
        animate={{ opacity: 1, y: 0 }}
        transition={{ duration: 0.3 }}
        className="flex-1 px-4 py-5 space-y-4 max-w-lg mx-auto w-full"
      >
        <button
          onClick={() => navigate("/results")}
          className="flex items-center gap-1.5 text-[#6A8D73] text-sm font-bold mb-1"
        >
          <ArrowLeft className="w-4 h-4" />
          Back to Results
        </button>

        {!purchased ? (
          <PurchasePrompt onPurchase={handlePurchase} />
        ) : (
          <ShoppingListContent result={result} input={input} />
        )}
      </motion.div>

      <AppFooter />
    </div>
  );
}

function PurchasePrompt({ onPurchase }) {
  return (
    <div className="bg-white rounded-xl p-5 border-2 border-[#6A8D73] shadow-md">
      <h2 className="text-[#2F3E34] text-xl font-extrabold mb-2">
        Get Your Exact Shopping List
      </h2>
      <p className="text-[#2F3E34] text-sm mb-4 leading-relaxed">
        Stop guessing what size solar panel or battery you need. For $9.99 you get:
      </p>
      <div className="space-y-2.5 mb-5">
        {benefits.map((b) => (
          <div key={b} className="flex items-start gap-2">
            <Check className="w-4 h-4 text-[#6A8D73] mt-0.5 shrink-0" />
            <span className="text-[#2F3E34] text-sm">{b}</span>
          </div>
        ))}
      </div>

      <div className="bg-[#F5F5DC] rounded-lg p-3 mb-5 flex items-start gap-2">
        <Heart className="w-4 h-4 text-[#D9A86C] mt-0.5 shrink-0" />
        <p className="text-[#2F3E34] text-xs italic leading-relaxed">
          From the creator of GrannysRoute.org — I built this after my battery died at 2am.
        </p>
      </div>

      <button
        onClick={onPurchase}
        className="w-full bg-[#6A8D73] text-white text-lg font-bold py-4 rounded-xl hover:bg-[#5a7d63] transition-colors shadow-lg flex items-center justify-center gap-2"
      >
        <ShoppingCart className="w-5 h-5" />
        Get Shopping List — $9.99
      </button>
      <p className="text-[#2F3E34] text-xs text-center mt-2 opacity-60">
        One-time purchase. No subscription. Paid through Apple or Google.
      </p>
    </div>
  );
}

function ShoppingListContent({ result, input }) {
  const { recommendedSolarWatts, recommendedBatteryAh, controllerAmps, extraSolarNeeded, extraBatteryNeeded } = result;
  const batteryLabel = input.batteryType === "lithium" ? "LiFePO4 Lithium" : input.batteryType === "agm" ? "AGM" : "Flooded Lead-Acid";

  const amazonSearch = (query) => `https://www.amazon.com/s?k=${encodeURIComponent(query)}`;
  const walmartSearch = (query) => `https://www.walmart.com/search?q=${encodeURIComponent(query)}`;

  const items = [
    {
      category: "Solar Panel",
      size: `${recommendedSolarWatts}W`,
      searchTerm: `${recommendedSolarWatts}W RV solar panel`,
      note: extraSolarNeeded > 0 ? `You need ${extraSolarNeeded}W more than your current setup` : "Your current panels are sufficient — upgrade for more margin",
    },
    {
      category: "Battery",
      size: `${recommendedBatteryAh}Ah ${batteryLabel}`,
      searchTerm: `${recommendedBatteryAh}Ah ${batteryLabel} RV battery`,
      note: extraBatteryNeeded > 0 ? `You need ${extraBatteryNeeded}Ah more than your current battery` : "Your current battery is sufficient — upgrade for more margin",
    },
    {
      category: "Charge Controller",
      size: `${controllerAmps}A MPPT`,
      searchTerm: `${controllerAmps}A MPPT solar charge controller`,
      note: "MPPT is more efficient than PWM. Match amps to your panel setup.",
    },
  ];

  return (
    <motion.div
      initial={{ opacity: 0, scale: 0.98 }}
      animate={{ opacity: 1, scale: 1 }}
      transition={{ duration: 0.3 }}
      className="space-y-4"
    >
      <div className="bg-[#C1D8C3] rounded-xl p-4 text-center">
        <p className="text-[#2F3E34] text-sm font-bold">
          📋 Your personalized list for {input.nights} night{input.nights > 1 ? "s" : ""} off-grid
        </p>
      </div>

      {items.map((item) => (
        <div key={item.category} className="bg-white rounded-xl p-4 border border-[#C1D8C3]/50 shadow-sm">
          <div className="flex items-center justify-between mb-2">
            <h3 className="text-[#2F3E34] text-base font-bold">{item.category}</h3>
            <span className="bg-[#6A8D73] text-white text-sm font-bold px-3 py-1 rounded-full">
              {item.size}
            </span>
          </div>
          <p className="text-[#2F3E34] text-xs mb-3 opacity-70">{item.note}</p>
          <div className="flex gap-2">
            <a
              href={amazonSearch(item.searchTerm)}
              target="_blank"
              rel="noopener noreferrer"
              className="flex-1 bg-[#F5F5DC] text-[#2F3E34] text-sm font-bold py-2.5 rounded-lg border border-[#6A8D73] text-center hover:bg-[#6A8D73] hover:text-white transition-colors"
            >
              Amazon
            </a>
            <a
              href={walmartSearch(item.searchTerm)}
              target="_blank"
              rel="noopener noreferrer"
              className="flex-1 bg-[#F5F5DC] text-[#2F3E34] text-sm font-bold py-2.5 rounded-lg border border-[#6A8D73] text-center hover:bg-[#6A8D73] hover:text-white transition-colors"
            >
              Walmart
            </a>
          </div>
        </div>
      ))}

      <div className="bg-white rounded-xl p-4 border border-[#C1D8C3]/50 shadow-sm text-center">
        <Lock className="w-5 h-5 text-[#6A8D73] mx-auto mb-2" />
        <p className="text-[#2F3E34] text-xs opacity-60">
          This list is yours forever. No subscription. No expiration.
        </p>
      </div>
    </motion.div>
  );
}