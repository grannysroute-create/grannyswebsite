import React, { useMemo } from "react";
import { useNavigate } from "react-router-dom";
import { motion } from "framer-motion";
import { ArrowLeft } from "lucide-react";
import AppHeader from "../components/AppHeader";
import AppFooter from "../components/AppFooter";
import ResultCard from "../components/results/ResultCard";
import PowerBreakdown from "../components/results/PowerBreakdown";
import WeatherSection from "../components/results/WeatherSection";
import PurchaseCard from "../components/results/PurchaseCard";
import { calculatePower } from "../lib/powerCalc";

export default function ResultsScreen() {
  const navigate = useNavigate();

  const input = useMemo(() => {
    const raw = sessionStorage.getItem("powerCalcInput");
    if (!raw) return null;
    return JSON.parse(raw);
  }, []);

  const result = useMemo(() => {
    if (!input) return null;
    return calculatePower(input);
  }, [input]);

  if (!input || !result) {
    return (
      <div className="min-h-screen bg-[#F5F5DC] flex flex-col items-center justify-center p-6">
        <p className="text-[#2F3E34] text-lg font-bold mb-4">No calculation data found.</p>
        <button
          onClick={() => navigate("/")}
          className="bg-[#6A8D73] text-white font-bold py-3 px-6 rounded-xl"
        >
          Go to Setup
        </button>
      </div>
    );
  }

  return (
    <div className="min-h-screen bg-[#F5F5DC] flex flex-col">
      <AppHeader title="Weekend Power Check by GrannysRoute.org" />

      <motion.div
        initial={{ opacity: 0, y: 12 }}
        animate={{ opacity: 1, y: 0 }}
        transition={{ duration: 0.3 }}
        className="flex-1 px-4 py-5 space-y-4 max-w-lg mx-auto w-full"
      >
        <button
          onClick={() => navigate("/")}
          className="flex items-center gap-1.5 text-[#6A8D73] text-sm font-bold mb-1"
        >
          <ArrowLeft className="w-4 h-4" />
          Edit My Setup
        </button>

        <ResultCard
          result={result}
          nights={input.nights}
          solarWatts={input.solarWatts}
          batteryAh={input.batteryAh}
          batteryType={input.batteryType}
          sunHours={input.sunHours}
        />

        <PowerBreakdown result={result} />

        <WeatherSection zipCode={input.zipCode} />

        <PurchaseCard />
      </motion.div>

      <AppFooter />
    </div>
  );
}