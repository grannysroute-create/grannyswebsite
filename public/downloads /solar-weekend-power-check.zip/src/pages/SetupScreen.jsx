import React, { useState } from "react";
import { useNavigate } from "react-router-dom";
import { motion } from "framer-motion";
import AppHeader from "../components/AppHeader";
import AppFooter from "../components/AppFooter";
import TripDetailsCard from "../components/setup/TripDetailsCard";
import PowerSystemCard from "../components/setup/PowerSystemCard";
import ApplianceChecklist, { DEFAULT_APPLIANCES } from "../components/setup/ApplianceChecklist";
import { Zap } from "lucide-react";

const initAppliances = DEFAULT_APPLIANCES.map(a => ({
  ...a,
  checked: a.defaultChecked,
}));

export default function SetupScreen() {
  const navigate = useNavigate();

  const [nights, setNights] = useState(3);
  const [sunHours, setSunHours] = useState(5);
  const [zipCode, setZipCode] = useState("");
  const [batteryType, setBatteryType] = useState("lithium");
  const [batteryAh, setBatteryAh] = useState("");
  const [solarWatts, setSolarWatts] = useState("");
  const [appliances, setAppliances] = useState(initAppliances);

  const canCalculate = Number(batteryAh) > 0;

  const handleCalculate = () => {
    const params = {
      nights,
      sunHours,
      batteryType,
      batteryAh: Number(batteryAh) || 0,
      solarWatts: Number(solarWatts) || 0,
      appliances,
      zipCode,
    };
    // Store in sessionStorage for results page
    sessionStorage.setItem("powerCalcInput", JSON.stringify(params));
    navigate("/results");
  };

  return (
    <div className="min-h-screen bg-[#F5F5DC] flex flex-col">
      {/* Branded Hero Header */}
      <div className="w-full py-5 px-4 text-center" style={{ background: '#F5C518' }}>
        <h1 className="font-extrabold text-2xl leading-tight tracking-tight" style={{ color: '#3E2F0A' }}>
          Granny's Solar Weekend Power Check
        </h1>
        <a
          href="https://grannysroute.org?ref=app"
          target="_blank"
          rel="noopener noreferrer"
          className="inline-block mt-1 underline underline-offset-2 opacity-80 hover:opacity-100" style={{ color: '#3E2F0A' }}
          style={{ fontSize: 12 }}
        >
          GrannysRoute.org
        </a>
      </div>

      <AppHeader title="Step 1: Tell Us About Your Trip" />

      <motion.div
        initial={{ opacity: 0, y: 12 }}
        animate={{ opacity: 1, y: 0 }}
        transition={{ duration: 0.3 }}
        className="flex-1 px-4 py-5 space-y-4 max-w-lg mx-auto w-full"
      >
        <TripDetailsCard
          nights={nights}
          setNights={setNights}
          sunHours={sunHours}
          setSunHours={setSunHours}
          zipCode={zipCode}
          setZipCode={setZipCode}
        />

        <PowerSystemCard
          batteryType={batteryType}
          setBatteryType={setBatteryType}
          batteryAh={batteryAh}
          setBatteryAh={setBatteryAh}
          solarWatts={solarWatts}
          setSolarWatts={setSolarWatts}
        />


        <ApplianceChecklist
          appliances={appliances}
          onChange={setAppliances}
        />

        <button
          onClick={handleCalculate}
          disabled={!canCalculate}
          className="w-full text-white text-lg font-bold py-4 rounded-xl shadow-lg transition-all disabled:opacity-40 disabled:cursor-not-allowed flex items-center justify-center gap-2"
          style={{ background: canCalculate ? '#B8860B' : '#8B6914' }}
        >
          <Zap className="w-5 h-5" />
          Check My Power
        </button>

        {!canCalculate && (
          <p className="text-[#2F3E34] text-xs text-center opacity-60">
            Enter your battery amp-hours to continue.
          </p>
        )}
      </motion.div>

      <AppFooter />
    </div>
  );
}