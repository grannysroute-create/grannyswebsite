export default function PowerSystemCard({ batteryType, batteryAh, solarWatts, setBatteryType, setBatteryAh, setSolarWatts }) {
  return (
    <div className="bg-white rounded-xl p-4 shadow-sm">
      <h2 className="font-bold text-base mb-4" style={{ color: '#2F3E34' }}>Your Power System</h2>

      {/* Battery Type */}
      <label className="block font-bold text-sm mb-1" style={{ color: '#2F3E34' }}>Battery Type</label>
      <select
        value={batteryType}
        onChange={e => setBatteryType(e.target.value)}
        className="w-full rounded-lg px-3 py-2 text-sm mb-4 border"
        style={{ background: '#FDF6E3', borderColor: '#E8D5A3', color: '#3E2F0A' }}
      >
        <option value="Lithium">Lithium</option>
        <option value="AGM">AGM</option>
        <option value="Flooded">Flooded</option>
      </select>

      {/* Battery Ah */}
      <label className="block font-bold text-sm mb-1" style={{ color: '#2F3E34' }}>Total Battery Amp Hours</label>
      <input
        type="number"
        inputMode="numeric"
        min={0}
        placeholder="100"
        value={batteryAh}
        onChange={e => setBatteryAh(e.target.value)}
        className="w-full rounded-lg px-3 py-2 text-sm border mb-1"
        style={{ background: '#FDF6E3', borderColor: '#E8D5A3', color: '#3E2F0A' }}
      />
      <p className="text-xs mb-4" style={{ color: '#2F3E34' }}>Check your battery label. Example: 100Ah</p>

      {/* Solar Watts */}
      <label className="block font-bold text-sm mb-1" style={{ color: '#2F3E34' }}>Solar Panel Watts on Roof</label>
      <input
        type="number"
        inputMode="numeric"
        min={0}
        placeholder="200"
        value={solarWatts}
        onChange={e => setSolarWatts(e.target.value)}
        className="w-full rounded-lg px-3 py-2 text-sm border mb-1"
        style={{ background: '#FDF6E3', borderColor: '#E8D5A3', color: '#3E2F0A' }}
      />
      <p className="text-xs" style={{ color: '#2F3E34' }}>Enter 0 if you have no panels.</p>
    </div>
  );
}