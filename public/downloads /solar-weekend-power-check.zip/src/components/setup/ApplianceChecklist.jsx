import { useState } from 'react';
import { Plus, X } from 'lucide-react';

export const DEFAULT_APPLIANCES = [
  { id: 'lights', label: 'LED Lights', watts: 20, hours: 5, defaultChecked: true, note: '5 hrs/day' },
  { id: 'fan', label: 'Vent Fan', watts: 35, hours: 8, defaultChecked: true, note: '8 hrs/day' },
  { id: 'fridge', label: '12V Fridge', watts: 45, hours: 24, defaultChecked: true, note: '24 hrs/day' },
  { id: 'phone', label: 'Phone Charging', watts: 10, hours: 2, defaultChecked: true, note: '2 hrs/day' },
  { id: 'cpap', label: 'CPAP (no heat)', watts: 30, hours: 8, defaultChecked: false, note: '8 hrs/night' },
  { id: 'cpap_heat', label: 'CPAP (with heat)', watts: 60, hours: 8, defaultChecked: false, note: '8 hrs/night' },
  { id: 'tv', label: 'TV / Laptop', watts: 50, hours: 3, defaultChecked: false, note: '3 hrs/day' },
  { id: 'coffee', label: 'Coffee Maker (inverter)', watts: 800, hours: 0.15, defaultChecked: false, note: '~10 min/day' },
];

export default function ApplianceChecklist({ appliances, onChange }) {
  const [showAdd, setShowAdd] = useState(false);
  const [newName, setNewName] = useState('');
  const [newWatts, setNewWatts] = useState('');
  const [newHours, setNewHours] = useState('');

  const toggle = (id) => {
    onChange(appliances.map(a => a.id === id ? { ...a, checked: !a.checked } : a));
  };

  const removeCustom = (id) => {
    onChange(appliances.filter(a => a.id !== id));
  };

  const addAppliance = () => {
    if (!newName || !newWatts || !newHours) return;
    const custom = {
      id: `custom_${Date.now()}`,
      label: newName,
      watts: Number(newWatts),
      hours: Number(newHours),
      checked: true,
      note: `${newHours} hrs/day`,
      isCustom: true,
    };
    onChange([...appliances, custom]);
    setNewName('');
    setNewWatts('');
    setNewHours('');
    setShowAdd(false);
  };

  return (
    <div className="bg-white rounded-xl p-4 shadow-sm">
      <h2 className="font-bold text-base mb-3" style={{ color: '#2F3E34' }}>
        What You Run
      </h2>
      <p className="text-sm mb-3" style={{ color: '#2F3E34' }}>
        Check what you will use each day:
      </p>

      <div className="flex flex-col gap-3">
        {appliances.map(a => (
          <div key={a.id} className="flex items-center gap-3">
            <button
              onClick={() => toggle(a.id)}
              className="w-6 h-6 rounded flex-shrink-0 border-2 flex items-center justify-center transition-colors"
              style={{
                background: a.checked ? '#B8860B' : 'white',
                borderColor: '#B8860B',
              }}
              aria-checked={a.checked}
              role="checkbox"
            >
              {a.checked && (
                <svg width="12" height="9" viewBox="0 0 12 9" fill="none">
                  <path d="M1 4L4.5 7.5L11 1" stroke="white" strokeWidth="2" strokeLinecap="round" strokeLinejoin="round" />
                </svg>
              )}
            </button>
            <div className="flex-1">
              <span className="text-sm font-semibold" style={{ color: '#2F3E34' }}>{a.label}</span>
              <span className="text-xs ml-2" style={{ color: '#8B6914' }}>{a.note}</span>
            </div>
            {a.isCustom && (
              <button onClick={() => removeCustom(a.id)} className="p-1" aria-label="Remove">
                <X size={14} color="#2F3E34" />
              </button>
            )}
          </div>
        ))}
      </div>

      {/* Add Custom Appliance */}
      {showAdd ? (
        <div className="mt-4 p-3 rounded-lg border" style={{ borderColor: '#E8D5A3', background: '#FDF6E3' }}>
          <p className="text-sm font-bold mb-2" style={{ color: '#2F3E34' }}>Add Appliance</p>
          <input
            className="w-full rounded px-2 py-1.5 text-sm border mb-2"
            style={{ borderColor: '#E8D5A3', background: 'white', color: '#3E2F0A' }}
            placeholder="Name (e.g. Electric Blanket)"
            value={newName}
            onChange={e => setNewName(e.target.value)}
          />
          <div className="flex gap-2 mb-2">
            <input
              className="flex-1 rounded px-2 py-1.5 text-sm border"
              style={{ borderColor: '#E8D5A3', background: 'white', color: '#3E2F0A' }}
              placeholder="Watts (e.g. 60)"
              type="number"
              inputMode="numeric"
              value={newWatts}
              onChange={e => setNewWatts(e.target.value)}
            />
            <input
              className="flex-1 rounded px-2 py-1.5 text-sm border"
              style={{ borderColor: '#E8D5A3', background: 'white', color: '#3E2F0A' }}
              placeholder="Hours/day"
              type="number"
              inputMode="decimal"
              value={newHours}
              onChange={e => setNewHours(e.target.value)}
            />
          </div>
          <div className="flex gap-2">
            <button
              onClick={addAppliance}
              className="flex-1 py-2 rounded-lg text-sm font-bold text-white"
              style={{ background: '#B8860B' }}
            >
              Add
            </button>
            <button
              onClick={() => setShowAdd(false)}
              className="flex-1 py-2 rounded-lg text-sm font-bold border"
              style={{ borderColor: '#B8860B', color: '#3E2F0A', background: '#FDF6E3' }}
            >
              Cancel
            </button>
          </div>
        </div>
      ) : (
        <button
          onClick={() => setShowAdd(true)}
          className="mt-4 flex items-center gap-1 text-sm font-semibold"
          style={{ color: '#B8860B' }}
        >
          <Plus size={16} /> Add other appliance
        </button>
      )}
    </div>
  );
}