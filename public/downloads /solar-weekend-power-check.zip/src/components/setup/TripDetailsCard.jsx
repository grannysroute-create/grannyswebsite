import { useState } from 'react';

function StyledSlider({ min, max, value, onChange, color = '#B8860B', track = '#E8D5A3' }) {
  const pct = ((value - min) / (max - min)) * 100;
  return (
    <div className="relative w-full my-1">
      <input
        type="range"
        min={min}
        max={max}
        value={value}
        onChange={e => onChange(Number(e.target.value))}
        className="w-full h-2 rounded-full appearance-none cursor-pointer"
        style={{
          background: `linear-gradient(to right, ${color} ${pct}%, ${track} ${pct}%)`,
          accentColor: color,
        }}
      />
    </div>
  );
}

export default function TripDetailsCard({ nights, sunHours, zipCode, setNights, setSunHours, setZipCode }) {
  const weatherUrl = `https://weatherpower.climatecentral.org/forecast?location=${zipCode || ''}`;

  return (
    <div className="bg-white rounded-xl p-4 shadow-sm">
      <h2 className="font-bold text-base mb-4" style={{ color: '#2F3E34' }}>Trip Details</h2>

      {/* Nights */}
      <label className="block font-bold text-sm mb-1" style={{ color: '#2F3E34' }}>
        How many nights off-grid?
      </label>
      <div className="text-2xl font-bold mb-1" style={{ color: '#2F3E34' }}>
        {nights} {nights === 1 ? 'night' : 'nights'}
      </div>
      <StyledSlider min={1} max={4} value={nights} onChange={setNights} />
      <div className="flex justify-between text-xs mb-4" style={{ color: '#2F3E34' }}>
        <span>1</span><span>2</span><span>3</span><span>4</span>
      </div>

      {/* Sun Hours */}
      <label className="block font-bold text-sm mb-1" style={{ color: '#2F3E34' }}>
        Avg sun hours per day at your campsite
      </label>
      <div className="text-2xl font-bold mb-1" style={{ color: '#2F3E34' }}>
        {sunHours} {sunHours === 1 ? 'hour' : 'hours'}
      </div>
      <StyledSlider min={3} max={7} value={sunHours} onChange={setSunHours} />
      <div className="flex justify-between text-xs mb-1" style={{ color: '#2F3E34' }}>
        <span>3</span><span>4</span><span>5</span><span>6</span><span>7</span>
      </div>
      <p className="text-xs mb-3" style={{ color: '#2F3E34' }}>
        Winter ≈ 4, Summer ≈ 6. Guessing is fine.
      </p>

      {/* Zip code */}
      <label className="block font-bold text-sm mb-1" style={{ color: '#2F3E34' }}>
        Your zip code <span className="font-normal text-xs">(for weather link)</span>
      </label>
      <input
        type="text"
        inputMode="numeric"
        maxLength={5}
        placeholder="e.g. 44471"
        value={zipCode}
        onChange={e => setZipCode(e.target.value.replace(/\D/g, ''))}
        className="w-full rounded-lg px-3 py-2 text-sm mb-3 border"
        style={{ background: '#FDF6E3', borderColor: '#E8D5A3', color: '#3E2F0A' }}
      />

      <a
        href={weatherUrl}
        target="_blank"
        rel="noopener noreferrer"
        className="text-sm underline font-semibold"
        style={{ color: '#8B6914' }}
      >
        Not sure? Check Live Solar Forecast →
      </a>
    </div>
  );
}