const GRANNY_APPS = [
  { label: "🚗 Granny's Garage", url: 'https://sherifoor.gumroad.com/l/grannysgarage?ref=app' },
  { label: "📋 Granny's RV Pre-trip Check", url: 'https://sherifoor.gumroad.com/l/rvpretrip?ref=app' },
  { label: "☀️ Granny's Solar Weekend Power Check", url: 'https://sherifoor.gumroad.com/l/solarpowercheck?ref=app' },
  { label: "🌉 RV BridgeSafe", url: 'https://sherifoor.gumroad.com/l/rvbridgesafe?ref=app' },
];

const SITE_LINKS = [
  { label: 'Visit GrannysRoute.org', url: 'https://grannysroute.org?ref=app' },
  { label: 'RV BridgeSafe - Avoid Low Bridges', url: 'https://rvpre-trip.grannysroute.org?ref=app' },
];

export default function AppFooter() {
  return (
    <footer className="px-4 py-5 mt-4" style={{ background: '#FFF8DC' }}>

      {/* Granny's App Family */}
      <div className="mb-5 rounded-xl p-4" style={{ background: '#F5C518' }}>
        <p className="text-center font-bold text-sm mb-1" style={{ color: '#3E2F0A' }}>
          🌻 Granny's App Family
        </p>
        <p className="text-center text-xs mb-3" style={{ color: '#5A3E10' }}>
          All available on Gumroad
        </p>
        <div className="flex flex-col gap-2">
          {GRANNY_APPS.map(app => (
            <a
              key={app.url}
              href={app.url}
              target="_blank"
              rel="noopener noreferrer"
              className="block text-center text-sm py-2 px-3 rounded-lg font-semibold transition-opacity hover:opacity-80"
              style={{ background: '#fff', color: '#3E2F0A', border: '1.5px solid #B8860B' }}
            >
              {app.label}
            </a>
          ))}
        </div>
      </div>

      {/* Site Links */}
      <div className="flex flex-col gap-2 mb-3">
        {SITE_LINKS.map(link => (
          <a
            key={link.url}
            href={link.url}
            target="_blank"
            rel="noopener noreferrer"
            className="block text-center text-sm py-2 px-3 rounded-lg border font-semibold hover:opacity-80"
            style={{ background: '#FDF6E3', color: '#3E2F0A', borderColor: '#B8860B' }}
          >
            {link.label}
          </a>
        ))}
      </div>

      <p className="text-center" style={{ color: '#6B5A3A', fontSize: 11 }}>
        Check your route for low bridges before you drive.
      </p>
    </footer>
  );
}