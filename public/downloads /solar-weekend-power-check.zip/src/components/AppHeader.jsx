export default function AppHeader({ title, showBack, onBack }) {
  return (
    <div className="sticky top-0 z-10 w-full flex items-center px-4 py-4" style={{ background: '#F5C518' }}>
      {showBack && (
        <button
          onClick={onBack}
          className="mr-3 text-2xl leading-none" style={{ color: '#3E2F0A' }}
          aria-label="Back"
        >
          ‹
        </button>
      )}
      <h1 className="flex-1 text-center font-bold text-lg leading-tight" style={{ color: '#3E2F0A' }}>
        {title}
      </h1>
      {showBack && <div className="w-6" />}
    </div>
  );
}