import React from "react";
import { Battery, Sun, Zap } from "lucide-react";

export default function PowerBreakdown({ result }) {
  const { dailyConsumptionWh, dailySolarWh, usableBatteryWh, netDailyDeficit } = result;

  const items = [
    {
      icon: Zap,
      label: "Daily Usage",
      value: `${dailyConsumptionWh} Wh/day`,
      color: "text-[#D9A86C]",
      bg: "bg-[#D9A86C]/10",
    },
    {
      icon: Sun,
      label: "Daily Solar Input",
      value: `${dailySolarWh} Wh/day`,
      color: "text-[#6A8D73]",
      bg: "bg-[#6A8D73]/10",
    },
    {
      icon: Battery,
      label: "Usable Battery",
      value: `${usableBatteryWh} Wh`,
      color: "text-[#2F3E34]",
      bg: "bg-[#2F3E34]/10",
    },
  ];

  return (
    <div className="bg-white rounded-xl p-4 shadow-sm border border-[#C1D8C3]/50">
      <h3 className="text-[#2F3E34] text-sm font-bold mb-3">Power Breakdown</h3>
      <div className="space-y-2.5">
        {items.map(({ icon: Icon, label, value, color, bg }) => (
          <div key={label} className="flex items-center justify-between">
            <div className="flex items-center gap-2.5">
              <div className={`${bg} rounded-lg p-1.5`}>
                <Icon className={`w-4 h-4 ${color}`} />
              </div>
              <span className="text-[#2F3E34] text-sm">{label}</span>
            </div>
            <span className="text-[#2F3E34] text-sm font-bold">{value}</span>
          </div>
        ))}
        <div className="border-t border-[#C1D8C3] pt-2 mt-2">
          <div className="flex items-center justify-between">
            <span className="text-[#2F3E34] text-sm font-bold">Net Daily</span>
            <span className={`text-sm font-bold ${netDailyDeficit > 0 ? "text-[#D9A86C]" : "text-[#6A8D73]"}`}>
              {netDailyDeficit > 0 ? `-${netDailyDeficit} Wh/day` : `+${Math.abs(netDailyDeficit)} Wh/day`}
            </span>
          </div>
        </div>
      </div>
    </div>
  );
}