import React from "react";
import { ShoppingCart, Check } from "lucide-react";
import { useNavigate } from "react-router-dom";

const benefits = [
  "Exact panel, battery & controller sizes for your trip",
  "Links to cheapest parts on Amazon & Walmart",
  "Printable PDF to take to the RV store",
  "No monthly fees — yours forever",
];

export default function PurchaseCard() {
  const navigate = useNavigate();

  return (
    <div className="bg-white rounded-xl p-5 shadow-sm border-2 border-[#6A8D73]">
      <h3 className="text-[#2F3E34] text-lg font-bold flex items-center gap-2 mb-4">
        <ShoppingCart className="w-5 h-5 text-[#6A8D73]" />
        Get Your Exact Shopping List — $9.99
      </h3>
      <div className="space-y-2.5 mb-5">
        {benefits.map((b) => (
          <div key={b} className="flex items-start gap-2">
            <Check className="w-4 h-4 text-[#6A8D73] mt-0.5 shrink-0" />
            <span className="text-[#2F3E34] text-sm">{b}</span>
          </div>
        ))}
      </div>
      <button
        onClick={() => navigate("/shopping-list")}
        className="w-full bg-[#6A8D73] text-white text-lg font-bold py-3.5 rounded-xl hover:bg-[#5a7d63] transition-colors shadow-md"
      >
        Get Shopping List — $9.99
      </button>
      <p className="text-[#2F3E34] text-xs text-center mt-2 opacity-60">
        One-time purchase. No subscription. Paid through Apple or Google.
      </p>
    </div>
  );
}