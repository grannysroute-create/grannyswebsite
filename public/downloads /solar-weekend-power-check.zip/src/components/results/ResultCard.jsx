import { CheckCircle, AlertTriangle } from 'lucide-react';

export default function ResultCard({ result, inputs }) {
  const { willLast, surplusHours, deficitNight, deficitHour, extraSolarNeeded, extraBatteryAh, appSummary } = result;
  const { nights, solarWatts, batteryAh, batteryType, sunHours } = inputs;

  const mainText = willLast
    ? surplusHours >= 99
      ? `Your solar covers everything — you're fully charged all ${nights} ${nights === 1 ? 'night' : 'nights'}!`
      : `You'll last ${nights} ${nights === 1 ? 'night' : 'nights'} with ${surplusHours} hours to spare`
    : `You'll run out by ${deficitHour} on Day ${deficitNight}`;

  const subText = willLast
    ? `Based on ${solarWatts}W solar, ${batteryAh}Ah ${batteryType}, ${sunHours} sun hrs. Running: ${appSummary}.`
    : `You need ${extraSolarNeeded}W more solar OR ${extraBatteryAh}Ah more battery to make it ${nights} ${nights === 1 ? 'night' : 'nights'} safely.`;

  return (
    <div
      className="rounded-xl p-4 flex gap-3 items-start"
      style={{ background: willLast ? '#C1D8C3' : '#D9A86C' }}
    >
      <div className="flex-shrink-0 mt-1">
        {willLast
          ? <CheckCircle size={28} color="#6A8D73" fill="white" />
          : <AlertTriangle size={28} color="#2F3E34" />
        }
      </div>
      <div>
        <p className="font-bold leading-snug mb-2" style={{ color: '#2F3E34', fontSize: 22 }}>
          {mainText}
        </p>
        <p className="text-sm" style={{ color: '#2F3E34' }}>{subText}</p>
      </div>
    </div>
  );
}