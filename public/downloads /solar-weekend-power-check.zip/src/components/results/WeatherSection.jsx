import React from "react";
import { Cloud, ExternalLink } from "lucide-react";

export default function WeatherSection({ zipCode }) {
  const url = zipCode
    ? `https://weatherpower.climatecentral.org/forecast?location=${zipCode}`
    : "https://weatherpower.climatecentral.org/forecast";

  return (
    <div className="border-t border-[#6A8D73]/30 pt-4 mt-4">
      <div className="flex items-start gap-2 mb-3">
        <Cloud className="w-5 h-5 text-[#6A8D73] mt-0.5 shrink-0" />
        <p className="text-[#2F3E34] text-sm">
          Weather changes your power. Cloudy = less solar.
        </p>
      </div>
      <a
        href={url}
        target="_blank"
        rel="noopener noreferrer"
        className="flex items-center justify-center gap-2 bg-[#6A8D73] text-white text-base font-bold py-3 px-4 rounded-xl w-full hover:bg-[#5a7d63] transition-colors"
      >
        Check Live Solar Forecast{zipCode ? ` for ${zipCode}` : ""}
        <ExternalLink className="w-4 h-4" />
      </a>
      <p className="text-[#2F3E34] text-xs text-center mt-2 opacity-60">
        Powered by Climate Central. Opens in browser.
      </p>
    </div>
  );
}